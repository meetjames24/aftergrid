"""Namespace-related methods for ``ZimOperations``.

This mixin handles namespace listing, browsing, and walking — anything
that surfaces or iterates over the archive's namespace structure.

``zim_archive`` is accessed through ``openzim_mcp.zim_operations`` so
existing test patches against the shim's symbols continue to work
without changes.
"""

import contextlib
import hashlib
import logging
from pathlib import Path
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Tuple, cast

from libzim.reader import Archive  # type: ignore[import-untyped]

import openzim_mcp.zim_operations as _zim_ops_mod
from openzim_mcp.constants import NAMESPACE_MAX_ENTRIES, NAMESPACE_MAX_SAMPLE_SIZE
from openzim_mcp.exceptions import (
    OpenZimMcpArchiveError,
    OpenZimMcpValidationError,
)
from openzim_mcp.meta import attach_meta
from openzim_mcp.zim._ops_base import _json
from openzim_mcp.zim.redirects import best_effort_redirect_chain

if TYPE_CHECKING:
    from openzim_mcp.cache import OpenZimMcpCache
    from openzim_mcp.config import OpenZimMcpConfig
    from openzim_mcp.content_processor import ContentProcessor
    from openzim_mcp.security import PathValidator
    from openzim_mcp.tool_schemas import (
        BrowseNamespaceResponse,
        ListNamespacesResponse,
        WalkNamespaceResponse,
    )

logger = logging.getLogger(__name__)


def is_human_readable_metadata_key(key: str) -> bool:
    """A11 post-a11 M1: shared filter for ``M/<key>`` metadata entries that
    can surface as text-rendered values.

    ``Illustration_*`` keys are binary PNG payloads (favicon-shaped art)
    that decode-as-utf8 turns into mojibake. Both ``metadata for <file>``
    (the aggregator at :meth:`Archive._extract_zim_metadata`) and
    ``walk namespace M`` should agree on what counts as a human-readable
    metadata key — splitting the filter between the two surfaces produced
    a 12-vs-13 disagreement (aggregator dropped the illustration; walk
    kept it). One predicate, one answer.
    """
    return not key.startswith("Illustration_")


# Human-readable description per ZIM namespace letter; surfaced in the
# ``list_namespaces`` JSON response.
_NAMESPACE_DESCRIPTIONS = {
    "C": "User content entries (articles, main content)",
    "M": "ZIM metadata (title, description, language, etc.)",
    "W": "Well-known entries (MainPage, Favicon, navigation)",
    "X": "Search indexes and full-text search data",
    "A": "Legacy content namespace (older ZIM files)",
    "I": "Images and media files",
    "-": "Layout and template files",
}

# D11 / Op6 (v2.0.0a9): the set of namespace letters defined by the ZIM
# spec — used by ``browse_namespace_data`` to fast-reject unknown
# tokens before the full-iteration fallback wastes cycles scanning a
# 27 M-entry archive for letters that don't exist. New-scheme
# archives are dominated by C; old-scheme add A and I plus the rarer
# legacy letters B (article meta data), J (images-text), U
# (categories-text) and V (categories-article-list), which
# ``list_namespaces`` can report with authoritative counts and browse/
# walk therefore must not contradict. ``-`` is the layout/templates
# pseudo-namespace.
_KNOWN_NAMESPACE_LETTERS = frozenset(
    {"C", "M", "W", "X", "A", "I", "B", "J", "U", "V", "-"}
)


# Upper bound on a browse-row ``preview``. Deliberately far below the
# configured ``snippet_length`` (3000): a browse row exists to help a
# caller choose a path, and a page of 50 rows should stay a navigation
# response rather than becoming 40 KB of article leads.
_PREVIEW_MAX_CHARS = 200


def _evenly_spaced(items: List[Any], count: int) -> List[Any]:
    """Return ``count`` items spread evenly across ``items`` (order kept).

    Shorter inputs are returned whole. The indices are computed with
    integer division so they are strictly increasing whenever
    ``len(items) >= count`` — no duplicate picks.
    """
    n = len(items)
    if n <= count or count <= 1:
        return list(items[:count]) if count > 0 else []
    return [items[i * (n - 1) // (count - 1)] for i in range(count)]


def _entry_mimetype(entry: "Any") -> Optional[str]:
    """Best-effort per-row mimetype for the asset filter.

    Reads the libzim item header mimetype (no content decode). Redirect
    entries and read errors degrade to ``None`` so the asset predicate falls
    back to the path/extension heuristic rather than failing the page.
    """
    try:
        if getattr(entry, "is_redirect", False):
            return None
        return entry.get_item().mimetype or None
    except Exception:
        return None


def _scan_fill_c_namespace(
    entry_count: int,
    get_path: "Any",
    is_asset: "Any",
    limit: int,
    offset: int,
    *,
    include_assets: bool = False,
) -> Tuple[List[str], int, bool, int]:
    """Scan new-scheme C entries by id, collecting up to ``limit`` real
    content rows starting after ``offset`` content rows.

    ``offset`` is a CONTENT-ROW offset (entries to skip among real content),
    not a raw entry-id scan position. The previous implementation used
    ``offset`` directly as the starting entry id, so offsets 1..N (which all
    fall inside the run of leading asset/redirect entries that get filtered)
    collapsed to the same first content row with the same resume cursor.
    Treating it as a row offset makes ``offset += limit`` paging advance by
    real rows. The cost is an O(offset) rescan from id 0 per page, which is
    acceptable for a navigation tool (id reads are cheap, no content decode).

    Unaddressable entries (empty path — the phantom empty-path/empty-title
    row that ``browse`` emitted at offset 0 but ``walk`` omitted) and assets
    are skipped and do not consume the offset budget.

    ``get_path(scan_id)`` returns ``(path, content_type)``; the per-row
    mimetype lets the asset predicate catch query-string / extensionless
    asset URLs (e.g. ``fonts.googleapis.com/css2?family=...``).
    ``include_assets=True`` surfaces asset rows instead of skipping them
    (``assets_skipped`` then stays 0).

    Returns ``(page_paths, next_row_offset, scan_exhausted, assets_skipped)``
    where ``next_row_offset = offset + len(page_paths)``.
    """
    page_paths: List[str] = []
    assets_skipped = 0
    content_seen = 0
    scan_id = 0
    while scan_id < entry_count and len(page_paths) < limit:
        path, content_type = get_path(scan_id)
        scan_id += 1
        if not path or not str(path).strip():
            # Read error (get_path returned None) or an unaddressable
            # empty-path entry — skip without consuming the offset budget.
            continue
        if not include_assets and is_asset(path, content_type):
            assets_skipped += 1
            continue
        if content_seen < offset:
            content_seen += 1
            continue
        page_paths.append(path)
    scan_exhausted = scan_id >= entry_count
    next_row_offset = offset + len(page_paths)
    return page_paths, next_row_offset, scan_exhausted, assets_skipped


# Minimum sampled hits required before we project a per-namespace total
# from the sampling ratio. Below this we report the lower-bound (sampled +
# probed) instead of fabricating numbers from single-hit projections.
_NAMESPACE_PROJECTION_MIN_SAMPLES = 3


def _deterministic_sample_ids(
    total_entries: int, sample_size: int, seed_token: str
) -> List[int]:
    """Pick ``sample_size`` entry ids out of ``total_entries``, reproducibly.

    This replaces ``Archive.get_random_entry()`` on the namespace-discovery
    path. libzim exposes no seed for that call, so it made
    ``list_namespaces`` answer differently on every invocation — and the
    answer is cached, so each cache fill froze one arbitrary roll of the
    dice. It was also *blind*: ``get_random_entry`` draws from the archive's
    **article** index, so namespaces that hold no articles (``I`` images,
    ``-`` layout assets) could never be sampled at all, however many entries
    they held.

    The replacement is a systematic sample: walk the id space at a fixed
    stride ``total/sample_size``, starting from a phase derived from the
    archive's UUID. That gives us three things at once:

    * **determinism** — same archive, same ids, same payload, forever.
    * **spread** — the walk covers the whole id space rather than the first
      N entries. Old-scheme ZIM archives store dirents grouped by namespace,
      so a strided walk represents each namespace roughly in proportion to
      its true size (systematic sampling over an ordered population), which
      is what the ratio projection downstream assumes.
    * **distinct draws** — ids are unique by construction, so the old
      retry-until-distinct loop (and its attempts multiplier) is gone.

    The UUID-derived phase keeps two same-sized archives from probing the
    identical offsets, without reintroducing any run-to-run variation.

    The trade being made: a systematic sample is biased whenever the
    population has a period that divides the stride. An archive whose
    dirent table repeated a namespace pattern with period
    ``total/sample_size`` would land every draw in the same namespace. ZIM
    dirents are sorted by path, so namespaces appear as contiguous runs
    rather than as a repeating cycle, and no corpus archive exercises it —
    but that is the failure mode to look for if a projection ever comes back
    absurd, and it is why ``_probe_known_namespaces`` still runs afterwards.
    """
    if total_entries <= 0 or sample_size <= 0:
        return []
    if sample_size >= total_entries:
        return list(range(total_entries))

    step = total_entries / sample_size
    digest = hashlib.blake2b(seed_token.encode("utf-8"), digest_size=8).digest()
    offset = int.from_bytes(digest, "big") % total_entries
    # ``int(i * step)`` is strictly increasing while ``step >= 1`` (which
    # holds because sample_size < total_entries), and rotating a set of
    # distinct values modulo ``total_entries`` keeps them distinct.
    return [(offset + int(i * step)) % total_entries for i in range(sample_size)]


def _archive_sample_seed(archive: Archive) -> str:
    """Stable per-archive seed for :func:`_deterministic_sample_ids`."""
    try:
        return str(getattr(archive, "uuid", "") or "")
    except Exception as e:  # pragma: no cover - defensive, libzim may raise
        logger.debug(f"Unable to read archive uuid for sampling seed: {e}")
        return ""


def _clamp_projections_to_total(
    estimates: Dict[str, int], floors: Dict[str, int], total_entries: int
) -> None:
    """Shrink projections in place so they cannot sum above the archive total.

    The per-namespace estimate is ``max(projected, observed)``: a ratio
    extrapolation for namespaces with enough sampled signal, floored by the
    entries we actually laid eyes on (sampled + probed). Both halves are
    individually reasonable and their sum was not — a namespace discovered
    only by a canonical-path probe adds its floor on top of a projection
    that has already spent the whole budget, so ``list_namespaces`` reported
    per-namespace counts summing past its own ``total_entries``.

    Observed counts are facts, so only the extrapolated part above each
    floor is scaled down, proportionally, into whatever headroom the floors
    leave. Truncating each share keeps the result at or below the total.

    This runs on the sampled branch only, where every bucket comes from the
    iterable entry surface that ``entry_count`` counts. It does not touch
    the new-scheme M/W namespaces added afterwards, which legitimately sit
    outside ``entry_count`` (see ``render_namespaces``' "+N" reconciliation).
    """
    projected = sum(estimates.values())
    if projected <= total_entries:
        return
    observed = sum(floors.values())
    headroom = total_entries - observed
    if headroom < 0:
        # What we observed already exceeds the stated total, so the total
        # is not describing the same population. Under-reporting entries we
        # have seen with our own eyes would be the worse lie; leave them.
        return
    # Positive by construction here: projected > total_entries >= observed.
    projected_excess = projected - observed
    for ns in estimates:
        excess = estimates[ns] - floors[ns]
        estimates[ns] = floors[ns] + int(excess * headroom / projected_excess)


class _NamespaceMixin:
    """Namespace listing / browsing / walking methods for ZimOperations."""

    if TYPE_CHECKING:
        config: "OpenZimMcpConfig"
        path_validator: "PathValidator"
        cache: "OpenZimMcpCache"
        content_processor: "ContentProcessor"

        def _validate_zim_path(self, zim_file_path: str) -> Path:
            """Resolve via ``_ArchiveAccessMixin`` on the concrete coordinator."""

        def _is_non_article_target(
            self, path: str, content_type: "Optional[str]" = None
        ) -> bool:
            """Resolve via ``_StructureMixin`` on the concrete coordinator."""

    def list_namespaces_data(self, zim_file_path: str) -> "ListNamespacesResponse":
        """Structured variant of ``list_namespaces``.

        Returns the same payload as ``list_namespaces`` but as a Python
        dict, so MCP tool functions can hand it straight to the SDK's
        structured-output path without the json.dumps + re-parse round
        trip the legacy string variant required.

        Phase B v2: this is the one list-shaped result that does NOT carry
        the PaginatedResponse contract — it returns a dict-of-summaries,
        not a list. Top-level keys are ``total_entries`` /
        ``sampled_entries`` / ``has_new_namespace_scheme`` /
        ``is_total_authoritative`` / ``discovery_method`` / ``namespaces``
        plus the universal ``_meta`` envelope.

        Raises:
            OpenZimMcpFileNotFoundError: If ZIM file not found
            OpenZimMcpArchiveError: If namespace listing fails
        """
        # Validate and resolve file path
        validated_path = self._validate_zim_path(zim_file_path)

        # Cache key bumped to v2b (Phase B) so v1.x cached responses (old
        # shape: entry_count key) don't leak through after the rename to ``total``.
        # Bumped again to v2c when the sampled branch stopped drawing from
        # ``get_random_entry``: the archive does not change when the sampler
        # does, so a persisted snapshot would keep serving pre-fix listings
        # (random ``sample_entries``, no ``I`` bucket, per-namespace counts
        # summing above ``total_entries``) until TTL expiry.
        # Bumped again to v2d when ``sample_entries`` changed from the
        # first five rows recorded to an evenly-spread, article-preferring
        # pick, and the M bucket on OLD-scheme archives changed from a
        # sampled estimate to the exact ``metadata_keys`` enumeration. Same
        # argument as the v2c bump: neither depends on the archive, so a
        # persisted snapshot would keep serving the pre-fix listing
        # (five adjacent JPEGs, M under-reported 2x) until TTL expiry.
        # The stat token (mtime_ns:size) invalidates the listing when the
        # archive is replaced in place (archive_stat_token contract, which
        # names namespace listings explicitly).
        from openzim_mcp.bundle import archive_stat_token

        cache_key = (
            f"namespaces_data:v2d:{validated_path}:"
            f"{archive_stat_token(validated_path)}"
        )
        cached_result = self.cache.get(cache_key)
        if cached_result is not None:
            logger.debug(f"Returning cached namespaces dict for: {validated_path}")
            return cast("ListNamespacesResponse", cached_result)

        try:
            with _zim_ops_mod.zim_archive(validated_path) as archive:
                result = self._list_archive_namespaces(archive)

            # Attach _meta BEFORE caching so cold and warm reads return
            # bit-identical responses (Phase B #12 fix — re-attaching on
            # each cache hit produced non-deterministic chars/tokens_est).
            with_meta = attach_meta(result)
            self.cache.set(cache_key, with_meta)
            logger.info(f"Listed namespaces for: {validated_path}")
            return cast("ListNamespacesResponse", with_meta)

        except Exception as e:
            logger.error(f"Namespace listing failed for {validated_path}: {e}")
            raise OpenZimMcpArchiveError(f"Namespace listing failed: {e}") from e

    def list_namespaces(self, zim_file_path: str) -> str:
        """Legacy JSON-string variant of ``list_namespaces_data``.

        Retained so ``SimpleToolsHandler`` (which composes natural-language
        responses out of these strings) keeps working unchanged. New
        callers should prefer ``list_namespaces_data``.
        """
        return _json(self.list_namespaces_data(zim_file_path))

    def _list_archive_namespaces(self, archive: Archive) -> Dict[str, Any]:
        """List namespaces in the archive.

        For small archives (entry_count <= NAMESPACE_MAX_SAMPLE_SIZE) iterate
        every entry by ID so the namespace inventory is exhaustive. For larger
        archives, fall back to a systematic sample of entry ids (see
        :func:`_deterministic_sample_ids`) and return estimated counts —
        deterministic per archive, and projected so the buckets cannot sum
        above ``entry_count``.

        For new-scheme archives, the iterable surface only contains C
        entries; M is enumerated separately via ``archive.metadata_keys`` and
        W is surfaced via canonical probes.
        """
        namespaces: Dict[str, Dict[str, Any]] = {}
        seen_entries: set[str] = set()
        has_new_scheme = getattr(archive, "has_new_namespace_scheme", False)
        logger.debug(f"Archive uses new namespace scheme: {has_new_scheme}")

        total_entries = archive.entry_count
        full_iteration = total_entries <= NAMESPACE_MAX_SAMPLE_SIZE

        record = self._make_namespace_recorder(
            namespaces, seen_entries, has_new_scheme=has_new_scheme
        )

        if full_iteration:
            self._iterate_all_entries(archive, total_entries, record)
            self._finalise_full_iteration(namespaces)
        else:
            self._sample_entries(archive, total_entries, record)
            self._probe_known_namespaces(archive, seen_entries, record)
            self._finalise_sampled(namespaces, total_entries)
        self._publish_sample_entries(namespaces)

        # In new-scheme archives, M, W, X are reached via dedicated APIs, not
        # via the entry iterator. Surface them explicitly so callers see the
        # archive's real namespace inventory.
        if has_new_scheme:
            self._add_new_scheme_metadata_namespace(archive, namespaces)
            self._add_new_scheme_well_known_namespace(archive, namespaces)
            # P3-D3 (live-MCP sweep): for new-scheme archives the
            # iterable entry surface IS the C namespace, so
            # ``archive.entry_count`` is authoritative for C. The
            # sampling projection at ``_finalise_sampled`` derives an
            # estimate that drifts by ±1 for archives over the
            # ``MAX_SAMPLE_SIZE`` threshold; pin C to the exact total so
            # ``list_namespaces`` agrees with ``walk_namespace C`` /
            # ``metadata for <file>`` (all three now report the same
            # ``entry_count`` value).
            if "C" in namespaces:
                namespaces["C"]["total"] = total_entries
                namespaces["C"]["estimated_total"] = total_entries
                namespaces["C"]["is_authoritative"] = True
        else:
            # ``metadata_keys`` is exhaustive on OLD-scheme archives too —
            # the gate above used to keep this branch new-scheme-only, so
            # any legacy archive over ``NAMESPACE_MAX_SAMPLE_SIZE`` fell
            # through to the 1000-draw sampler for a namespace libzim can
            # enumerate exactly and for free. On the zim-testing-suite
            # 20,565-entry archive that published M as an estimated 6
            # while ``zim_browse(mode="walk")`` returned all 12 seconds
            # later on the same server. Old-scheme M entries are ordinary
            # iterable entries and browse/walk surface every one of them
            # (the binary ``Illustration_*`` blob included), so the
            # human-readable filter — which exists to keep the new-scheme
            # aggregators agreeing with each other — is NOT applied here;
            # applying it would trade a 2x under-report for an off-by-one.
            self._add_metadata_namespace_from_keys(
                archive, namespaces, filter_binary_keys=False
            )

        # P3-D3 / Op2: surface both documented archive totals so the
        # per-namespace-sum-vs-total relationship is legible to readers.
        # ``entry_count`` is the user-facing canonical count (returned in
        # ``metadata for <file>``); ``all_entry_count`` includes
        # well-knowns / redirects / indexes that ``entry_count`` excludes.
        all_entry_count = getattr(archive, "all_entry_count", None)

        result: Dict[str, Any] = {
            "total_entries": total_entries,
            "sampled_entries": len(seen_entries),
            "has_new_namespace_scheme": has_new_scheme,
            "is_total_authoritative": full_iteration,
            "discovery_method": "full_iteration" if full_iteration else "sampling",
            "namespaces": namespaces,
        }
        if all_entry_count is not None:
            result["all_entry_count"] = int(all_entry_count)
        return result

    @staticmethod
    def _add_new_scheme_metadata_namespace(
        archive: Archive, namespaces: Dict[str, Dict[str, Any]]
    ) -> None:
        """Populate the M namespace entry from ``archive.metadata_keys``.

        In new-scheme archives the public entry iterator surfaces only C
        entries; metadata is reached through ``Archive.metadata_keys`` and
        ``get_metadata_item``. Without this, list_namespaces would silently
        omit M for every modern archive.
        """
        _NamespaceMixin._add_metadata_namespace_from_keys(
            archive, namespaces, filter_binary_keys=True
        )

    @staticmethod
    def _add_metadata_namespace_from_keys(
        archive: Archive,
        namespaces: Dict[str, Dict[str, Any]],
        *,
        filter_binary_keys: bool,
    ) -> None:
        """Populate the M bucket from ``archive.metadata_keys``.

        ``metadata_keys`` enumerates M exhaustively on BOTH namespace
        schemes, so the bucket it produces is authoritative and needs no
        sampling.

        ``filter_binary_keys`` selects which surface we have to agree
        with. On new-scheme archives M is reachable only through the
        metadata APIs and the sibling aggregators (``walk namespace M``,
        ``metadata for <file>``) run every key through
        :func:`is_human_readable_metadata_key`, so this surface must too
        or the three disagree (13 vs 12). On old-scheme archives M
        entries are ordinary iterable entries; browse and walk return the
        binary ``Illustration_*`` blob along with the rest, so filtering
        here would re-introduce the same disagreement in the opposite
        direction.
        """
        try:
            raw_keys = list(getattr(archive, "metadata_keys", []) or [])
        except Exception as e:
            logger.debug(f"Unable to read metadata_keys: {e}")
            return
        # a13 D2: filter through the shared predicate so list_namespaces,
        # walk namespace M, and metadata-for agree on the same bucket size.
        # Pre-fix, list_namespaces reported M=13 (raw libzim count, includes
        # the ``Illustration_*`` binary entry) while the other two reported
        # M=12. The a12 M1 fix plumbed the predicate to walk + metadata-for
        # but missed this third surface.
        keys = (
            [k for k in raw_keys if is_human_readable_metadata_key(k)]
            if filter_binary_keys
            else raw_keys
        )
        if not keys:
            return
        # ``metadata_keys`` is an exhaustive enumeration of M, so the
        # bucket is authoritative — we know the total without sampling.
        ns_info = {
            "total": len(keys),
            "is_authoritative": True,
            "description": _NAMESPACE_DESCRIPTIONS["M"],
            "sample_entries": [{"path": f"M/{k}", "title": k} for k in keys[:5]],
            "sampled_count": len(keys),
            "estimated_total": len(keys),
            "probed_count": 0,
        }
        namespaces["M"] = ns_info

    @staticmethod
    def _add_new_scheme_well_known_namespace(
        archive: Archive, namespaces: Dict[str, Dict[str, Any]]
    ) -> None:
        """Surface the W namespace via canonical probes (mainPage, favicon).

        New-scheme archives expose well-known entries through dedicated APIs
        (``main_entry``, ``get_illustration_item``); they aren't part of the
        iterable C surface. Probing canonical paths gives a deterministic
        existence proof.
        """
        probes: List[Tuple[str, str]] = []
        # Suppressing exceptions here is intentional: probes are best-effort
        # advertisements of well-known entries. A failed probe simply means
        # we don't surface that path; it must not abort the listing.
        with contextlib.suppress(Exception):
            if getattr(archive, "has_main_entry", False):
                probes.append(("W/mainPage", "mainPage"))
        # ``has_illustration()`` (no size arg) reports whether any
        # illustration is available; preferred over the deprecated
        # ``get_illustration_sizes`` which carries a DeprecationWarning.
        with contextlib.suppress(Exception):
            if archive.has_illustration():
                probes.append(("W/favicon", "favicon"))
        if not probes:
            return
        # Probed-only buckets are authoritative existence proofs but the
        # ``total`` is a lower bound — we know these specific paths exist
        # but not how many other W entries the archive holds. We mark
        # ``is_authoritative=False`` to reflect that the count is not the
        # whole namespace, just confirmed canonical paths.
        namespaces["W"] = {
            "total": len(probes),
            "is_authoritative": False,
            "description": _NAMESPACE_DESCRIPTIONS["W"],
            "sample_entries": [{"path": p, "title": t} for p, t in probes],
            "sampled_count": 0,
            "probed_count": len(probes),
            "estimated_total": len(probes),
        }

    def _make_namespace_recorder(
        self,
        namespaces: Dict[str, Dict[str, Any]],
        seen_entries: set[str],
        has_new_scheme: bool = False,
    ) -> Any:
        """Build a closure that registers one entry into the namespaces map.

        Tracks sampled vs probed separately because probed entries are
        deterministic existence proofs and do NOT carry the
        sampling-frequency signal needed for ratio extrapolation.

        ``has_new_scheme`` is forwarded to the namespace extractor so that
        new-scheme archives don't fabricate first-letter buckets like
        ``F`` from ``favicon.png`` or ``E`` from ``Evolution``.
        """

        def _record(path: str, title: str, is_probe: bool = False) -> None:
            if path in seen_entries:
                return
            seen_entries.add(path)
            namespace = self._extract_namespace_from_path(
                path, has_new_scheme=has_new_scheme
            )
            ns_info = namespaces.setdefault(
                namespace,
                {
                    # ``total`` is the per-namespace count (renamed from
                    # ``count`` in v2 Phase B for consistency with
                    # PaginatedResponse.total). For full-iteration buckets
                    # this is exact; for sampled buckets it is overwritten
                    # with the projected estimate during finalisation.
                    "total": 0,
                    # Set during finalisation: True for full iteration,
                    # False for sampled / probed-only buckets.
                    "is_authoritative": False,
                    "description": _NAMESPACE_DESCRIPTIONS.get(
                        namespace, f"Namespace '{namespace}'"
                    ),
                    "sample_entries": [],
                    "_sample_pool": [],
                    "_probed_count": 0,
                    "_sampled_count": 0,
                },
            )
            if is_probe:
                ns_info["_probed_count"] += 1
            else:
                ns_info["_sampled_count"] += 1
            ns_info["total"] += 1
            # Collect every candidate; :meth:`_publish_sample_entries` picks
            # the five that ship. The recorder used to keep the first five
            # rows it saw, which is a contiguous slice of a path-ordered
            # walk: on both real corpus archives that made all five
            # published examples media files (``wp-content/media/*``,
            # ``ency/images/ency/fullsize/*.jpg``) under the description
            # "User content entries (articles, main content)". The 1000-draw
            # sample already spans the archive; only the publishing step
            # threw the spread away. The pool is bounded by the sampler
            # itself (``NAMESPACE_MAX_SAMPLE_SIZE`` draws, or an exhaustive
            # walk that only runs below that same threshold).
            ns_info["_sample_pool"].append({"path": path, "title": title or path})

        return _record

    def _publish_sample_entries(self, namespaces: Dict[str, Dict[str, Any]]) -> None:
        """Choose the five ``sample_entries`` each bucket publishes.

        Two rules, both aimed at the one job the field has — teaching a
        caller what an entry path in this archive looks like:

        * spread the picks evenly across the recorded candidates instead
          of taking a head slice, and
        * prefer rows that are not ``_is_non_article_target`` assets, so
          a media-heavy scrape does not advertise itself as a pile of
          JPEGs. Buckets with fewer than five non-asset candidates fall
          back to the full pool rather than publishing less.
        """
        # Imported from the structure mixin rather than reached through
        # ``self`` so the choice stays available to callers that compose
        # only this mixin (the concrete coordinator inherits both).
        from openzim_mcp.zim.structure import _StructureMixin

        is_asset = _StructureMixin._is_non_article_target
        for ns_info in namespaces.values():
            pool = ns_info.pop("_sample_pool", None)
            if not pool:
                continue
            articles = [entry for entry in pool if not is_asset(entry["path"])]
            source = articles if len(articles) >= 5 else pool
            ns_info["sample_entries"] = _evenly_spaced(source, 5)

    @staticmethod
    def _iterate_all_entries(archive: Archive, total_entries: int, record: Any) -> None:
        """Walk every entry id (small-archive path)."""
        logger.debug(
            f"Iterating all {total_entries} entries for exhaustive "
            f"namespace listing"
        )
        for entry_id in range(total_entries):
            try:
                entry = archive._get_entry_by_id(entry_id)
                record(entry.path, entry.title or "")
            except Exception as e:
                logger.debug(f"Error reading entry {entry_id}: {e}")

    @staticmethod
    def _finalise_full_iteration(namespaces: Dict[str, Dict[str, Any]]) -> None:
        """Collapse internal counters into the public shape after full scan."""
        for ns_info in namespaces.values():
            # Full iteration enumerates every entry — the bucket's total
            # is exact and the bucket is authoritative.
            ns_info["sampled_count"] = ns_info["total"]
            ns_info["estimated_total"] = ns_info["total"]
            ns_info["is_authoritative"] = True
            ns_info.pop("_probed_count", None)
            ns_info.pop("_sampled_count", None)

    @staticmethod
    def _sample_entries(archive: Archive, total_entries: int, record: Any) -> None:
        """Sample up to NAMESPACE_MAX_SAMPLE_SIZE distinct entries.

        Deterministic by construction — see :func:`_deterministic_sample_ids`
        for why ``get_random_entry`` could not be used here. That helper
        yields exactly ``sample_size`` distinct ids, so the old
        retry-until-distinct loop (and the "stop once we have enough" bound
        that went with it) has no work left to do.
        """
        sample_size = min(NAMESPACE_MAX_SAMPLE_SIZE, total_entries)
        logger.debug(
            f"Sampling {sample_size} entries from {total_entries} total entries"
        )
        try:
            entry_ids = _deterministic_sample_ids(
                total_entries, sample_size, _archive_sample_seed(archive)
            )
            for entry_id in entry_ids:
                try:
                    entry = archive._get_entry_by_id(entry_id)
                    record(entry.path, entry.title or "", is_probe=False)
                except Exception as e:
                    logger.debug(f"Error sampling entry {entry_id}: {e}")
        except Exception as e:
            logger.warning(f"Error during namespace sampling: {e}")

    def _probe_known_namespaces(
        self, archive: Archive, seen_entries: set[str], record: Any
    ) -> None:
        """Probe canonical paths to surface namespaces missed by sampling.

        A 1-in-N sample of a large archive can still miss minority
        namespaces (e.g. M, W, X, I when A holds 99%+ of entries) — with
        ``NAMESPACE_MAX_SAMPLE_SIZE`` draws over a 20k-entry archive the
        stride is ~20, so a namespace with fewer than ~20 entries may fall
        entirely between two steps. Trying canonical paths in each common
        namespace surfaces those, independently of where the stride lands.

        A probe proves existence only; the hit is recorded as a floor, not
        as sampled signal, so it never feeds the ratio projection.
        """
        for canonical_path in self._get_known_namespace_probes():
            try:
                if (
                    archive.has_entry_by_path(canonical_path)
                    and canonical_path not in seen_entries
                ):
                    try:
                        entry = archive.get_entry_by_path(canonical_path)
                        record(entry.path, entry.title or "", is_probe=True)
                    except Exception as e:
                        logger.debug(
                            f"Error reading canonical entry {canonical_path}: {e}"
                        )
            except Exception as e:
                logger.debug(f"Error probing canonical path {canonical_path}: {e}")

    @staticmethod
    def _finalise_sampled(
        namespaces: Dict[str, Dict[str, Any]], total_entries: int
    ) -> None:
        """Project per-namespace totals from sample counts.

        We extrapolate ONLY the sampled count via the sampling ratio —
        probed entries are confirmed-present-but-frequency-unknown, so they
        only contribute a lower-bound floor. Project only when we have
        enough sampled signal to make a stable estimate; below the
        threshold, single-hit projections vary by 100%+ and effectively
        manufacture numbers.

        The projections are then clamped as a set: a bucket found only by a
        canonical-path probe used to add its floor on top of a ratio
        projection that had already accounted for the entire archive, so the
        published per-namespace counts summed above ``total_entries``. See
        :func:`_clamp_projections_to_total`.
        """
        sampled_only_count = sum(v["_sampled_count"] for v in namespaces.values())
        sampling_ratio = (
            sampled_only_count / total_entries if sampled_only_count else 0.0
        )
        floors: Dict[str, int] = {}
        estimates: Dict[str, int] = {}
        for namespace, ns_info in namespaces.items():
            sampled = ns_info["_sampled_count"]
            probed = ns_info["_probed_count"]
            if sampling_ratio > 0 and sampled >= _NAMESPACE_PROJECTION_MIN_SAMPLES:
                estimated_from_sample = int(sampled / sampling_ratio)
            else:
                estimated_from_sample = 0
            floors[namespace] = sampled + probed
            estimates[namespace] = max(estimated_from_sample, floors[namespace])

        _clamp_projections_to_total(estimates, floors, total_entries)

        for namespace, ns_info in namespaces.items():
            ns_info["sampled_count"] = ns_info["_sampled_count"]
            ns_info["probed_count"] = ns_info["_probed_count"]
            ns_info["estimated_total"] = estimates[namespace]
            ns_info["total"] = estimates[namespace]
            # Sampling-derived counts are projections, not exact totals.
            ns_info["is_authoritative"] = False
            ns_info.pop("_probed_count", None)
            ns_info.pop("_sampled_count", None)

    def _extract_namespace_from_path(
        self, path: str, has_new_scheme: bool = False
    ) -> str:
        """Extract namespace from entry path.

        In **new-scheme** ZIM files, libzim's iterable entry surface
        (``entry_count`` / ``_get_entry_by_id`` / ``get_random_entry``) only
        exposes the C (content) namespace; entry paths carry no namespace
        prefix. So every iterable path is by definition in C, regardless of
        what its first character happens to be — parsing ``favicon.png`` or
        ``Evolution`` as namespace ``F`` / ``E`` is wrong.

        In **old-scheme** ZIMs, paths are namespace-prefixed (``A/Article``,
        ``M/Title``); the first segment is the namespace.

        Callers that have an ``Archive`` in scope must pass
        ``has_new_scheme=archive.has_new_namespace_scheme``. The default
        (``False``) preserves legacy single-arg call sites and keeps the
        canonicaliser-style behaviour used by some unit tests.
        """
        if not path:
            return "Unknown"

        if has_new_scheme:
            # libzim's iterable surface in new-scheme is C-only.
            return "C"

        # Old-scheme: namespace is the first segment before '/' (or, rarely,
        # the first character if no slash is present).
        if "/" in path:
            namespace = path.split("/", 1)[0]
        else:
            namespace = path[0] if path else "Unknown"

        return self._canonicalise_namespace(namespace)

    @staticmethod
    def _canonicalise_namespace(namespace: str) -> str:
        """Map a raw namespace token to its canonical short form.

        Handles single-char prefixes (case-insensitive — ZIM archives
        canonically use uppercase but tooling and user input may pass
        lowercase) and the long-form aliases ("content", "metadata", etc.)
        used by some new-scheme archives. Long-form matching is also
        case-insensitive so that callers passing ``CONTENT`` or
        ``Metadata`` get the same result as ``content`` / ``metadata``.
        """
        if len(namespace) == 1 and namespace.isalpha():
            # Single character namespace (typical for both old and new schemes)
            return namespace.upper()
        # Long-form aliases — match case-insensitively so callers don't
        # get silent zero-result responses for ``CONTENT`` etc.
        lower = namespace.lower()
        if lower == "content":
            return "C"
        if lower == "metadata":
            return "M"
        if lower in ("wellknown", "well-known"):
            return "W"
        if lower in ("search", "index"):
            return "X"
        return namespace

    @staticmethod
    def _get_known_namespace_probes() -> List[str]:
        """Canonical paths that, if present, prove a namespace exists.

        Used by list_namespaces to surface minority namespaces (M, W, X, I,
        -) that a 1-in-N sample can still miss on archives where one
        namespace dominates. A probe proves existence; it says nothing about
        how many entries the namespace holds, which is why probed hits are
        counted separately from sampled ones.
        """
        return [
            # Metadata
            "M/Title",
            "M/Description",
            "M/Language",
            "M/Creator",
            "M/Date",
            # Well-known
            "W/mainPage",
            "W/favicon",
            # Search indexes
            "X/fulltext/xapian",
            "X/title/xapian",
            # Images / media
            "I/favicon.png",
            # Layout / templates
            "-/favicon",
        ]

    def browse_namespace_data(
        self,
        zim_file_path: str,
        namespace: str,
        limit: int = 50,
        offset: int = 0,
        *,
        cursor_archive_identity: Optional[str] = None,
        include_assets: bool = False,
    ) -> "BrowseNamespaceResponse":
        """Structured variant of ``browse_namespace``.

        Returns the result dict directly (not a JSON string) so MCP tools
        can hand it straight to the SDK's structured-content path.

        Phase B contract: top-level ``results`` / ``next_cursor`` /
        ``total`` / ``done`` / ``page_info`` plus the ``namespace`` /
        ``discovery_method`` / ``sampling_based`` /
        ``results_may_be_incomplete`` extras. ``next_cursor`` is encoded
        with ``tool="browse_namespace"`` and state ``{o, l, ns, as, ai}``.

        ``cursor_archive_identity`` is the ``s.ai`` value decoded from a
        resumed cursor; mismatched archives are rejected so a cursor
        issued for archive A cannot be honoured against archive B.

        Raises:
            OpenZimMcpValidationError: If parameter validation fails (limit,
                offset, or namespace), or if a cursor was issued for a
                different archive.
            OpenZimMcpFileNotFoundError: If ZIM file not found
            OpenZimMcpArchiveError: If browsing fails
        """
        from openzim_mcp.pagination import (
            Cursor,
            CursorMismatchError,
            archive_identity,
        )

        # Validate parameters. These are caller-input errors, distinct from
        # archive-access failures, so they surface as
        # OpenZimMcpValidationError to let the tool layer render a targeted
        # validation message.
        # Same shape as the walk validator's message so the two modes of
        # zim_browse reject an out-of-range limit in one style (D06).
        if limit < 1 or limit > 200:
            raise OpenZimMcpValidationError(
                f"limit must be between 1 and 200 (provided: {limit})"
            )
        if offset < 0:
            raise OpenZimMcpValidationError("Offset must be non-negative")
        if not namespace or len(namespace.strip()) == 0:
            raise OpenZimMcpValidationError("Namespace must be a non-empty string")

        # Canonicalise user input (e.g. "c" -> "C", "content" -> "C") so
        # the comparison against ``_extract_namespace_from_path`` (which
        # always returns the canonical form) does not silently miss every
        # entry when callers pass lowercase or long-form names.
        namespace = self._canonicalise_namespace(namespace.strip())

        # D11 / Op6 (v2.0.0a9): fast-reject unknown namespaces before the
        # full-iteration fallback wastes cycles scanning a 27M-entry
        # archive for a letter that the ZIM spec doesn't define.
        # Returns a structured ``bad_namespace`` payload so the caller
        # can self-correct via the empty-result footer's recovery hint.
        if namespace not in _KNOWN_NAMESPACE_LETTERS:
            empty_payload: Dict[str, Any] = {
                "namespace": namespace,
                "results": [],
                "next_cursor": None,
                "total": 0,
                "done": True,
                "page_info": {
                    "offset": offset,
                    "limit": limit,
                    "returned_count": 0,
                },
                "discovery_method": "rejected_unknown_namespace",
                "sampling_based": False,
                "results_may_be_incomplete": False,
            }
            return cast(
                "BrowseNamespaceResponse",
                attach_meta(empty_payload, reason="bad_namespace"),
            )

        # Validate and resolve file path
        validated_path = self._validate_zim_path(zim_file_path)

        # Cursor integrity: a cursor issued for archive A must not be
        # honoured when resubmitted against archive B (same guard as
        # walk_namespace / extract_article_links / search_zim_file).
        if cursor_archive_identity is not None:
            try:
                Cursor.verify_archive_identity(
                    cast("Any", {"ai": cursor_archive_identity}),
                    expected=archive_identity(validated_path),
                    tool="browse_namespace",
                )
            except CursorMismatchError as e:
                raise OpenZimMcpValidationError(str(e)) from e

        # Cache key bumped v2c -> v2d: new-scheme C now treats ``offset`` as a
        # content-row offset (skip N real rows) rather than a raw entry-id
        # scan position, and skips unaddressable empty-path entries. The
        # cursor ``s.o`` is therefore a row offset again; ``total`` stays the
        # authoritative ``entry_count``. The bump stops pre-fix cached pages —
        # with the old entry-id-offset cursor — from leaking through.
        # Bumped again v2e -> v2f when the old-scheme sampled branch stopped
        # drawing from ``get_random_entry``: the archive does not change when
        # the sampler does, so a persisted snapshot would keep serving the
        # pre-fix pages (a different random population per page, and an empty
        # result for every namespace the article index cannot reach) until TTL
        # expiry.
        # Bumped again v2f -> v2g for three payload changes that are all
        # independent of the archive: row ``preview`` now renders the
        # main-content landmark (rather than the site chrome),
        # ``results_may_be_incomplete`` reports sampledness (rather than
        # sample-cap saturation), and a namespace that is not on the
        # iterable surface reports ``discovery_method: "not_iterable"``
        # (rather than a fabricated ``full_iteration``). A persisted
        # snapshot would keep serving all three pre-fix values until TTL
        # expiry.
        # The stat token (mtime_ns:size) invalidates the page when the
        # archive is replaced in place (archive_stat_token contract).
        from openzim_mcp.bundle import archive_stat_token

        cache_key = (
            f"browse_ns_data:v2g:{validated_path}:"
            f"{archive_stat_token(validated_path)}:{namespace}:"
            f"{limit}:{offset}:assets={include_assets}"
        )
        cached_result = self.cache.get(cache_key)
        if cached_result is not None:
            logger.debug(f"Returning cached namespace browse dict for: {namespace}")
            return cast("BrowseNamespaceResponse", cached_result)

        try:
            with _zim_ops_mod.zim_archive(validated_path) as archive:
                raw = self._browse_namespace_entries(
                    archive,
                    namespace,
                    limit,
                    offset,
                    archive_path=str(validated_path),
                    include_assets=include_assets,
                )

            # ``_browse_namespace_entries`` still returns the legacy inner
            # shape (entries / total_in_namespace / is_total_authoritative / ...). Adapt
            # to the v2 Phase B contract here so internal callers and tests
            # that target the helper aren't forced through the rename.
            entries = raw.get("entries", [])
            total_in_namespace = raw.get("total_in_namespace", 0)
            is_total_authoritative = raw.get("is_total_authoritative", True)
            discovery_method = raw.get("discovery_method", "unknown")
            sampling_based = raw.get("sampling_based", False)
            results_may_be_incomplete = raw.get("results_may_be_incomplete", False)

            returned_count = len(entries)
            # New-scheme C uses entry-id scan-fill (it filters non-article
            # assets), so its resume position is a SCAN position, not a
            # matched-row offset: ``next_scan_offset`` is the next unscanned
            # entry-id and ``done`` is scan-exhaustion. Encoding
            # ``offset + returned_count`` instead would drift once filtering
            # makes matched-rows < ids-scanned. Every other discovery method
            # keeps the row-offset cursor.
            next_row_offset = raw.get("next_row_offset")
            # Surfaced so a consumer reads ``returned_count`` < ``limit`` (and,
            # at ``done``, well below ``total`` on a media-rich archive) as
            # filtering, not truncation. The scan-fill path counts genuine
            # asset skips precisely (read errors / materialise drops excluded).
            assets_filtered = bool(raw.get("assets_filtered"))
            if next_row_offset is not None:
                resume_index = int(next_row_offset)
                done = bool(raw.get("scan_exhausted", True))
                sample_exhausted = False
            else:
                # Resume by CANDIDATE rows consumed, not by surviving rows:
                # ``_materialise_browse_entry`` can drop rows inside the
                # window (read errors, non-materialisable entries), and a
                # survivors-count resume re-examined the tail of the window
                # (duplicate rows) — or, when every row in a window dropped,
                # never advanced at all (same empty page forever).
                scanned_count = int(raw.get("scanned_count", returned_count))
                last_index = offset + scanned_count
                # When the discovery method is sampling-based,
                # ``total_in_namespace`` is the size of the sample (capped at
                # ``NAMESPACE_MAX_ENTRIES``), not the true namespace size.
                # Reporting ``done=True`` once the caller has consumed the
                # sample silently truncates pagination — the contract key says
                # "no more pages" but in reality only a fraction of the
                # namespace was returned. When sampling is in play and the page
                # is full, keep emitting ``next_cursor`` so the caller can
                # continue paging or pivot to ``walk_namespace`` for exhaustive
                # iteration. The ``page_info.total_is_lower_bound`` flag plus
                # ``_meta.reason="sample_only"`` give the caller enough signal.
                sample_exhausted = (
                    sampling_based
                    and scanned_count >= limit
                    and last_index >= total_in_namespace
                )
                done = (last_index >= total_in_namespace) and not sample_exhausted
                resume_index = last_index
            next_cursor: Optional[str] = None
            if not done:
                from openzim_mcp.pagination import archive_identity

                # ``as`` pins the asset visibility the resume offset was
                # counted under: on new-scheme C ``o`` is a content-row
                # offset against the include_assets-filtered row stream, so
                # replaying the cursor with the flag flipped skips (or
                # repeats) every row the other setting counted. The tool
                # layer adopts / rejects it the way it does ``ns``.
                next_cursor = Cursor.encode(
                    tool="browse_namespace",
                    state=cast(
                        "Any",
                        {
                            "o": resume_index,
                            "l": limit,
                            "ns": namespace,
                            "as": include_assets,
                            "ai": archive_identity(validated_path),
                        },
                    ),
                )

            page_info: Dict[str, Any] = {
                "offset": offset,
                "limit": limit,
                "returned_count": returned_count,
            }
            if not is_total_authoritative:
                page_info["total_is_lower_bound"] = True
            if assets_filtered:
                page_info["assets_filtered"] = True

            payload: Dict[str, Any] = {
                "namespace": namespace,
                "results": entries,
                "next_cursor": next_cursor,
                "total": total_in_namespace,
                "done": done,
                "page_info": page_info,
                "discovery_method": discovery_method,
                "sampling_based": sampling_based,
                "results_may_be_incomplete": results_may_be_incomplete,
            }

            # Op4: ``reason="sample_only"`` flags that the page came from
            # a sampled discovery and ``done`` is conservatively False so
            # the caller knows to either keep paging or pivot to
            # ``walk_namespace`` for exhaustive iteration. The footer
            # renderer surfaces this as actionable prose.
            reason = "sample_only" if sample_exhausted else None
            # The namespace exists in the ZIM spec but is not on this
            # archive's iterable surface (see ``_browse_namespace_entries``).
            # Carry the reason so a machine consumer can tell "nothing there"
            # apart from "nothing reachable this way".
            if discovery_method == "not_iterable":
                reason = "namespace_not_iterable"
            with_meta = attach_meta(payload, reason=reason)
            self.cache.set(cache_key, with_meta)
            logger.info(
                f"Browsed namespace {namespace}: {limit} entries from offset {offset}"
            )
            return cast("BrowseNamespaceResponse", with_meta)

        except Exception as e:
            logger.error(f"Namespace browsing failed for {namespace}: {e}")
            raise OpenZimMcpArchiveError(f"Namespace browsing failed: {e}") from e

    def browse_namespace(
        self, zim_file_path: str, namespace: str, limit: int = 50, offset: int = 0
    ) -> str:
        """Legacy JSON-string variant of ``browse_namespace_data``.

        Browse entries in a specific namespace with pagination.

        Args:
            zim_file_path: Path to the ZIM file
            namespace: Namespace to browse (C, M, W, X, A, I for old; domains for new)
            limit: Maximum number of entries to return
            offset: Starting offset for pagination

        Returns:
            JSON string containing namespace entries

        Raises:
            OpenZimMcpValidationError: If parameter validation fails (limit,
                offset, or namespace).
            OpenZimMcpFileNotFoundError: If ZIM file not found
            OpenZimMcpArchiveError: If browsing fails
        """
        return _json(
            self.browse_namespace_data(zim_file_path, namespace, limit, offset)
        )

    def _browse_namespace_entries(  # NOSONAR(python:S3776)
        self,
        archive: Archive,
        namespace: str,
        limit: int,
        offset: int,
        archive_path: Optional[str] = None,
        *,
        include_assets: bool = False,
    ) -> Dict[str, Any]:
        """Browse entries in a specific namespace using sampling and search.

        ``archive_path`` enables caching the full namespace listing per
        ``(archive_path, namespace)`` so successive page requests do not
        re-scan the archive. When omitted (legacy callers / tests), the
        listing is recomputed every call.
        """
        entries: List[Dict[str, Any]] = []

        # Check if archive uses new namespace scheme
        has_new_scheme = getattr(archive, "has_new_namespace_scheme", False)

        # Fast path: new-scheme + C namespace. Every iterable entry in a
        # new-scheme archive lives under C, so we don't need to enumerate
        # a list of "C entries" — we can pull each page directly from
        # the entry-id range. This avoids the 27M-iteration crash that
        # the legacy "build full list then slice" path triggered on
        # Wikipedia (D2): walking every entry to build a list we
        # immediately slice 50 rows out of is both pathologically slow
        # and memory-hostile. The total is ``archive.entry_count``,
        # which libzim returns in O(1).
        if has_new_scheme and namespace == "C":
            return self._browse_new_scheme_c_paginated(
                archive, namespace, limit, offset, include_assets=include_assets
            )
        # Fast path: new-scheme + W namespace. libzim doesn't surface W
        # through the iterable surface, but the well-known entries
        # (mainPage, favicon) ARE reachable by ``has_entry_by_path``.
        # Probing the known paths recovers the W namespace's actual
        # contents (D3) instead of the legacy empty result.
        if has_new_scheme and namespace == "W":
            return self._browse_new_scheme_w_paginated(
                archive, namespace, limit, offset
            )
        # Every remaining spec-legal letter (I, X, A, -, B, J, U, V) is a
        # namespace a new-scheme archive simply does not expose: C holds
        # every iterable entry, M is reached through the metadata API and W
        # through the probes above. The empty listing is the CORRECT answer
        # — but it used to be published as
        # ``discovery_method: "full_iteration"``, a provenance claim for a
        # scan that never ran, alongside ``results_may_be_incomplete: false``
        # and no reason code. A model asking "does this archive have images"
        # got a maximally confident zero in 3 ms with nothing pointing at
        # ``include_assets=True`` under C, where the images actually live.
        # Name the real reason; keep the (correct) zero.
        if has_new_scheme and namespace != "M":
            return {
                "namespace": namespace,
                "total_in_namespace": 0,
                "total_in_namespace_is_lower_bound": False,
                "offset": offset,
                "limit": limit,
                "returned_count": 0,
                "scanned_count": 0,
                "entries": [],
                "sampling_based": False,
                "discovery_method": "not_iterable",
                "is_total_authoritative": True,
                "results_may_be_incomplete": False,
            }

        # Discover entries in the namespace. The full listing is cached
        # separately from the per-page JSON (cache_key in browse_namespace),
        # so different (limit, offset) pages share one scan. The stat
        # token (st_mtime_ns:st_size) ensures an atomic ZIM replacement
        # invalidates the listing rather than serving the prior
        # snapshot's entries indefinitely until LRU eviction.
        listing_key: Optional[str] = None
        cached_listing: Optional[Tuple[List[str], bool]] = None
        if archive_path is not None:
            from openzim_mcp.bundle import archive_stat_token

            stat_token = archive_stat_token(Path(archive_path))
            listing_key = f"ns_entries:{archive_path}:{stat_token}:{namespace}"
            cached_listing = self.cache.get(listing_key)

        if cached_listing is not None:
            namespace_entries, full_iteration = cached_listing
        else:
            namespace_entries, full_iteration = self._find_entries_in_namespace(
                archive, namespace, has_new_scheme
            )
            if listing_key is not None:
                self.cache.set(listing_key, (namespace_entries, full_iteration))

        # Apply pagination
        total_in_namespace = len(namespace_entries)
        start_idx = offset
        end_idx = min(offset + limit, total_in_namespace)
        paginated_entries = namespace_entries[start_idx:end_idx]

        # Get detailed information for paginated entries
        for entry_path in paginated_entries:
            try:
                materialised = self._materialise_browse_entry(
                    archive, entry_path, has_new_scheme
                )
                if materialised is not None:
                    entries.append(materialised)
            except Exception as e:
                logger.warning(f"Error processing entry {entry_path}: {e}")
                continue

        # ``next_cursor`` and ``has_more`` are intentionally omitted here.
        # ``browse_namespace_data`` (the sole caller) rebuilds both fields
        # itself using ``Cursor.encode(tool="browse_namespace", ...)``.

        # A sampled listing is incomplete, full stop. The predicate used to
        # read ``total_in_namespace >= NAMESPACE_MAX_ENTRIES``, so it could
        # only ever trip when the sample saturated the 200-row cap: every
        # sampled bucket smaller than that self-certified as exhaustive.
        # On the old-scheme zim-testing-suite archive that made browse
        # report M as 6 entries, ``done: true``,
        # ``results_may_be_incomplete: false`` — while walk on the same
        # server returned all 12. ``results_may_be_incomplete`` is the
        # plainest-English completeness field in the payload and must agree
        # with its siblings (``sampling_based``, ``discovery_method``,
        # ``page_info.total_is_lower_bound``), which all already said
        # "sampled". Full iteration still reports False.
        results_may_be_incomplete = not full_iteration

        result = {
            "namespace": namespace,
            "total_in_namespace": total_in_namespace,
            # When sampling-based, ``total_in_namespace`` is the size of the
            # sampled listing — the real namespace may contain more entries.
            # Mirror that through a positively-named flag so callers don't
            # have to invert ``is_total_authoritative`` mentally.
            "total_in_namespace_is_lower_bound": not full_iteration,
            "offset": offset,
            "limit": limit,
            "returned_count": len(entries),
            # Candidate rows consumed from the listing window — the resume
            # offset in ``browse_namespace_data`` counts these, not the
            # (possibly smaller) number of rows that survived materialisation.
            "scanned_count": len(paginated_entries),
            "entries": entries,
            "sampling_based": not full_iteration,
            "discovery_method": "full_iteration" if full_iteration else "sampling",
            "is_total_authoritative": full_iteration,
            "results_may_be_incomplete": results_may_be_incomplete,
        }

        return result

    def _materialise_paths(
        self, archive: Archive, paths: List[str], *, log_label: str
    ) -> List[Dict[str, Any]]:
        """Run ``_materialise_browse_entry`` for each path, swallowing errors.

        Shared between the new-scheme C / W paginators — both materialise
        an already-known list of paths into the row dicts that
        ``browse_namespace_data`` expects. ``log_label`` lets the warning
        path identify which caller (C-range vs W-probe) produced the
        failure for diagnostics.
        """
        out: List[Dict[str, Any]] = []
        for entry_path in paths:
            try:
                materialised = self._materialise_browse_entry(
                    archive, entry_path, has_new_scheme=True
                )
                if materialised is not None:
                    out.append(materialised)
            except Exception as e:
                logger.warning(f"Error processing {log_label} entry {entry_path}: {e}")
                continue
        return out

    @staticmethod
    def _new_scheme_browse_payload(
        *,
        namespace: str,
        total: int,
        offset: int,
        limit: int,
        entries: List[Dict[str, Any]],
        discovery_method: str,
    ) -> Dict[str, Any]:
        """Build the v2 Phase B browse-namespace inner payload shape.

        Both the entry-id-range fast path (C) and the known-path probe (W)
        report ``archive.entry_count`` as the total. The C path now skips
        non-article assets (images / css / js / fonts / media), so the
        navigable count is at or below ``entry_count`` — we keep reporting
        ``entry_count`` as the (authoritative) total rather than invert the
        ``lower_bound`` flag, which means "true count is at least this" and
        would be backwards here. ``done`` is derived from scan-exhaustion, so
        pagination still terminates correctly; the only cosmetic effect is that
        a media-rich archive reaches ``done`` before ``returned == total``.
        """
        return {
            "namespace": namespace,
            "total_in_namespace": total,
            "total_in_namespace_is_lower_bound": False,
            "offset": offset,
            "limit": limit,
            "returned_count": len(entries),
            "entries": entries,
            "sampling_based": False,
            "discovery_method": discovery_method,
            "is_total_authoritative": True,
            "results_may_be_incomplete": False,
        }

    def _browse_new_scheme_c_paginated(
        self,
        archive: Archive,
        namespace: str,
        limit: int,
        offset: int,
        *,
        include_assets: bool = False,
    ) -> Dict[str, Any]:
        """Page through new-scheme C-namespace entries by entry-id range.

        New-scheme archives store every iterable entry under C, so we page
        directly over the entry-id range rather than building a 27M-item list
        and slicing it (the legacy approach that triggered "session expired"
        crashes on real Wikipedia archives, D2).

        New-scheme archives also store non-article assets under C — ZIMIT
        ``_zim_static`` infra (wombat.js + the MathJax font set), plus images /
        css / fonts / media — so a plain ``[offset, offset+limit)`` slice
        surfaced them as page 1. We now SCAN-FILL: ``offset`` is reinterpreted
        as an entry-id scan position, ``_is_non_article_target`` assets are
        skipped (``.html`` / ``.htm`` are kept as articles), and we keep
        scanning until the page holds ``limit`` real rows or the range is
        exhausted. ``next_scan_offset`` (the first unscanned id) and
        ``scan_exhausted`` are returned so ``browse_namespace_data`` can encode
        a resume cursor that survives filtering — ``offset + returned_count``
        would drift once matched-rows < ids-scanned.
        """
        total = int(getattr(archive, "entry_count", 0) or 0)

        def _get_path(scan_id: int) -> Tuple[Optional[str], Optional[str]]:
            try:
                entry = archive._get_entry_by_id(scan_id)
                return str(entry.path), _entry_mimetype(entry)
            except Exception as e:
                logger.warning(f"Error reading entry id {scan_id}: {e}")
                return None, None

        page_paths, next_row_offset, scan_exhausted, assets_skipped = (
            _scan_fill_c_namespace(
                total,
                _get_path,
                self._is_non_article_target,
                limit,
                offset,
                include_assets=include_assets,
            )
        )
        payload = self._new_scheme_browse_payload(
            namespace=namespace,
            total=total,
            offset=offset,
            limit=limit,
            entries=self._materialise_paths(
                archive, page_paths, log_label="C-namespace"
            ),
            discovery_method="entry_id_range",
        )
        # ``offset`` is a content-row offset, so the resume position is the
        # next row offset (``offset + rows returned``) — consistent with the
        # raw-``offset`` contract so ``offset += limit`` paging advances by
        # real rows instead of stalling on a raw entry-id scan position.
        payload["next_row_offset"] = next_row_offset
        payload["scan_exhausted"] = scan_exhausted
        # Count ONLY genuine asset skips (not read errors / materialise drops)
        # so the surfaced ``assets_filtered`` flag means exactly what it says.
        payload["assets_filtered"] = assets_skipped > 0
        return payload

    # Well-known W-namespace paths in new-scheme archives. The
    # ``has_entry_by_path`` probe is unreliable here — most Wikipedia
    # ZIMs return False for ``W/mainPage`` even when ``archive.main_entry``
    # resolves correctly, because the main page is stored under its
    # canonical C-namespace path and exposed via libzim's well-known-entry
    # APIs rather than as a literal ``W/`` entry. Auxiliary probes
    # (``W/index``, ``W/robots.txt`` etc.) cover archives that DO carry
    # extra well-known entries directly.
    _NEW_SCHEME_W_AUX_CANDIDATES = (
        "W/index",
        "W/robots.txt",
        "W/exception.html",
        "W/404.html",
    )

    def _browse_new_scheme_w_paginated(
        self,
        archive: Archive,
        namespace: str,
        limit: int,
        offset: int,
    ) -> Dict[str, Any]:
        """Enumerate new-scheme W-namespace entries via the same probes
        ``list_namespaces`` uses.

        D2 (v2.0.0a9): the original D3 fix probed
        ``archive.has_entry_by_path("W/mainPage")`` etc., which returns
        False on real Wikipedia archives even when the main entry
        exists — the path isn't a literal entry, it's a well-known
        alias resolved via ``archive.main_entry``. The result was
        ``list_namespaces`` reporting W=2 and ``browse_namespace W``
        reporting empty, with no way for a small model to reconcile.

        This rewrite asks the SAME questions ``list_namespaces`` does
        (``has_main_entry``, ``has_illustration()``) and synthesises
        the corresponding ``W/mainPage`` / ``W/favicon`` rows. Auxiliary
        candidates (``W/index``, ``W/robots.txt``) still get the
        ``has_entry_by_path`` probe because they ARE stored as literal
        entries when present.
        """
        present: List[str] = []
        # Synthetic well-known entries — resolved through libzim's
        # dedicated APIs at materialisation time, not by path lookup.
        try:
            if getattr(archive, "has_main_entry", False):
                present.append("W/mainPage")
        except Exception as e:
            logger.debug(f"has_main_entry probe failed: {e}")
        try:
            if archive.has_illustration():
                present.append("W/favicon")
        except Exception as e:
            logger.debug(f"has_illustration probe failed: {e}")
        # Auxiliary literal W entries — when present they ARE addressable
        # by path. Wikipedia maxi ZIMs rarely carry these but other
        # ZIM flavours (e.g. some scraped sites) do.
        for path in self._NEW_SCHEME_W_AUX_CANDIDATES:
            try:
                if archive.has_entry_by_path(path):
                    present.append(path)
            except Exception as e:
                logger.debug(f"has_entry_by_path probe failed for {path}: {e}")
        payload = self._new_scheme_browse_payload(
            namespace=namespace,
            total=len(present),
            offset=offset,
            limit=limit,
            entries=self._materialise_paths(
                archive, present[offset : offset + limit], log_label="W-namespace"
            ),
            discovery_method="known_path_probe",
        )
        # Resume by CANDIDATE rows consumed, not survivors: a row that drops
        # during materialisation must still advance the cursor, or a dropped
        # row is re-scanned every page (duplicates when a survivor shares the
        # window; a never-advancing cursor when the whole window drops).
        payload["scanned_count"] = len(present[offset : offset + limit])
        return payload

    def _materialise_browse_entry(
        self, archive: Archive, entry_path: str, has_new_scheme: bool
    ) -> Optional[Dict[str, Any]]:
        """Render one browse_namespace row for ``entry_path``.

        New-scheme metadata entries (paths shaped ``M/<key>``) aren't on
        libzim's regular entry surface — they're reached via
        ``archive.get_metadata_item``. Without this branch a new-scheme
        ``browse_namespace('M', ...)`` would error on every row.

        Synthetic ``W/mainPage`` / ``W/favicon`` rows (D2) similarly
        route through dedicated libzim well-known-entry APIs because
        those paths aren't literal entries on most new-scheme archives.
        """
        if has_new_scheme and entry_path.startswith("M/"):
            return self._materialise_new_scheme_metadata_entry(archive, entry_path)
        if has_new_scheme and entry_path == "W/mainPage":
            return self._materialise_new_scheme_main_entry(archive)
        if has_new_scheme and entry_path == "W/favicon":
            return self._materialise_new_scheme_favicon(archive)

        entry = archive.get_entry_by_path(entry_path)
        title = entry.title or entry_path
        preview, content_type = self._render_entry_preview(entry, entry_path)
        return {
            "path": entry_path,
            "title": title,
            "content_type": content_type,
            "preview": preview,
        }

    def _materialise_new_scheme_main_entry(
        self, archive: Archive
    ) -> Optional[Dict[str, Any]]:
        """Render the synthetic ``W/mainPage`` row.

        Resolves through ``archive.main_entry`` (libzim's well-known
        entry API) — the canonical target may live anywhere in C, so
        we render its actual path/title rather than a synthetic
        placeholder. Following the redirect chain is intentional: the
        ``main_entry`` value is typically a redirect to the actual
        landing page.
        """
        try:
            entry = archive.main_entry
        except Exception as e:
            logger.debug(f"main_entry resolution failed: {e}")
            return None
        # Follow the redirect chain so the rendered row points at the
        # actual page rather than the redirect stub. Best-effort: a stale
        # redirect on a partially-rewritten archive degrades to the last
        # good entry rather than failing the whole main-page lookup.
        entry = best_effort_redirect_chain(entry)
        title = getattr(entry, "title", None) or "Main Page"
        try:
            preview, content_type = self._render_entry_preview(entry, "W/mainPage")
        except Exception:
            preview, content_type = "", "text/html"
        return {
            "path": "W/mainPage",
            "title": title,
            "content_type": content_type,
            "preview": preview,
        }

    @staticmethod
    def _materialise_new_scheme_favicon(
        archive: Archive,
    ) -> Optional[Dict[str, Any]]:
        """Render the synthetic ``W/favicon`` row.

        Pulls the illustration item's mimetype via
        ``archive.get_illustration_item`` without dereferencing the
        bytes — favicons can be tens of KB and rendering them as a
        preview adds nothing useful.
        """
        content_type = "image/png"
        try:
            item = archive.get_illustration_item(48)
            if item and item.mimetype:
                content_type = item.mimetype
        except Exception as e:
            logger.debug(f"get_illustration_item failed: {e}")
        return {
            "path": "W/favicon",
            "title": "favicon",
            "content_type": content_type,
            "preview": "(archive favicon)",
        }

    def _materialise_new_scheme_metadata_entry(
        self, archive: Archive, entry_path: str
    ) -> Optional[Dict[str, Any]]:
        key = entry_path.split("/", 1)[1] if "/" in entry_path else entry_path
        try:
            item = archive.get_metadata_item(key)
        except Exception as e:
            logger.debug(f"get_metadata_item failed for {key}: {e}")
            return None
        content_type = (item.mimetype or "unknown") if item else "unknown"
        preview = ""
        try:
            if item and item.mimetype and item.mimetype.startswith("text/"):
                raw = bytes(item.content)
                preview = self.content_processor.create_snippet(
                    self.content_processor.process_mime_content(raw, item.mimetype),
                    max_paragraphs=1,
                )
            elif item:
                preview = f"({content_type} content)"
        except Exception as e:
            logger.debug(f"metadata preview failed for {key}: {e}")
            preview = "(Preview unavailable)"
        return {
            "path": entry_path,
            "title": key,
            "content_type": content_type,
            "preview": preview,
        }

    def _render_entry_preview(self, entry: Any, entry_path: str) -> Tuple[str, str]:
        """Return (preview_text, content_type) for a regular entry.

        The render is scoped to the page's main-content landmark, exactly
        as the search-snippet path does (:meth:`_ContentMixin.
        get_content_snippet`). warc2zim / ZIMIT scrapes keep the site
        chrome — cookie banner, masthead, in-page nav — OUTSIDE the
        ``<article>`` landmark, so an unscoped render hands
        ``create_snippet`` the banner as the document's first paragraph:
        on a MedlinePlus scrape every browse row previewed as "An
        official website of the United States government", and on an IEP
        scrape every row previewed as ``""`` (its lead paragraph is the
        bare site-logo link, which ``_strip_snippet_render_junk``
        empties). ``preview`` and ``content_type`` are the only two
        fields page mode adds over walk mode, so a constant preview made
        the whole per-row render cost buy nothing — and made every row
        look identical to a ranker.

        With no landmark ``select_main_content`` returns the whole
        document, so chrome-free (Wikipedia / mwoffliner) archives render
        exactly as before.

        The entry title is passed to ``create_snippet`` for the same
        reason the search path passes it: the scoped body opens with the
        page's ``<h1>``, and the row already carries that text in its
        ``title`` field, so repeating it would spend the preview budget
        on the row header.

        The snippet is capped at ``_PREVIEW_MAX_CHARS`` rather than the
        configured ``snippet_length`` (3000 by default). A browse row is
        an orientation aid, not a read: at the configured length a
        50-row page of long scholarly articles rendered 30-40 KB of lead
        paragraphs. The cap keeps a page the size it was when the field
        was boilerplate, but spends it on the article.
        """
        try:
            item = entry.get_item()
            content_type = item.mimetype or "unknown"
            if item.mimetype and item.mimetype.startswith("text/"):
                content = self.content_processor.process_mime_content(
                    bytes(item.content), item.mimetype, scope_main_content=True
                )
                preview = self.content_processor.create_snippet(
                    content,
                    max_paragraphs=1,
                    title=getattr(entry, "title", None) or "",
                    snippet_length=min(
                        self.content_processor.snippet_length, _PREVIEW_MAX_CHARS
                    ),
                )
            else:
                preview = f"({content_type} content)"
            return preview, content_type
        except Exception as e:
            logger.debug(f"Error getting preview for {entry_path}: {e}")
            return "(Preview unavailable)", ""

    def _find_entries_in_namespace(
        self, archive: Archive, namespace: str, has_new_scheme: bool
    ) -> Tuple[List[str], bool]:
        """Find entries in a specific namespace.

        Returns ``(sorted_paths, full_iteration)`` where ``full_iteration`` is
        True when every entry in the archive was inspected (so the result is
        exhaustive). For larger archives, falls back to a systematic sample of
        entry ids and returns False — counts/paths are then a lower bound.

        New-scheme dispatch: M is enumerated from ``archive.metadata_keys``
        (full iteration, exhaustive); namespaces other than C/M return empty
        because libzim's iterable surface only exposes C in this scheme.
        """
        if has_new_scheme:
            if namespace == "M":
                paths = self._enumerate_new_scheme_metadata(archive)
                return sorted(paths), True
            if namespace != "C":
                # Other namespaces (W, X, etc.) aren't on the iterable surface;
                # return empty rather than path-prefix-matching them into
                # nonsense buckets.
                return [], True
            # New-scheme + C: every iterable entry is in C, so full iteration
            # is the right call regardless of archive size. Sampling here was
            # wasteful (same per-entry cost) and produced misleading
            # ``total_in_namespace`` values capped at the sample size.
            entries = self._enumerate_namespace_entries(
                archive, namespace, archive.entry_count, has_new_scheme=True
            )
            return sorted(entries), True

        total_entries = archive.entry_count

        # Full iteration is exhaustive and far more accurate than sampling for
        # small archives. The threshold mirrors _list_archive_namespaces.
        if total_entries <= NAMESPACE_MAX_SAMPLE_SIZE:
            entries = self._enumerate_namespace_entries(
                archive, namespace, total_entries, has_new_scheme=has_new_scheme
            )
            return sorted(entries), True

        sampled, seen = self._sample_namespace_entries(
            archive, namespace, has_new_scheme=has_new_scheme
        )
        self._extend_with_pattern_probes(
            archive, namespace, sampled, seen, has_new_scheme=has_new_scheme
        )
        return sorted(sampled), False

    @staticmethod
    def _enumerate_new_scheme_metadata(archive: Archive) -> List[str]:
        """Build M/<key> paths from archive.metadata_keys for new-scheme.

        P3-D3 (live-MCP sweep): apply the same
        ``is_human_readable_metadata_key`` filter that
        ``_add_new_scheme_metadata_namespace`` and the M-walker already
        use. Without this, ``browse namespace M`` reported 13 entries
        (including the binary ``Illustration_*`` entry) while
        ``list namespaces`` / ``walk namespace M`` /
        ``metadata for <file>`` all reported 12 — same aggregator-
        disagreement family as the post-a10 / post-a11 sweeps.
        """
        try:
            raw_keys = list(getattr(archive, "metadata_keys", []) or [])
        except Exception as e:
            logger.debug(f"Unable to read metadata_keys: {e}")
            return []
        keys = [k for k in raw_keys if is_human_readable_metadata_key(k)]
        return [f"M/{k}" for k in keys]

    def _enumerate_namespace_entries(
        self,
        archive: Archive,
        namespace: str,
        total_entries: int,
        has_new_scheme: bool = False,
    ) -> List[str]:
        """Walk every entry id and keep those that fall under ``namespace``."""
        logger.debug(
            f"Iterating all {total_entries} entries to enumerate namespace "
            f"'{namespace}'"
        )
        seen: set[str] = set()
        results: List[str] = []
        for entry_id in range(total_entries):
            try:
                entry = archive._get_entry_by_id(entry_id)
                path = entry.path
                if path in seen:
                    continue
                seen.add(path)
                if (
                    self._extract_namespace_from_path(
                        path, has_new_scheme=has_new_scheme
                    )
                    == namespace
                ):
                    results.append(path)
            except Exception as e:
                logger.debug(f"Error reading entry {entry_id}: {e}")
        logger.info(
            f"Found {len(results)} entries in namespace '{namespace}' via full "
            f"iteration of {total_entries} entries"
        )
        return results

    def _sample_namespace_entries(
        self, archive: Archive, namespace: str, has_new_scheme: bool = False
    ) -> Tuple[List[str], set[str]]:
        """Sample entry ids until ``NAMESPACE_MAX_ENTRIES`` matches are found.

        Uses the same systematic walk as the ``list_namespaces`` sampler
        (:func:`_deterministic_sample_ids`), for the same two reasons:

        * **agreement.** ``get_random_entry`` draws from the *article*
          index, so on an archive whose articles all live in ``A`` this
          function could never return an ``I`` or ``-`` entry however many
          draws it took — while ``list_namespaces``, which walks entry ids,
          reports both. Two tools describing the same archive differently
          is worse than either being imprecise.
        * **determinism.** ``browse_namespace`` is cached and paginated;
          a sample that re-rolls on every call hands page 2 a different
          population than page 1.

        The returned ``total`` is still a lower bound (capped at
        ``NAMESPACE_MAX_ENTRIES``), which is what
        ``page_info.total_is_lower_bound`` advertises.
        """
        total_entries = archive.entry_count
        max_samples = min(NAMESPACE_MAX_SAMPLE_SIZE * 2, total_entries)
        logger.debug(f"Sampling for entries in namespace '{namespace}'")

        results: List[str] = []
        seen: set[str] = set()
        entry_ids = _deterministic_sample_ids(
            total_entries, max_samples, _archive_sample_seed(archive)
        )
        attempts = 0
        for entry_id in entry_ids:
            if len(results) >= NAMESPACE_MAX_ENTRIES:
                break
            attempts += 1
            try:
                path = archive._get_entry_by_id(entry_id).path
                if path in seen:
                    continue
                seen.add(path)
                if (
                    self._extract_namespace_from_path(
                        path, has_new_scheme=has_new_scheme
                    )
                    == namespace
                ):
                    results.append(path)
            except Exception as e:
                logger.debug(f"Error sampling entry {entry_id}: {e}")

        logger.info(
            f"Found {len(results)} entries in namespace '{namespace}' "
            f"after {attempts} samples"
        )
        return results, seen

    def _extend_with_pattern_probes(
        self,
        archive: Archive,
        namespace: str,
        results: List[str],
        seen: set[str],
        has_new_scheme: bool = False,
    ) -> None:
        """Append entries from canonical-pattern probes to the sampled list.

        The pattern list contains both namespace-prefixed paths (e.g.
        ``C/index.html``) and bare paths (e.g. ``index.html``); the latter
        live in *some other* namespace, so we must verify membership before
        appending.
        """
        for pattern in self._get_common_namespace_patterns(namespace):
            try:
                if (
                    archive.has_entry_by_path(pattern)
                    and pattern not in seen
                    and self._extract_namespace_from_path(
                        pattern, has_new_scheme=has_new_scheme
                    )
                    == namespace
                ):
                    results.append(pattern)
                    seen.add(pattern)
            except Exception as e:
                logger.debug(f"Error checking pattern {pattern}: {e}")

    def _get_common_namespace_patterns(self, namespace: str) -> List[str]:
        """Get common path patterns for a namespace.

        Seeded with the canonical probes ``list_namespaces`` uses, so a
        namespace that tool surfaces by probe alone (``X`` is found via
        ``X/fulltext/xapian``, which is not in the browse-specific list
        below) is never advertised as non-empty by one tool and reported
        empty by the other.
        """
        patterns = [
            probe
            for probe in self._get_known_namespace_probes()
            if probe.split("/", 1)[0] == namespace
        ]

        # Common patterns based on namespace
        if namespace == "C":
            patterns.extend(
                [
                    "index.html",
                    "main.html",
                    "home.html",
                    "C/index.html",
                    "C/main.html",
                    "content/index.html",
                ]
            )
        elif namespace == "M":
            patterns.extend(
                [
                    "M/Title",
                    "M/Description",
                    "M/Language",
                    "M/Creator",
                    "metadata/title",
                    "metadata/description",
                ]
            )
        elif namespace == "W":
            patterns.extend(
                [
                    "W/mainPage",
                    "W/favicon",
                    "W/navigation",
                    "wellknown/mainPage",
                    "wellknown/favicon",
                ]
            )
        elif namespace == "X":
            patterns.extend(
                ["X/fulltext", "X/title", "X/search", "search/fulltext", "index/title"]
            )
        elif namespace == "A":
            patterns.extend(["A/index.html", "A/main.html", "A/home.html"])
        elif namespace == "I":
            patterns.extend(["I/favicon.png", "I/logo.png", "I/image.jpg"])

        # The two lists overlap (M/Title, I/favicon.png, ...); de-duplicate
        # so a caller doesn't pay for the same has_entry_by_path twice.
        return list(dict.fromkeys(patterns))

    def walk_namespace_data(
        self,
        zim_file_path: str,
        namespace: str,
        cursor_state: Optional[Dict[str, Any]] = None,
        limit: int = 200,
        *,
        include_assets: bool = False,
    ) -> "WalkNamespaceResponse":
        """Structured variant of ``walk_namespace``.

        Returns the result dict directly (not a JSON string) so MCP tools
        can hand it straight to the SDK's structured-content path.

        Phase B contract: top-level ``results`` / ``next_cursor`` (opaque
        str) / ``total`` (always None — walk doesn't know the per-namespace
        total mid-scan) / ``done`` / ``page_info`` plus ``namespace`` /
        ``scanned_count`` / ``scanned_through_id`` / ``archive_entry_count``
        extras. ``next_cursor`` is encoded with ``tool="walk_namespace"``
        and state ``{scan_at, l}``.

        ``cursor_state`` carries the decoded ``s`` dict from a v2 cursor.
        The tool layer is responsible for decoding the opaque wire token;
        this method works with the decoded shape directly so non-tool
        callers (legacy ``walk_namespace`` JSON wrapper, simple_tools)
        don't have to round-trip through base64.

        Raises:
            OpenZimMcpValidationError: If ``limit`` is outside ``1..500``.
        """
        from openzim_mcp.pagination import Cursor

        # Caller-input validation surfaces as OpenZimMcpValidationError so
        # the tool layer can render a targeted validation message and so
        # other call sites (e.g. simple_tools) can distinguish it from
        # archive-access failures.
        if limit < 1 or limit > 500:
            raise OpenZimMcpValidationError(
                f"limit must be between 1 and 500 (provided: {limit})"
            )

        # Decoded cursor state ``s`` for walk_namespace carries
        # ``{scan_at: int, l: int, ns: str, ai: str}``. ``scan_at``/``l``
        # are positional, ``ns``/``ai`` are integrity-check fields added
        # in cursor v2.
        scan_at_raw = (cursor_state or {}).get("scan_at", 0)
        try:
            scan_at = int(scan_at_raw)
        except (TypeError, ValueError):
            scan_at = 0
        if scan_at < 0:
            scan_at = 0

        # Canonicalise user input (e.g. "c" -> "C") so the comparison
        # against ``_extract_namespace_from_path`` (canonical form) does
        # not silently iterate to completion with zero matches.
        if namespace:
            namespace = self._canonicalise_namespace(namespace.strip())

        # Fast-reject unknown namespace letters with the SAME signal
        # ``browse_namespace_data`` uses (``reason="bad_namespace"``). Pre-fix
        # walk treated an unknown letter (``Z``) as a valid-but-empty
        # namespace while browse rejected it, so the two siblings disagreed
        # on whether the letter was legal.
        if namespace not in _KNOWN_NAMESPACE_LETTERS:
            return cast(
                "WalkNamespaceResponse",
                attach_meta(
                    self._build_walk_result(
                        namespace=namespace,
                        scan_at=scan_at,
                        limit=limit,
                        entries=[],
                        scanned_count=0,
                        scanned_through_id=None,
                        done=True,
                        next_cursor=None,
                        archive_entry_count=0,
                        namespace_entry_count=0,
                    ),
                    reason="bad_namespace",
                ),
            )

        validated = self._validate_zim_path(zim_file_path)

        # Cursor integrity: a v2 cursor encodes the namespace it was
        # issued for and the archive identity. Rejecting on mismatch
        # prevents silent wrong-result bugs where a caller resubmits a
        # cursor against a different namespace or different archive
        # (issues Phase B #10, #17, #11 for the equivalent pattern in
        # extract_article_links).
        if cursor_state:
            from openzim_mcp.pagination import Cursor as _CursorClass
            from openzim_mcp.pagination import (
                CursorMismatchError,
                archive_identity,
            )

            cursor_ns = cursor_state.get("ns")
            if cursor_ns is not None and cursor_ns != namespace:
                raise OpenZimMcpValidationError(
                    f"Cursor was issued for namespace {cursor_ns!r}; "
                    f"call passed namespace={namespace!r}. Drop the cursor "
                    f"and start the walk over for the new namespace."
                )
            # H16: always verify ``ai``. The old ``if "ai" in cursor_state``
            # guard skipped the check when a cursor lacked the field — but
            # v=2 cursors always carry ``ai``, so the only way to miss it
            # is a hand-crafted (or v=1, now rejected by Cursor.decode)
            # token. ``verify_archive_identity`` itself raises a clear
            # ``CursorMismatchError`` on absent ``ai``; relying on that
            # makes the cross-archive guard unconditional.
            try:
                _CursorClass.verify_archive_identity(
                    cast("Any", cursor_state),
                    expected=archive_identity(validated),
                    tool="walk_namespace",
                )
            except CursorMismatchError as e:
                raise OpenZimMcpValidationError(str(e)) from e

        try:
            with _zim_ops_mod.zim_archive(validated) as archive:
                has_new_scheme = getattr(archive, "has_new_namespace_scheme", False)

                archive_entry_count = archive.entry_count

                # New-scheme M is sourced from metadata_keys, not the entry
                # iterator (which only surfaces C). Hand the request to a
                # dedicated walker so callers see real metadata entries
                # instead of zero matches after a full archive scan.
                if has_new_scheme and namespace == "M":
                    return cast(
                        "WalkNamespaceResponse",
                        attach_meta(
                            self._walk_new_scheme_metadata(
                                archive,
                                scan_at,
                                limit,
                                archive_entry_count,
                                validated_path=validated,
                            )
                        ),
                    )
                # D8 (beta): symmetric handling for W namespace. The
                # well-known entries (mainPage, favicon) are reachable via
                # ``archive.main_entry`` / ``archive.has_illustration()``
                # — not the iterable surface that ``walk_namespace_data``
                # falls back to below. Without this branch, ``walk
                # namespace W`` returned an empty result while the
                # sibling ``list namespaces`` operation simultaneously
                # advertised W has 2 entries (via the same probes used
                # here in ``_add_new_scheme_well_known_namespace``).
                # The two ops were contradicting each other on the same
                # archive — now they agree.
                if has_new_scheme and namespace == "W":
                    return cast(
                        "WalkNamespaceResponse",
                        attach_meta(
                            self._walk_new_scheme_well_known(
                                archive,
                                scan_at,
                                limit,
                                archive_entry_count,
                                validated_path=validated,
                            )
                        ),
                    )
                # Other-than-C namespaces in new-scheme aren't on the
                # iterable surface; short-circuit so callers don't pay the
                # full-archive scan to discover that.
                if has_new_scheme and namespace != "C":
                    # A15 post-a15: pass ``namespace_entry_count=0`` so
                    # the short-circuited empty result has the same
                    # schema as the M / W walks (which surface their
                    # bounded totals). Without this the field is
                    # omitted entirely, forcing downstream consumers
                    # to special-case "missing" vs "zero" — a schema-
                    # consistency defect surfaced by ``walk namespace
                    # A`` against a new-scheme Wikipedia archive.
                    return cast(
                        "WalkNamespaceResponse",
                        attach_meta(
                            self._build_walk_result(
                                namespace=namespace,
                                scan_at=scan_at,
                                limit=limit,
                                entries=[],
                                scanned_count=0,
                                scanned_through_id=None,
                                done=True,
                                next_cursor=None,
                                archive_entry_count=archive_entry_count,
                                namespace_entry_count=0,
                            )
                        ),
                    )

                entries: List[Dict[str, Any]] = []
                entry_id = scan_at
                # Non-article asset filter applies ONLY to the new-scheme C
                # surface, where every iterable entry (articles AND ZIMIT
                # ``_zim_static`` infra, images, css, fonts, media) lives under
                # C. Old-scheme or non-C walks (e.g. the ``I`` image namespace)
                # must still surface their assets, so they are never filtered.
                filter_assets = has_new_scheme and namespace == "C"
                # Count what the filter withheld. Both numbers a walk page
                # carries that could serve as a denominator
                # (``archive_entry_count`` and, for new-scheme C,
                # ``namespace_entry_count``) describe the UNFILTERED
                # surface, so an exhaustive walk that ended
                # ``done=True, next_cursor=None`` having returned 1,733 of
                # a stated 3,178 entries read as truncated or lossy — with
                # nothing in the payload naming the 1,445 filtered assets.
                # Page mode has emitted ``page_info.assets_filtered`` since
                # the filter landed; the signal simply never reached walk.
                assets_skipped = 0
                while entry_id < archive_entry_count and len(entries) < limit:
                    try:
                        entry = archive._get_entry_by_id(entry_id)
                        path = entry.path
                        if (
                            self._extract_namespace_from_path(
                                path, has_new_scheme=has_new_scheme
                            )
                            == namespace
                        ):
                            if (
                                filter_assets
                                and not include_assets
                                and self._is_non_article_target(
                                    path, _entry_mimetype(entry)
                                )
                            ):
                                assets_skipped += 1
                            else:
                                entries.append(
                                    {
                                        "path": path,
                                        "title": entry.title or path,
                                    }
                                )
                    except Exception as e:
                        logger.debug(f"walk_namespace: entry {entry_id} skipped: {e}")
                    entry_id += 1

                done = entry_id >= archive_entry_count
                # scanned_through_id reflects the last ID we examined regardless
                # of whether it matched the filter. None if we never entered the
                # loop (scan_at was already at/past the end).
                scanned_through_id = entry_id - 1 if entry_id > scan_at else None
                next_cursor: Optional[str] = None
                if not done:
                    from openzim_mcp.pagination import archive_identity

                    # P3-D2 (live-MCP sweep): use ``s.o`` on the wire so
                    # the universal top-level cursor decoder accepts the
                    # cursor we just issued. ``scan_at`` is the internal
                    # libzim entry-id semantics; the dispatcher in
                    # simple_tools.py maps offset back into the
                    # ``scan_at`` key on cursor_state before calling
                    # walk_namespace_data.
                    # ``as`` pins asset visibility so an exhaustive walk
                    # resumed from its own cursor keeps surfacing the same
                    # row stream instead of silently switching filters
                    # mid-scan (same contract as the browse cursor).
                    next_cursor = Cursor.encode(
                        tool="walk_namespace",
                        state=cast(
                            "Any",
                            {
                                "o": entry_id,
                                "l": limit,
                                "ns": namespace,
                                "as": include_assets,
                                "ai": archive_identity(validated),
                            },
                        ),
                    )

                # A11 post-a11 M3: surface a per-namespace denominator
                # for new-scheme C as well. M / W already plumb their
                # bounded totals (metadata_keys length / well-known
                # probe pair); for new-scheme C the iterable surface
                # IS the C-namespace, so ``archive.entry_count`` is
                # the authoritative count and the renderer can read
                # "of N in namespace C" instead of the misleading
                # "archive total: ~27M" header that the empty-default
                # fall-through produces.
                ns_count_c = (
                    archive_entry_count if has_new_scheme and namespace == "C" else None
                )
                return cast(
                    "WalkNamespaceResponse",
                    attach_meta(
                        self._build_walk_result(
                            namespace=namespace,
                            scan_at=scan_at,
                            limit=limit,
                            entries=entries,
                            scanned_count=entry_id - scan_at,
                            scanned_through_id=scanned_through_id,
                            done=done,
                            next_cursor=next_cursor,
                            archive_entry_count=archive_entry_count,
                            namespace_entry_count=ns_count_c,
                            assets_skipped=assets_skipped,
                        )
                    ),
                )
        except OpenZimMcpArchiveError:
            raise
        except Exception as e:
            raise OpenZimMcpArchiveError(f"walk_namespace failed: {e}") from e

    @staticmethod
    def _build_walk_result(
        *,
        namespace: str,
        scan_at: int,
        limit: int,
        entries: List[Dict[str, Any]],
        scanned_count: int,
        scanned_through_id: Optional[int],
        done: bool,
        next_cursor: Optional[str],
        archive_entry_count: int,
        namespace_entry_count: Optional[int] = None,
        assets_skipped: int = 0,
    ) -> Dict[str, Any]:
        """Assemble the walk_namespace v2 contract result dict.

        Five-key contract (``results`` / ``next_cursor`` / ``total`` /
        ``done`` / ``page_info``) plus walk-specific extras.

        ``total`` is always None: walk_namespace doesn't know the
        per-namespace total mid-scan for the iterable C-namespace path.
        Callers that need a count can use ``browse_namespace`` (sampled)
        or wait for ``done=True``.

        A11 F4 (post-a10 second pass): the M and W well-known walks
        know the bounded total ahead of time (``metadata_keys`` length;
        main_entry / illustration probe pair). Surface it as
        ``namespace_entry_count`` so the renderer can report a per-
        namespace denominator instead of the archive-wide ``of ~27M``
        scale hint that mismatches a 2- or 13-entry namespace.

        ``archive_entry_count`` is the file-level entry count, distinct
        from the (unknown for C, known for M/W) namespace count.

        ``assets_skipped`` is how many in-namespace rows the non-article
        asset filter withheld on THIS page. It surfaces as
        ``page_info.assets_filtered`` / ``page_info.assets_skipped`` —
        the same field page mode emits — only when it is non-zero, so the
        signal keeps meaning "rows were withheld" rather than becoming a
        constant. Because new-scheme C holds every iterable entry,
        ``returned_count + assets_skipped == scanned_count`` there, which
        is what lets a caller reconcile an exhaustive walk against the
        unfiltered ``namespace_entry_count``.
        """
        returned_count = len(entries)
        page_info: Dict[str, Any] = {
            "offset": scan_at,
            "limit": limit,
            "returned_count": returned_count,
        }
        if assets_skipped:
            page_info["assets_filtered"] = True
            page_info["assets_skipped"] = assets_skipped
        payload: Dict[str, Any] = {
            "namespace": namespace,
            "results": entries,
            "next_cursor": next_cursor,
            "total": None,
            "done": done,
            "page_info": page_info,
            "scanned_count": scanned_count,
            "scanned_through_id": scanned_through_id,
            "archive_entry_count": archive_entry_count,
        }
        if namespace_entry_count is not None:
            payload["namespace_entry_count"] = namespace_entry_count
        return payload

    @classmethod
    def _walk_new_scheme_metadata(
        cls,
        archive: Archive,
        scan_at: int,
        limit: int,
        archive_entry_count: int,
        *,
        validated_path: "Optional[Path]" = None,
    ) -> Dict[str, Any]:
        """Walk M (metadata) entries in a new-scheme archive via metadata_keys."""
        from openzim_mcp.pagination import Cursor, archive_identity

        try:
            keys = [
                k
                for k in (getattr(archive, "metadata_keys", []) or [])
                # A11 post-a11 M1: same filter the metadata-for aggregator
                # uses (Archive._extract_zim_metadata) so the two surfaces
                # agree on what counts as a metadata key. Without this,
                # walk reported 13 entries (incl. binary illustration)
                # while metadata-for reported 12.
                if is_human_readable_metadata_key(k)
            ]
        except Exception as e:
            logger.debug(f"metadata_keys read failed: {e}")
            keys = []
        total = len(keys)
        start = scan_at
        # Clamp: a stale cursor can resume past the end of the key list, and
        # an unclamped ``end - start`` went negative in ``scanned_count``.
        end = max(start, min(start + limit, total))
        entries = [{"path": f"M/{k}", "title": k} for k in keys[start:end]]
        done = end >= total
        next_cursor: Optional[str] = None
        if not done:
            # ``scan_at`` here is an index into ``metadata_keys``, not an
            # entry ID. The cursor's ``ns="M"`` discriminator + the
            # archive's new-scheme bit are enough for the consumer to
            # know which interpretation to use; see #17. P3-D2: ``o``
            # is the universal wire key — the dispatcher remaps it
            # back to ``scan_at`` on the cursor_state passed into the
            # walker.
            state: Dict[str, Any] = {"o": end, "l": limit, "ns": "M"}
            if validated_path is not None:
                state["ai"] = archive_identity(validated_path)
            next_cursor = Cursor.encode(
                tool="walk_namespace",
                state=cast("Any", state),
            )
        return cls._build_walk_result(
            namespace="M",
            scan_at=scan_at,
            limit=limit,
            entries=entries,
            scanned_count=end - start,
            scanned_through_id=end - 1 if end > start else None,
            done=done,
            next_cursor=next_cursor,
            archive_entry_count=archive_entry_count,
            # F4: M is bounded by metadata_keys length, so surface
            # the real namespace total to the renderer.
            namespace_entry_count=total,
        )

    @classmethod
    def _walk_new_scheme_well_known(
        cls,
        archive: Archive,
        scan_at: int,
        limit: int,
        archive_entry_count: int,
        *,
        validated_path: "Optional[Path]" = None,
    ) -> Dict[str, Any]:
        """D8 (beta): walk W (well-known) entries via canonical probes.

        Mirrors ``_walk_new_scheme_metadata`` but the source is the
        ``has_main_entry`` / ``has_illustration`` probe pair that
        ``_add_new_scheme_well_known_namespace`` already uses for the
        namespace listing. Keeps the two operations consistent for
        new-scheme archives: ``list namespaces`` says W has 2 entries
        and ``walk namespace W`` now actually surfaces them.
        """
        from openzim_mcp.pagination import Cursor, archive_identity

        probes: List[Tuple[str, str]] = []
        # Same suppress-on-failure semantics as the namespace listing
        # probe; W is informational, never load-bearing.
        with contextlib.suppress(Exception):
            if getattr(archive, "has_main_entry", False):
                probes.append(("W/mainPage", "mainPage"))
        with contextlib.suppress(Exception):
            if archive.has_illustration():
                probes.append(("W/favicon", "favicon"))

        total = len(probes)
        start = scan_at
        # Clamp: same stale-cursor guard as the metadata walker — an
        # unclamped ``end - start`` went negative in ``scanned_count``.
        end = max(start, min(start + limit, total))
        entries = [{"path": p, "title": t} for p, t in probes[start:end]]
        done = end >= total
        next_cursor: Optional[str] = None
        if not done:
            state: Dict[str, Any] = {"o": end, "l": limit, "ns": "W"}
            if validated_path is not None:
                state["ai"] = archive_identity(validated_path)
            next_cursor = Cursor.encode(
                tool="walk_namespace",
                state=cast("Any", state),
            )
        return cls._build_walk_result(
            namespace="W",
            scan_at=scan_at,
            limit=limit,
            entries=entries,
            scanned_count=end - start,
            scanned_through_id=end - 1 if end > start else None,
            done=done,
            next_cursor=next_cursor,
            archive_entry_count=archive_entry_count,
            # F4: W is bounded by the well-known probe pair length.
            namespace_entry_count=total,
        )

    def walk_namespace(
        self,
        zim_file_path: str,
        namespace: str,
        cursor: Optional[Dict[str, Any]] = None,
        limit: int = 200,
    ) -> str:
        """Legacy JSON-string variant of ``walk_namespace_data``.

        Walk every entry in a namespace by entry ID, with cursor pagination.

        Unlike browse_namespace (which samples), this iterates the archive
        deterministically from ``cursor`` onward and returns up to ``limit``
        entries that belong to the requested namespace. Pair the returned
        ``next_cursor`` with a follow-up call to walk the rest. Set to None
        when iteration is complete.

        Args:
            zim_file_path: Path to the ZIM file
            namespace: Namespace to walk (C, M, W, X, A, I, etc.)
            cursor: Decoded cursor-state dict (e.g.
                ``{"scan_at": 42, "l": 200}``). ``None`` starts from the
                beginning. Tool callers should prefer the MCP
                ``walk_namespace`` tool which accepts an opaque wire
                cursor and decodes for you.
            limit: Maximum entries to return per page (1–500, default 200)

        Returns:
            JSON containing entries in the namespace, the next cursor, and
            ``done: true`` if iteration finished

        Raises:
            OpenZimMcpValidationError: If ``limit`` is outside ``1..500``.
        """
        return _json(
            self.walk_namespace_data(
                zim_file_path, namespace, cursor_state=cursor, limit=limit
            )
        )
