"""Server-state introspection helpers — builders for the ``zim_health``
tool's combined response.

Phase F lifted these helpers out of the legacy ``tools/server_tools.py``
(which Task D12 deleted) into this dedicated module so the cross-layer
dependency chain becomes a stable, non-tool path:

  ``tools/zim_health`` →  ``async_operations.get_health_data``
                       →  ``server_state._build_health_report`` /
                          ``server_state._build_configuration_report``

The same builders served the legacy single-purpose ``get_server_health``
and ``get_server_configuration`` tools verbatim, so the data shape they
emit is identical to b13.
"""

from __future__ import annotations

import logging
import os
import time as _time
from datetime import datetime, timezone
from pathlib import Path
from typing import TYPE_CHECKING, Any, Dict, List, Tuple, Union, cast

from . import __version__
from .constants import CACHE_HIGH_HIT_RATE_THRESHOLD, CACHE_LOW_HIT_RATE_THRESHOLD
from .onboarding import acquisition_hint_line
from .responses import ToolErrorPayload, tool_error
from .security import redact_paths_in_message, sanitize_path_for_error
from .tool_schemas import HealthStatus, ServerConfigurationResponse
from .zim.archive import has_zim_signature, is_truncated_zim, zim_signature_error

if TYPE_CHECKING:
    from .server import OpenZimMcpServer

logger = logging.getLogger(__name__)


def _utc_now_iso() -> str:
    """Return the current UTC time as an ISO-8601 string with offset.

    All server-state timestamps go through this helper so a single response
    never mixes timezone-aware (``+00:00``) and naive local strings.
    """
    return datetime.now(timezone.utc).isoformat()


def _downgrade_to_warning(health_info: Dict[str, Any]) -> None:
    """Move ``status`` from ``healthy`` to ``warning``; never overrides ``error``."""
    if health_info["status"] == "healthy":
        health_info["status"] = "warning"


def _resolved(path: Path) -> Path:
    """``path`` resolved, or the path itself when the filesystem refuses."""
    try:
        return path.resolve()
    except OSError:  # pragma: no cover - a vanished/looping path
        return path


def _readable_zim_files(
    dir_path: Path,
    health_info: Dict[str, Any],
    health_checks: Dict[str, Any],
    warnings: List[str],
    recommendations: List[str],
) -> "set[Path]":
    """The ``.zim`` files under an accessible directory that carry the ZIM
    signature, keyed by resolved path, reporting the ones that do not.

    Resolved paths rather than a bare count, because the caller unions them
    across every allowed directory: two entries that name the same tree (the
    same path twice, or a parent alongside its child — both ordinary editing
    mistakes in a hand-maintained client config) used to make
    ``zim_files_found`` report one archive as two, contradicting
    ``loaded_archives`` three lines below it in the very same payload.

    Probes the directory with ``iterdir`` first so a permission problem
    surfaces as the exception the caller classifies, not as a silent zero.

    A file the process cannot read is reported as the permission problem it
    is, not as a bad signature: the advice for the two is opposite, and
    "remove or replace it" aimed at a merely unreadable archive destroys a
    good one.
    """
    list(dir_path.iterdir())
    zim_files = sorted({_resolved(p) for p in dir_path.glob("**/*.zim") if p.is_file()})
    unreadable = [p for p in zim_files if not has_zim_signature(p)]
    denied = {p for p in unreadable if zim_signature_error(p) is not None}
    for bad in unreadable:
        redacted = sanitize_path_for_error(str(bad))
        if bad in denied:
            warnings.append(f"Cannot read .zim file: {redacted}")
        elif is_truncated_zim(bad):
            # v3.3.1 field report (fid 0's residual). A truncated download
            # DOES carry the signature — that is why the per-archive
            # ``loaded_archives[].warning`` calls it truncated and says to
            # re-download it. This line kept calling it a missing signature,
            # contradicting that verdict three lines up in the same payload
            # and pointing the operator at replacing a file whose bytes are
            # fine as far as they go. The two remedies differ, so the two
            # verdicts have to.
            warnings.append(f"Truncated .zim file (re-download it): {redacted}")
        else:
            warnings.append(f"Unreadable .zim file (missing ZIM signature): {redacted}")
    if denied:
        recommendations.append(
            "Check read permissions for the .zim file(s) this server cannot open"
        )
        health_checks["permissions_ok"] = False
    if len(unreadable) > len(denied):
        recommendations.append(
            "Remove or replace the unreadable .zim file(s); "
            "they cannot be opened as archives"
        )
    if unreadable:
        _downgrade_to_warning(health_info)
    return set(zim_files) - set(unreadable)


def _check_directory_health(
    directory: str,
    health_info: Dict[str, Any],
    health_checks: Dict[str, Any],
    warnings: List[str],
    recommendations: List[str],
) -> Tuple[int, "set[Path]"]:
    """Probe one allowed directory and return (accessible, readable archives).

    The archives come back as resolved paths rather than a count so the
    caller can union them; overlapping allowed directories then cannot
    inflate the total. Only files carrying the ZIM signature are included: a
    file merely *named* ``.zim`` that libzim could never open is reported as
    a warning (and downgrades the status) instead of being counted as a
    loaded archive — otherwise a directory of garbage reads as "healthy".

    Mutates ``health_info``/``health_checks``/``warnings``/``recommendations``
    in place so the caller can accumulate aggregate state across directories.
    """
    # Sanitize the path before it ever lands in user-visible warning /
    # recommendation strings — diagnostic output is frequently copy-pasted
    # into bug reports and must not leak host topology.
    redacted = sanitize_path_for_error(str(directory))
    try:
        dir_path = Path(directory)
        if dir_path.exists() and dir_path.is_dir():
            readable = _readable_zim_files(
                dir_path, health_info, health_checks, warnings, recommendations
            )
            return 1, readable
        warnings.append(f"Directory not accessible: {redacted}")
        recommendations.append(f"Check directory path and permissions: {redacted}")
        _downgrade_to_warning(health_info)
    except PermissionError:
        warnings.append(f"Permission denied: {redacted}")
        recommendations.append(f"Check file permissions for: {redacted}")
        health_checks["permissions_ok"] = False
        _downgrade_to_warning(health_info)
    except Exception as e:
        warnings.append(
            f"Error accessing {redacted}: {redact_paths_in_message(str(e))}"
        )
        _downgrade_to_warning(health_info)
    return 0, set()


def _dedupe(items: List[str]) -> List[str]:
    """``items`` with later repeats dropped, order preserved.

    Two allowed directories naming the same tree produced every warning and
    every recommendation twice, for the same reason they produced every
    archive twice.
    """
    seen: "set[str]" = set()
    unique = []
    for item in items:
        if item not in seen:
            seen.add(item)
            unique.append(item)
    return unique


# Minimum cache accesses before we report on hit-rate trends. Below this we
# treat the rate as too noisy to comment on. 50 is enough that a steady-state
# pattern has emerged; below that, warming-up effects dominate.
_CACHE_RECOMMENDATION_MIN_SAMPLES = 50


def _append_cache_recommendations(
    cache_stats: Dict[str, Any], recommendations: List[str]
) -> None:
    """Translate cache stats into human-readable recommendations.

    Skip the "low" warning until the cache has seen a meaningful sample.
    A fresh session legitimately has a low hit rate while it warms up;
    warning on the first query was misleading and got beta-tester
    complaints.

    A cache sitting at ``max_size`` is checked first, and it suppresses the
    hit-rate advice rather than adding to it. "Issue repeated queries against
    the same ZIM files" is the wrong knob for a full cache: a client that
    obeys it re-issues a query whose entry has already been evicted and misses
    again. Capacity is the knob, and it was the one thing this report never
    mentioned.
    """
    if not cache_stats.get("enabled", False):
        recommendations.append("Consider enabling cache for better performance")
        return

    max_size = cache_stats.get("max_size", 0) or 0
    if max_size and cache_stats.get("size", 0) >= max_size:
        recommendations.append(
            f"Cache is full ({max_size} entries) and evicting — raise "
            "OPENZIM_MCP_CACHE__MAX_SIZE if the working set is larger"
        )
        return

    hit_rate = cache_stats.get("hit_rate", 0)
    total_accesses = cache_stats.get("hits", 0) + cache_stats.get("misses", 0)
    if total_accesses < _CACHE_RECOMMENDATION_MIN_SAMPLES:
        return  # Not enough signal yet — silence is more useful than noise.
    if hit_rate < CACHE_LOW_HIT_RATE_THRESHOLD:
        recommendations.append(
            "Cache hit rate is low — consider issuing repeated "
            "queries against the same ZIM files"
        )
    elif hit_rate > CACHE_HIGH_HIT_RATE_THRESHOLD:
        recommendations.append("Cache is performing well")


def _append_persistence_warning(
    cache_stats: Dict[str, Any], warnings: List[str], recommendations: List[str]
) -> bool:
    """Report a broken cache persistence path; True when one was reported.

    An unwritable cache directory used to reach the operator only as a
    ``WARNING`` on stderr at process exit — after the last moment anyone could
    react — while ``zim_health`` returned ``status: healthy``,
    ``warnings: []`` and ``Server is running optimally`` for the same run.
    Nothing is wrong with the *content* the server can serve, so this is a
    warning rather than an error, but it must not be silent.
    """
    error = cache_stats.get("persistence_error")
    if not error:
        return False
    warnings.append(f"Cache persistence is not working: {error}")
    recommendations.append(
        "Point OPENZIM_MCP_CACHE__PERSISTENCE_PATH (or XDG_CACHE_HOME) at a "
        "writable directory, or disable cache persistence"
    )
    return True


def _finalize_health_status(
    health_info: Dict[str, Any],
    accessible_dirs: int,
    total_zim_files: int,
    warnings: List[str],
    recommendations: List[str],
) -> None:
    """Roll up accumulated checks into the final ``status`` field."""
    if total_zim_files == 0:
        warnings.append("No ZIM files found in any directory")
        # "Add ZIM files" answers "what" and leaves "from where" hanging.
        # ``troubleshooting.mdx`` sends readers here for exactly this
        # symptom, and the file listing beside it already hands over a
        # download command; a health report that stops short of one is the
        # un-helped half of the same sentence. The warning string above is
        # quoted verbatim by the docs, so it is left byte-identical and the
        # guidance is added as a recommendation instead.
        recommendations.append("Add ZIM files to configured directories")
        recommendations.append(acquisition_hint_line())
        _downgrade_to_warning(health_info)

    if accessible_dirs == 0:
        health_info["status"] = "error"
        recommendations.append(
            "Fix directory accessibility issues before using the server"
        )

    if health_info["status"] == "healthy" and not recommendations:
        recommendations.append("Server is running optimally")


def _redact_directory_path(path: str) -> str:
    """Render a directory path for the configuration response.

    Returns ``<redacted>/<basename>`` so it's unambiguous that the leading
    components were intentionally hidden. The basename stays so operators
    can still tell which configured directory each entry corresponds to.
    """
    if not path:
        return "<redacted>"
    parts = path.replace("\\", "/").split("/")
    basename = parts[-1] if parts[-1] else (parts[-2] if len(parts) > 1 else "")
    if not basename:
        return "<redacted>"
    return f"<redacted>/{basename}"


def _redact_diagnostics(server: "OpenZimMcpServer") -> bool:
    """Whether to mask paths/PID in the diagnostic report.

    Redaction guards a trust boundary: over the HTTP/SSE transports the
    client may be remote, so absolute host paths and the PID are masked.
    On the local stdio transport the client already shares the filesystem
    — and ``loaded_archives[].path`` reports the same absolute paths
    unredacted (clients pass them back as ``zim_file_path``) — so masking
    there only creates an inconsistency without protecting anything; show
    the real values.
    """
    return getattr(server.config, "transport", "stdio") != "stdio"


def _build_uptime_info(server: "OpenZimMcpServer") -> Dict[str, Any]:
    """Return uptime block for the health report.

    ``started_at`` and ``uptime_seconds`` are filled in from the server's
    init-time anchors when present; falls back to ``"unknown"`` /
    ``None`` for legacy paths that didn't record them.
    """
    start_iso = getattr(server, "_start_time", None) or "unknown"
    start_mono = getattr(server, "_start_monotonic", None)
    uptime_seconds: Any = None
    if start_mono is not None:
        uptime_seconds = round(_time.monotonic() - start_mono, 3)
    return {
        # PID is masked over the network transports (HTTP/SSE) where the
        # client may be remote; shown on local stdio for consistency with
        # the unredacted ``loaded_archives`` paths (see _redact_diagnostics).
        "process_id": "[REDACTED]" if _redact_diagnostics(server) else os.getpid(),
        "started_at": start_iso,
        "uptime_seconds": uptime_seconds,
    }


def _build_health_report(
    server: "OpenZimMcpServer",
) -> Union[HealthStatus, ToolErrorPayload]:
    try:
        cache_stats = server.cache.stats()
        if _redact_diagnostics(server) and "persistence_path" in cache_stats:
            # The cache file is a host path no client can hand back to a tool,
            # so it follows the PID/directory masking rather than the
            # ``loaded_archives`` exemption (see _redact_diagnostics).
            cache_stats = dict(cache_stats)
            cache_stats["persistence_path"] = sanitize_path_for_error(
                str(cache_stats["persistence_path"])
            )
        recommendations: List[str] = []
        warnings: List[str] = []
        health_checks: Dict[str, Any] = {
            "directories_accessible": 0,
            "zim_files_found": 0,
            "permissions_ok": True,
        }
        health_info: Dict[str, Any] = {
            "timestamp": _utc_now_iso(),
            "status": "healthy",
            "server_name": server.config.server_name,
            # A stale install can serve an old server for weeks while looking
            # current; ``serverInfo.version`` exists in the initialize result
            # but most clients never surface it, so the health report is the
            # one place an operator can ask what is actually running.
            "version": __version__,
            "uptime_info": _build_uptime_info(server),
            "configuration": {
                "allowed_directories": len(server.config.allowed_directories),
                "cache_enabled": server.config.cache.enabled,
                "config_hash": server.config.get_config_hash()[:8] + "...",
            },
            "cache_performance": cache_stats,
            "health_checks": health_checks,
            "recommendations": recommendations,
            "warnings": warnings,
        }

        # Surface simple-mode heuristic-branch counters so the operator
        # can see, in aggregate, which fallback paths are firing.
        simple_handler = getattr(server, "simple_tools_handler", None)
        if simple_handler is not None and hasattr(simple_handler, "get_telemetry"):
            health_info["simple_tools_telemetry"] = simple_handler.get_telemetry()

        accessible_dirs = 0
        # Distinct resolved paths, so a directory listed twice (or a parent
        # listed alongside its child) cannot report one archive as two.
        readable_zim_files: "set[Path]" = set()
        for directory in server.config.allowed_directories:
            ok, readable = _check_directory_health(
                directory, health_info, health_checks, warnings, recommendations
            )
            accessible_dirs += ok
            readable_zim_files |= readable

        warnings[:] = _dedupe(warnings)
        recommendations[:] = _dedupe(recommendations)

        total_zim_files = len(readable_zim_files)
        health_checks["directories_accessible"] = accessible_dirs
        health_checks["zim_files_found"] = total_zim_files

        _append_cache_recommendations(cache_stats, recommendations)
        if _append_persistence_warning(cache_stats, warnings, recommendations):
            _downgrade_to_warning(health_info)
        _finalize_health_status(
            health_info, accessible_dirs, total_zim_files, warnings, recommendations
        )

        return cast(HealthStatus, health_info)

    except Exception as e:
        logger.error(f"Error getting server health: {e}")
        return tool_error(
            operation="get server health",
            message=server._create_enhanced_error_message(
                operation="get server health",
                error=e,
                context="Checking server health and performance metrics",
            ),
            context="Checking server health and performance metrics",
        )


def _build_configuration_report(
    server: "OpenZimMcpServer",
) -> Union[ServerConfigurationResponse, ToolErrorPayload]:
    try:
        # Mask paths and PID over the network transports (HTTP/SSE) where the
        # client may be remote; on local stdio show the real values so this
        # report stays consistent with the unredacted ``loaded_archives``
        # paths the same response carries (see _redact_diagnostics).
        redact = _redact_diagnostics(server)
        config_info = {
            "server_name": server.config.server_name,
            "allowed_directories": [
                _redact_directory_path(str(p)) if redact else str(p)
                for p in server.config.allowed_directories
            ],
            "allowed_directories_count": len(server.config.allowed_directories),
            "cache_enabled": server.config.cache.enabled,
            "cache_max_size": server.config.cache.max_size,
            "cache_ttl_seconds": server.config.cache.ttl_seconds,
            "content_max_length": server.config.content.max_content_length,
            "content_snippet_length": server.config.content.snippet_length,
            "search_default_limit": server.config.content.default_search_limit,
            "config_hash": server.config.get_config_hash(),
            "server_pid": "[REDACTED]" if redact else os.getpid(),
        }

        warnings_list: List[str] = []
        recommendations_list: List[str] = []
        diagnostics = {
            "validation_status": "ok",
            "warnings": warnings_list,
            "recommendations": recommendations_list,
        }

        invalid_dirs = [
            _redact_directory_path(str(d)) if redact else str(d)
            for d in server.config.allowed_directories
            if not Path(d).exists()
        ]
        if invalid_dirs:
            diagnostics["validation_status"] = "error"
            warnings_list.append(f"Invalid directories: {invalid_dirs}")
            recommendations_list.append(
                "Check that all allowed directories exist and are accessible"
            )

        result: ServerConfigurationResponse = {
            "configuration": cast("Any", config_info),
            "diagnostics": cast("Any", diagnostics),
            "timestamp": _utc_now_iso(),
        }

        return result
    except Exception as e:
        logger.error(f"Error getting server configuration: {e}")
        return tool_error(
            operation="get server configuration",
            message=server._create_enhanced_error_message(
                operation="get server configuration",
                error=e,
                context="Configuration diagnostics",
            ),
            context="Configuration diagnostics",
        )
