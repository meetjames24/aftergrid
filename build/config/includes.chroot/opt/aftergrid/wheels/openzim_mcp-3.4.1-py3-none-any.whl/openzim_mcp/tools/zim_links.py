"""zim_links — outbound/inbound link buckets or related-article suggestions.

Collapses ``extract_article_links`` + ``get_related_articles`` +
``get_inbound_links`` (3 → 1) via a
``direction: Literal["outbound", "inbound", "related"]`` dispatch.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Literal, Optional

from ..exceptions import OpenZimMcpCursorMismatchError
from ..linkgraph.reader import LinkGraphUnavailable
from ..responses import tool_error
from ._common import (
    READ_ONLY_ANNOTATIONS,
    blank_archive_path,
    cursor_context_mismatch,
    decode_cursor_state,
    effective_limit,
    enforce_rate_limit,
    limit_out_of_range,
    load_description,
    tool_error_response,
)

if TYPE_CHECKING:
    from ..server import OpenZimMcpServer

_DESCRIPTION = load_description("zim_links")

_VALID_DIRECTIONS = {"outbound", "inbound", "related"}
_VALID_KINDS = {"internal", "external", "media"}


def register(server: "OpenZimMcpServer") -> None:
    """Register the `zim_links` tool with the MCP server."""
    from ..async_operations import AsyncZimOperations

    ops = AsyncZimOperations(server.zim_operations)

    @server.mcp.tool(description=_DESCRIPTION, annotations=READ_ONLY_ANNOTATIONS)
    async def zim_links(
        zim_file_path: str,
        entry_path: str,
        direction: Literal["outbound", "inbound", "related"] = "outbound",
        kind: Literal["internal", "external", "media"] = "internal",
        cursor: Optional[str] = None,
        limit: Optional[int] = None,
        offset: int = 0,
    ) -> Any:
        try:
            # Price/limit on the INTERNAL operation name — ``zim_links`` is
            # absent from ``RATE_LIMIT_COSTS`` (see ``defaults.py``), so the
            # wire name resolved to the default cost of 1 and any
            # ``per_operation_limits`` override was silently inert.
            _rl_op = {
                "related": "get_related_articles",
                "inbound": "get_inbound_links",
            }.get(direction, "extract_article_links")
            rl = enforce_rate_limit(server, _rl_op)
            if rl is not None:
                return rl
            if direction not in _VALID_DIRECTIONS:
                return tool_error(
                    operation="invalid_direction",
                    message=(
                        f"`direction` must be one of {sorted(_VALID_DIRECTIONS)} "
                        f"(provided: {direction!r})."
                    ),
                )
            # ``kind`` buckets the links extracted from an article body, which
            # only the outbound walk produces; the inbound and related sets
            # are unbucketed. Both directions used to accept an explicit
            # ``kind`` and drop it, so "what media links here" answered with
            # every inbound link and read as a complete answer. Only a
            # non-default value can be rejected — ``kind`` is a plain enum
            # argument, so "internal" is indistinguishable from omitted.
            if direction != "outbound" and kind != "internal":
                return tool_error(
                    operation="invalid_combination",
                    message=(
                        "`kind` selects one bucket of an article's own "
                        "outbound links and is only supported by "
                        f"`direction='outbound'`; direction={direction!r} "
                        "returns a single unbucketed set. Drop `kind`, or "
                        "switch to `direction='outbound'`."
                    ),
                )

            blank = blank_archive_path(zim_file_path)
            if blank is not None:
                return blank
            # outbound walks the page's own link list (500); inbound and
            # related read the sidecar's ranked neighbours (100 each).
            bad_limit = limit_out_of_range(
                limit,
                maximum=500 if direction == "outbound" else 100,
                qualifier=f"direction={direction!r}",
            )
            if bad_limit is not None:
                return bad_limit

            if direction == "outbound":
                if kind not in _VALID_KINDS:
                    return tool_error(
                        operation="invalid_kind",
                        message=(
                            f"`kind` must be one of {sorted(_VALID_KINDS)} "
                            f"(provided: {kind!r})."
                        ),
                    )
                state, cursor_error = decode_cursor_state(
                    cursor, expected_tool="extract_article_links"
                )
                if cursor_error is not None:
                    return cursor_error
                eff_limit = effective_limit(limit, state, 100)
                eff_kind: str = kind
                if state is not None:
                    # Guard against replaying entry A's cursor against entry B,
                    # which would apply A's offset to B's link list.
                    ep_error = cursor_context_mismatch(
                        state, field="ep", expected=entry_path, label="entry"
                    )
                    if ep_error is not None:
                        return ep_error
                    # Honour the bucket the cursor was issued for. A cursor for
                    # the 'external' bucket must not silently resume against
                    # 'internal'; reject an explicit non-default `kind` that
                    # contradicts the cursor's encoded 'k', else adopt it.
                    cursor_kind = state.get("k")
                    if isinstance(cursor_kind, str) and cursor_kind:
                        if kind != "internal" and kind != cursor_kind:
                            return cursor_context_mismatch(
                                state, field="k", expected=kind, label="kind"
                            )
                        eff_kind = cursor_kind
                    return await ops.extract_article_links_data(
                        zim_file_path,
                        entry_path,
                        limit=eff_limit,
                        offset=int(state.get("o", 0) or 0),
                        kind=eff_kind,
                        cursor_archive_identity=state.get("ai"),
                    )
                return await ops.extract_article_links_data(
                    zim_file_path,
                    entry_path,
                    limit=eff_limit,
                    offset=offset,
                    kind=eff_kind,
                )

            if direction == "inbound":
                state, cursor_error = decode_cursor_state(
                    cursor, expected_tool="get_inbound_links"
                )
                if cursor_error is not None:
                    return cursor_error
                eff_offset = offset
                if state is not None:
                    # Guard against replaying entry A's cursor against entry B,
                    # which would apply A's offset to B's inbound list.
                    ep_error = cursor_context_mismatch(
                        state, field="ep", expected=entry_path, label="entry"
                    )
                    if ep_error is not None:
                        return ep_error
                    eff_offset = int(state.get("o", 0) or 0)
                try:
                    return await ops.get_inbound_links_data(
                        zim_file_path,
                        entry_path,
                        limit=effective_limit(limit, state, 10),
                        offset=eff_offset,
                        cursor_archive_identity=state.get("ai") if state else None,
                    )
                except LinkGraphUnavailable as e:
                    return tool_error(
                        operation="inbound_sidecar_unavailable", message=str(e)
                    )

            # direction == "related" — a single ranked set, never paginated
            # (the data layer always returns next_cursor=None), so a cursor
            # here is a caller error rather than a silent no-op.
            if cursor is not None and str(cursor).strip():
                return tool_error(
                    operation="cursor_unsupported",
                    message=(
                        "`direction='related'` returns a single ranked set and "
                        "does not paginate; omit `cursor`."
                    ),
                )
            # ``offset`` is the same request the cursor guard above refuses,
            # spelled the other way, and it was the half that stayed silent:
            # ``get_related_articles_data`` takes no offset, so every page was
            # page one while the caller believed it had advanced.
            if offset:
                return tool_error(
                    operation="invalid_combination",
                    message=(
                        "`direction='related'` returns a single ranked set and "
                        f"does not paginate; `offset` (provided: {offset}) "
                        "would return the same rows. Omit it, and raise "
                        "`limit` if you need more neighbours."
                    ),
                )
            return await ops.get_related_articles_data(
                zim_file_path,
                entry_path,
                limit=limit if limit is not None else 10,
            )
        except OpenZimMcpCursorMismatchError as e:
            # The archive-identity check needs the validated path, so it runs
            # in the data layer; render it under the same code the entry/kind
            # cursor guards above use, not the generic validation envelope.
            return tool_error(
                operation="cursor_context_mismatch",
                message=str(e),
                context="field=ai",
            )
        except Exception as e:  # noqa: BLE001 — broad catch matches b13 envelope
            return tool_error_response(
                server,
                operation="zim_links",
                error=e,
                context=f"Path: {entry_path}, Direction: {direction}",
            )
