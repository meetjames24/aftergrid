"""
Caching functionality for OpenZIM MCP server.

Provides an in-memory LRU cache with TTL support, optional background
cleanup to proactively remove expired entries, and optional persistence
for cache warmup between restarts.
"""

import atexit
import contextlib
import functools
import hashlib
import heapq
import json
import logging
import os
import tempfile
import threading
import time
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple

from .config import CacheConfig
from .defaults import CACHE
from .exceptions import OpenZimMcpValidationError

logger = logging.getLogger(__name__)

# Default interval for background cleanup (in seconds)
DEFAULT_CLEANUP_INTERVAL = 60

# File extension for persistence files
CACHE_FILE_EXTENSION = ".json"


# The package-wide default persistence path (``~/.cache/openzim-mcp``).
# Every server that does not override ``persistence_path`` gets this exact
# string, which is why it needs the per-config scoping applied in
# ``OpenZimMcpCache.__init__``.
_DEFAULT_PERSISTENCE_PATH = str(Path(CACHE.PERSISTENCE_PATH).expanduser())


def _default_cache_directory() -> Path:
    """``$XDG_CACHE_HOME`` if set, else ``~/.cache``.

    M27 rewrote the default away from a CWD-relative directory, which
    silently failed inside read-only Docker images run from ``/app``: the
    save error was logged and the operator's cache warmup was lost with no
    obvious feedback. ``XDG_CACHE_HOME`` is the well-known override an
    operator sets under Docker/systemd to point the cache somewhere writable,
    and honouring it is the whole point of that rewrite — but the branch that
    read it sat behind ``if configured_path:``, and ``persistence_path`` has a
    ``default_factory``, so it was never falsy and the branch was unreachable.
    The lookup therefore lives here, on the path the default actually takes.
    """
    xdg = os.environ.get("XDG_CACHE_HOME")
    return Path(xdg) if xdg else Path.home() / ".cache"


def _is_package_default_path(configured_path: Any) -> bool:
    """Whether ``configured_path`` is the untouched package default."""
    if not configured_path:
        return True
    return str(Path(configured_path).expanduser()) == _DEFAULT_PERSISTENCE_PATH


def _cache_config_fingerprint(config: CacheConfig) -> str:
    """Short stable digest of the cache-shaping settings in ``config``.

    Used to scope the *default* persistence path so two servers running
    under different cache configurations do not write to (and clobber) the
    same file. Only fields that change what may legitimately live in the
    snapshot are included, so a cosmetic config change does not throw away
    an otherwise-valid warm cache.
    """
    payload = "|".join(
        str(getattr(config, name, None))
        for name in ("max_size", "max_bytes", "ttl_seconds")
    )
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()[:12]


def _silence_logging_errors(func: Callable[..., Any]) -> Callable[..., Any]:
    """Wrap an atexit-registered callable to suppress logging-handler errors.

    During interpreter shutdown — or under pytest stream capture — stdout and
    stderr may be closed before atexit handlers run. Logging calls inside
    those handlers then raise ``ValueError: I/O operation on closed file``
    inside ``StreamHandler.emit``, which ``handleError`` reports by writing
    "--- Logging error ---" plus a traceback to stderr (spamming test output
    and confusing users). Toggling ``logging.raiseExceptions`` disables that
    fallback path so failed log writes are silently dropped instead.
    """

    @functools.wraps(func)
    def wrapper(*args: Any, **kwargs: Any) -> Any:
        prev = logging.raiseExceptions
        logging.raiseExceptions = False
        try:
            return func(*args, **kwargs)
        finally:
            logging.raiseExceptions = prev

    return wrapper


def _approximate_size_bytes(value: Any) -> int:
    """Approximate the cached value's memory cost via JSON encoding length.

    JSON length is not the actual Python in-memory footprint, but it is
    a stable, monotonic proxy that callers can budget against, and it's
    cheap (no full pympler-style traversal). Non-serializable values
    fall back to a conservative ``2 KB`` so they still count toward the
    cap.
    """
    try:
        return len(json.dumps(value, ensure_ascii=False, default=str))
    except (TypeError, ValueError):
        return 2048


class CacheEntry:
    """Represents a single cache entry with TTL."""

    def __init__(self, value: Any, ttl_seconds: int):
        """
        Initialize cache entry.

        Args:
            value: Value to cache
            ttl_seconds: Time to live in seconds

        Example:
            >>> entry = CacheEntry("cached_value", ttl_seconds=3600)
            >>> entry.is_expired()
            False
        """
        self.value = value
        self.size_bytes = _approximate_size_bytes(value)
        # Use monotonic clock for in-memory expiry/LRU so wall-clock
        # adjustments (NTP, DST, manual changes) can't break expiry.
        self.created_at = time.monotonic()
        self.ttl_seconds = ttl_seconds

    def is_expired(self) -> bool:
        """Check if cache entry has expired."""
        return time.monotonic() - self.created_at > self.ttl_seconds


class OpenZimMcpCache:
    """Simple in-memory cache with TTL support and hit/miss statistics.

    This cache implements LRU (Least Recently Used) eviction with TTL-based
    expiration. It tracks cache hits and misses for performance monitoring.

    Features:
    - Thread-safe operations with locking
    - Background cleanup thread for proactive expiration
    - LRU eviction using heap for O(log n) performance
    - Hit/miss statistics for monitoring
    - Optional persistence for cache warmup between restarts

    Example:
        >>> from openzim_mcp.config import CacheConfig
        >>> config = CacheConfig(enabled=True, max_size=100, ttl_seconds=3600)
        >>> cache = OpenZimMcpCache(config)
        >>> cache.set("key1", "value1")
        >>> cache.get("key1")
        'value1'
        >>> stats = cache.stats()
        >>> stats["hits"]
        1
    """

    def __init__(
        self,
        config: CacheConfig,
        enable_background_cleanup: bool = True,
        cleanup_interval: int = DEFAULT_CLEANUP_INTERVAL,
    ):
        """
        Initialize cache.

        Args:
            config: Cache configuration
            enable_background_cleanup: If True, start a background thread to
                proactively clean up expired entries
            cleanup_interval: Interval in seconds between cleanup runs
        """
        self.config = config
        self._cache: Dict[str, CacheEntry] = {}
        # Running total of ``CacheEntry.size_bytes`` across all live
        # entries. Updated incrementally on every set/eviction so the
        # byte-bound eviction check is O(1).
        self._total_bytes: int = 0
        # Keys of *ancillary* entries — per-item fragments (one search can
        # insert hundreds of per-result snippet renders) that are exempt
        # from the ``max_size`` count cap and bounded by ``max_bytes``
        # instead. See :meth:`set`.
        self._ancillary_keys: set = set()
        # Monotonic counter for LRU access ordering. A counter is used in
        # preference to a wall-clock or monotonic timestamp because clock
        # resolution varies by platform (Windows ticks at ~15.6ms by default),
        # which would let multiple operations land on the same timestamp and
        # break LRU ordering when (timestamp, key) tuples fall back to
        # lexicographic key comparison.
        self._access_counter: int = 0
        self._access_order: Dict[str, int] = {}
        # Heap for O(log n) LRU eviction: (access_counter, key)
        # Uses lazy deletion - entries may be stale if key was updated or removed
        self._lru_heap: List[Tuple[int, str]] = []
        self._hits: int = 0
        self._misses: int = 0
        # v3.3.1 field report (fid 127): per-item fragment lookups are
        # counted apart from response lookups. ``_get_entry_snippet``
        # consults one ``snippet_render:v1:`` key per search RESULT, so a
        # 50-row search charged 50 lookups to a rate a human reads as "how
        # often did the server avoid repeating work for a client" — making
        # the reported hit rate, and zim_health's verdict on it, a function
        # of the caller's ``limit`` rather than of the cache.
        self._ancillary_hits: int = 0
        self._ancillary_misses: int = 0
        self._lock = threading.RLock()  # Reentrant lock for thread safety

        # Background cleanup thread
        self._cleanup_thread: Optional[threading.Thread] = None
        self._cleanup_stop_event = threading.Event()
        self._cleanup_interval = cleanup_interval

        # Persistence settings
        self._persistence_enabled = getattr(config, "persistence_enabled", False)
        # Why persistence is not working, when it is not. ``stats()`` reports
        # it so ``zim_health`` can say so: an unwritable cache directory used
        # to surface only as a WARNING on stderr at process exit, i.e. after
        # the last moment anyone could react, while the health report went on
        # saying "Server is running optimally".
        self._persistence_error: Optional[str] = None
        # Identity of the snapshot this instance last wrote, so an empty save
        # can tell its own file from a peer's. See ``_save_to_disk``.
        self._saved_snapshot_id: Optional[Tuple[int, int]] = None
        configured_path = getattr(config, "persistence_path", None)
        if _is_package_default_path(configured_path):
            # The package default is a single per-user path, so every server
            # process on the host writes the same file. stdio servers are
            # spawned one per client and each saves from ``atexit``, which
            # meant concurrent savers clobbered one another. Scope the DEFAULT
            # by a fingerprint of the cache settings so differently-configured
            # servers no longer share a file. Identically-configured peers
            # still share one — for those the atomic ``os.replace`` in
            # ``_save_to_disk`` bounds the damage to last-writer-wins rather
            # than a truncated, unparseable file, and the empty-save branch
            # there refuses to delete a snapshot it did not write. An operator
            # who needs strict per-instance isolation sets an explicit
            # ``persistence_path``.
            default_path = (
                _default_cache_directory() / Path(_DEFAULT_PERSISTENCE_PATH).name
            )
            self._persistence_path = default_path.with_name(
                f"{default_path.name}-{_cache_config_fingerprint(config)}"
            )
            if self._persistence_enabled:
                # Ensure the parent dir exists; the file itself is written
                # later by ``_save_to_disk``. Doing it here rather than only
                # at save time is what turns "read-only container" from a
                # warning nobody sees at exit into a startup fact the health
                # report can carry.
                try:
                    self._persistence_path.parent.mkdir(parents=True, exist_ok=True)
                except OSError as e:
                    self._persistence_error = (
                        f"cache directory {self._persistence_path.parent} could "
                        f"not be created ({e}); persistence is disabled"
                    )
                    logger.warning("Cache persistence disabled: %s", e)
                    self._persistence_enabled = False
        else:
            self._persistence_path = Path(str(configured_path)).expanduser()

        # Load persisted cache if enabled
        if config.enabled and self._persistence_enabled:
            self._load_from_disk()

        # atexit handlers fire in LIFO order, so register persistence FIRST
        # and the cleanup-thread stop SECOND. That way at shutdown the cleanup
        # thread is signalled to stop *before* _save_to_disk runs, so the save
        # snapshot doesn't race with concurrent expirations from the cleanup
        # loop.
        # Wrap both with _silence_logging_errors so that interpreter shutdown
        # — when stdout/stderr may already be closed by pytest's capture or
        # the runtime itself — does not spam "--- Logging error ---" tracebacks.
        # Keep references to the registered (wrapped) callables so
        # ``shutdown()`` can deregister them. ``_silence_logging_errors``
        # returns a fresh wrapper each call, so the exact object must be
        # retained to unregister it — otherwise repeated cache construction
        # in one process (per-test server fixtures, config reloads) piles up
        # stale handlers that fire on already-shut-down instances at exit.
        self._atexit_save_handler: Optional[Callable[[], None]] = None
        self._atexit_stop_handler: Optional[Callable[[], None]] = None

        if config.enabled and self._persistence_enabled:
            self._atexit_save_handler = _silence_logging_errors(self._save_to_disk)
            atexit.register(self._atexit_save_handler)

        if config.enabled and enable_background_cleanup:
            self._start_cleanup_thread()
            self._atexit_stop_handler = _silence_logging_errors(
                self._stop_cleanup_thread
            )
            atexit.register(self._atexit_stop_handler)

        logger.info(
            f"Cache initialized: enabled={config.enabled}, "
            f"max_size={config.max_size}, ttl={config.ttl_seconds}s, "
            f"background_cleanup={enable_background_cleanup}, "
            f"persistence={self._persistence_enabled}"
        )

    def _start_cleanup_thread(self) -> None:
        """Start the background cleanup thread."""
        if self._cleanup_thread is not None and self._cleanup_thread.is_alive():
            return  # Already running

        self._cleanup_stop_event.clear()
        self._cleanup_thread = threading.Thread(
            target=self._background_cleanup_loop,
            name="CacheCleanupThread",
            daemon=True,  # Daemon thread will exit when main program exits
        )
        self._cleanup_thread.start()
        logger.debug("Cache background cleanup thread started")

    def _stop_cleanup_thread(self) -> None:
        """Stop the background cleanup thread gracefully."""
        if self._cleanup_thread is None:
            return

        self._cleanup_stop_event.set()
        # Give the thread a chance to exit cleanly
        self._cleanup_thread.join(timeout=2.0)
        if self._cleanup_thread.is_alive():
            logger.debug("Cache cleanup thread did not stop in time")
        else:
            logger.debug("Cache background cleanup thread stopped")
        self._cleanup_thread = None

    def _background_cleanup_loop(self) -> None:
        """Background loop that periodically cleans up expired entries."""
        while not self._cleanup_stop_event.is_set():
            try:
                # Wait for the cleanup interval or until stop is signaled
                if self._cleanup_stop_event.wait(timeout=self._cleanup_interval):
                    break  # Stop event was set

                # Perform cleanup
                self._cleanup_expired()
            except Exception as e:
                # Log but don't crash the cleanup thread
                logger.debug(f"Error in cache cleanup thread: {e}")

    def get(self, key: str, *, ancillary: bool = False) -> Optional[Any]:
        """
        Get value from cache (thread-safe).

        Args:
            key: Cache key
            ancillary: Mark this as a per-item fragment lookup (e.g. one
                entry's rendered markdown) rather than a response lookup, so
                it lands in the ancillary counters instead of the headline
                hit rate. The CALL SITE has to say so: ``set`` can infer it
                from ``_ancillary_keys`` because the key is present, but a
                miss is precisely the case where it is not — and in the
                workload fid 127 reported, essentially every polluting
                lookup was a first-time miss, so a hit-side-only split would
                have fixed nothing.

        Returns:
            Cached value or None if not found/expired
        """
        if not self.config.enabled:
            return None

        with self._lock:
            if key not in self._cache:
                self._count_miss(ancillary)
                return None

            entry = self._cache[key]

            # Check if expired
            if entry.is_expired():
                self._remove(key)
                self._count_miss(ancillary)
                logger.debug(f"Cache entry expired: {key}")
                return None

            self._touch(key)
            if ancillary:
                self._ancillary_hits += 1
            else:
                self._hits += 1
            logger.debug(f"Cache hit: {key}")
            return entry.value

    def _count_miss(self, ancillary: bool) -> None:
        """Charge a miss to the right counter (lock held)."""
        if ancillary:
            self._ancillary_misses += 1
        else:
            self._misses += 1

    def _counts_toward_cap(self, ancillary: bool) -> bool:
        """Whether an entry flagged ``ancillary`` is charged to ``max_size``.

        Fragments are exempt only while a byte budget exists to bound them;
        with ``max_bytes=0`` the count cap is the sole limit and must apply
        to everything.
        """
        return not ancillary or getattr(self.config, "max_bytes", 0) <= 0

    def _primary_count(self) -> int:
        """Entries charged to ``max_size`` (must be called with lock held)."""
        return len(self._cache) - len(self._ancillary_keys)

    def _validate_persistable(self, key: str, value: Any) -> None:
        """Reject a value the persisted cache could not round-trip.

        Only the persisted path needs JSON guarantees; pure in-memory caches
        still accept arbitrary Python objects.
        """
        if not self._persistence_enabled:
            return
        try:
            json.dumps(value)
        except (TypeError, ValueError) as exc:
            raise OpenZimMcpValidationError(
                f"Cache value for key {key!r} is not JSON-serializable; "
                f"persistence is enabled so the value must be JSON-safe.",
                details=str(exc),
            ) from exc

    def _release_bytes(self, size_bytes: int) -> None:
        """Uncharge a departing entry's bytes, clamped at zero (lock held)."""
        self._total_bytes -= size_bytes
        if self._total_bytes < 0:
            self._total_bytes = 0

    def _touch(self, key: str) -> None:
        """Stamp ``key`` as most recently used (must be called with lock held).

        Pushes a fresh ``(counter, key)`` pair onto the heap; any older pair
        for the same key is now stale and gets skipped lazily by
        ``_evict_lru``.
        """
        self._access_counter += 1
        access_counter = self._access_counter
        self._access_order[key] = access_counter
        heapq.heappush(self._lru_heap, (access_counter, key))

    def _make_room_for_charged(self, key: str) -> None:
        """Free a ``max_size`` slot before a charged entry lands (lock held).

        Only a set that *adds* a charged entry needs a slot: a new key, or an
        existing fragment being promoted. Overwriting a charged key in place
        does not. Eviction takes the least recently used entry regardless of
        kind — a fragment goes too when it is the oldest.
        """
        if key in self._cache and key not in self._ancillary_keys:
            return
        while self._cache and self._primary_count() >= self.config.max_size:
            self._evict_lru()

    def _enforce_byte_budget(self) -> None:
        """Evict LRU entries until ``_total_bytes`` fits ``max_bytes`` (lock held).

        Skipped when the cap is 0 (disabled) or when the cache only holds a
        single entry: one oversized value can legitimately exceed the cap,
        and the count cap still bounds entry count.
        """
        max_bytes = getattr(self.config, "max_bytes", 0)
        if max_bytes <= 0:
            return
        while self._total_bytes > max_bytes and len(self._cache) > 1:
            self._evict_lru()

    def set(self, key: str, value: Any, *, ancillary: bool = False) -> None:
        """
        Set value in cache (thread-safe).

        Args:
            key: Cache key
            value: Value to cache
            ancillary: Mark the entry as a per-item fragment (e.g. one
                rendered snippet per search result) rather than a whole
                response. ``max_size`` counts responses; fragments are
                exempt from it and bounded by ``max_bytes`` alone, so a
                single wide search cannot flush every other client's warm
                responses while memory sits far below the byte budget.
                They still participate in LRU eviction under byte pressure.

        Raises:
            OpenZimMcpValidationError: When persistence is enabled and the
                value is not JSON-serializable. Surfacing the error at write
                time prevents silent ``str()`` coercion on save (M21) — a
                ``Path`` or ``datetime`` round-tripped through persistence
                would otherwise come back as a plain string and lose its
                type.
        """
        if not self.config.enabled:
            return

        self._validate_persistable(key, value)

        with self._lock:
            charged = self._counts_toward_cap(ancillary)
            if charged:
                self._make_room_for_charged(key)

            # Replace path: drop the old entry's byte count first so
            # ``_total_bytes`` stays accurate when the same key is reset
            # with a value of different size.
            prior = self._cache.get(key)
            if prior is not None:
                self._release_bytes(prior.size_bytes)

            # Add/update entry
            entry = CacheEntry(value, self.config.ttl_seconds)
            self._cache[key] = entry
            if charged:
                self._ancillary_keys.discard(key)
            else:
                self._ancillary_keys.add(key)
            self._total_bytes += entry.size_bytes
            self._touch(key)
            logger.debug(
                f"Cache set: {key} ({entry.size_bytes} bytes, total "
                f"{self._total_bytes} bytes)"
            )

            self._enforce_byte_budget()

    def delete(self, key: str) -> None:
        """
        Delete a specific key from cache (thread-safe).

        Args:
            key: Cache key to delete
        """
        if not self.config.enabled:
            return

        with self._lock:
            if key in self._cache:
                self._remove(key)
                logger.debug(f"Cache entry deleted: {key}")

    def _remove(self, key: str) -> None:
        """Remove entry from cache (must be called with lock held)."""
        entry = self._cache.pop(key, None)
        if entry is not None:
            self._release_bytes(entry.size_bytes)
        self._access_order.pop(key, None)
        self._ancillary_keys.discard(key)

    def _cleanup_expired(self) -> None:
        """Remove all expired entries (thread-safe).

        Also compacts the LRU heap when stale entries dominate. get()/set()
        push a new (access_counter, key) on every access for lazy LRU;
        without compaction the heap grows unboundedly with total operations
        rather than with cache size.
        """
        with self._lock:
            expired_keys = [
                key for key, entry in self._cache.items() if entry.is_expired()
            ]

            for key in expired_keys:
                self._remove(key)

            if expired_keys:
                logger.debug(f"Cleaned up {len(expired_keys)} expired cache entries")

            # Compact the heap when it grew well past the live cache size.
            # 4x is a cheap heuristic — small enough to keep memory bounded,
            # large enough that we don't rebuild the heap on every cleanup.
            if len(self._lru_heap) > 4 * max(len(self._access_order), 1):
                self._lru_heap = [(t, k) for k, t in self._access_order.items()]
                heapq.heapify(self._lru_heap)
                logger.debug(f"Compacted LRU heap to {len(self._lru_heap)} entries")

    def _evict_lru(self) -> None:
        """Evict least recently used entry using heap (must be called with lock held).

        Uses lazy deletion: entries in heap may be stale if key was accessed again
        or removed. We skip invalid entries until we find a valid one to evict.
        """
        while self._lru_heap:
            # Pop the oldest entry from heap
            access_counter, key = heapq.heappop(self._lru_heap)

            # Check if this entry is still valid (not stale)
            # An entry is valid if:
            # 1. The key still exists in cache
            # 2. The access counter matches (not updated since)
            if key in self._access_order and self._access_order[key] == access_counter:
                self._remove(key)
                logger.debug(f"Evicted LRU cache entry: {key}")
                return

            # Entry is stale (key was removed or accessed more recently), skip it

        # Fallback: if heap is empty but cache has entries, use linear scan
        # This shouldn't happen in normal operation but provides safety
        if self._access_order:
            lru_key = min(
                self._access_order.keys(), key=lambda k: self._access_order[k]
            )
            self._remove(lru_key)
            logger.debug(f"Evicted LRU cache entry (fallback): {lru_key}")

    def clear(self) -> None:
        """Clear all cache entries and reset statistics (thread-safe)."""
        with self._lock:
            self._cache.clear()
            self._access_order.clear()
            self._lru_heap.clear()
            self._ancillary_keys.clear()
            self._total_bytes = 0
            self._hits = 0
            self._misses = 0
            self._ancillary_hits = 0
            self._ancillary_misses = 0
        logger.info("Cache cleared")

    def stats(self) -> Dict[str, Any]:
        """Get cache statistics including hit/miss rates (thread-safe)."""
        with self._lock:
            total_requests = self._hits + self._misses
            hit_rate = self._hits / total_requests if total_requests > 0 else 0.0

            stats = {
                "enabled": self.config.enabled,
                # ``size`` measures exactly what ``max_size`` bounds, so
                # ``size <= max_size`` always holds. Per-item fragments are
                # exempt from the count cap (bounded by ``max_bytes``) and
                # reported separately; ``total_entries`` is the sum.
                "size": self._primary_count(),
                "max_size": self.config.max_size,
                "ancillary_entries": len(self._ancillary_keys),
                "total_entries": len(self._cache),
                "size_bytes": self._total_bytes,
                "max_bytes": getattr(self.config, "max_bytes", 0),
                "ttl_seconds": self.config.ttl_seconds,
                # Response lookups only — see ``get(ancillary=...)``. What
                # a reader (and ``_append_cache_recommendations``) means by
                # "hit rate" is whether repeating work was avoided for a
                # client, and a fragment lookup is not a client asking twice.
                "hits": self._hits,
                "misses": self._misses,
                "hit_rate": round(hit_rate, 4),
                # Kept visible rather than discarded: the fragment cache is a
                # real cache whose behaviour is worth seeing, it is just not
                # the number the recommendation is about.
                "ancillary_hits": self._ancillary_hits,
                "ancillary_misses": self._ancillary_misses,
                "background_cleanup": (
                    self._cleanup_thread is not None and self._cleanup_thread.is_alive()
                ),
                "persistence_enabled": self._persistence_enabled,
            }

            # Add persistence file info if enabled
            if self._persistence_enabled:
                persistence_file = self._get_persistence_file()
                stats["persistence_path"] = str(persistence_file)
                stats["persistence_file_exists"] = persistence_file.exists()

            # Only present when persistence is actually broken, so a health
            # report can turn it into a warning instead of "running
            # optimally". Reported whether or not persistence is still
            # enabled: an unwritable directory disables it at startup, and
            # silently reporting ``persistence_enabled: false`` for a server
            # the operator configured with persistence on is the same silence
            # in a different place.
            if self._persistence_error is not None:
                stats["persistence_error"] = self._persistence_error

            return stats

    def shutdown(self) -> None:
        """Shutdown the cache and stop background threads."""
        self._stop_cleanup_thread()
        if self._persistence_enabled:
            self._save_to_disk()
        # Deregister our atexit handlers now that we've run their work
        # explicitly — prevents accumulation across repeated construction
        # and stops stale handlers from clobbering a newer instance's
        # persisted snapshot at interpreter exit.
        for handler in (self._atexit_save_handler, self._atexit_stop_handler):
            if handler is not None:
                atexit.unregister(handler)
        self._atexit_save_handler = None
        self._atexit_stop_handler = None
        logger.debug("Cache shutdown complete")

    def _get_persistence_file(self) -> Path:
        """Get the path to the persistence file.

        The extension is APPENDED, never substituted: ``with_suffix``
        replaces the text after the last dot, so ``openzim.prod`` and
        ``openzim.dev`` would silently collide onto one ``openzim.json``
        snapshot — breaking the per-instance isolation an explicit
        ``persistence_path`` promises.
        """
        if self._persistence_path.suffix == CACHE_FILE_EXTENSION:
            return self._persistence_path
        return self._persistence_path.with_name(
            self._persistence_path.name + CACHE_FILE_EXTENSION
        )

    @staticmethod
    def _snapshot_id(persistence_file: Path) -> Optional[Tuple[int, int]]:
        """A cheap identity for the snapshot on disk: (mtime_ns, size)."""
        try:
            stat = persistence_file.stat()
        except OSError:
            return None
        return (stat.st_mtime_ns, stat.st_size)

    def _discard_own_empty_snapshot(self, persistence_file: Path) -> None:
        """Remove the snapshot on disk, but only if this instance wrote it.

        Deleting unconditionally made an *idle* peer destroy a warm cache.
        Two MCP clients on one desktop each spawn their own stdio server with
        identical default config, so they share one default snapshot path;
        whichever one the user happened not to query saved nothing at exit and
        unlinked the other's file, which is how an opt-in accelerator came to
        do nothing at all for the multi-client setup it is aimed at.

        Having nothing to save is not evidence that the file on disk is stale
        — only that *this* process has nothing in it. So the file is removed
        only when it is byte-for-byte the one this instance last wrote; a
        snapshot we never wrote, or one a peer has replaced since, is left
        alone and ages out through its own TTLs on load.
        """
        if self._saved_snapshot_id is None:
            logger.debug(
                "Empty cache: leaving %s alone, this instance never wrote it",
                persistence_file,
            )
            return
        if self._snapshot_id(persistence_file) != self._saved_snapshot_id:
            logger.debug(
                "Empty cache: leaving %s alone, another writer replaced it",
                persistence_file,
            )
            return
        # ``missing_ok``: a peer process saving the same file may have
        # removed it between the check and the call.
        persistence_file.unlink(missing_ok=True)
        self._saved_snapshot_id = None
        logger.debug("Removed empty cache persistence file")

    def _save_to_disk(self) -> None:
        """Save cache contents to disk for persistence.

        Only saves non-expired entries. Thread-safe.
        """
        if not self._persistence_enabled:
            return

        try:
            # Hold the lock for the whole snapshot+write so concurrent set/
            # delete calls can't be silently dropped between the snapshot and
            # the rename, and so the empty-cache file deletion doesn't race
            # with a concurrent set().
            with self._lock:
                # Collect non-expired entries. created_at is monotonic
                # in memory; convert to wall-clock for persistence so the
                # data is meaningful across process restarts.
                entries_to_save: Dict[str, Dict[str, Any]] = {}
                now_monotonic = time.monotonic()
                now_wall = time.time()
                for key, entry in self._cache.items():
                    # Clamp on the save side too: an already-poisoned in-memory
                    # entry (created_at in the future) would otherwise be
                    # written back with a future wall-clock timestamp and
                    # re-poison itself on every restart.
                    age = max(0.0, now_monotonic - entry.created_at)
                    if age <= entry.ttl_seconds:
                        saved: Dict[str, Any] = {
                            "value": entry.value,
                            "created_at": now_wall - age,
                            "ttl_seconds": entry.ttl_seconds,
                        }
                        # Only written when set, so snapshots without
                        # fragments keep the pre-existing v1 layout.
                        if key in self._ancillary_keys:
                            saved["ancillary"] = True
                        entries_to_save[key] = saved

                persistence_file = self._get_persistence_file()

                if not entries_to_save:
                    self._discard_own_empty_snapshot(persistence_file)
                    return

                persistence_file.parent.mkdir(parents=True, exist_ok=True)

                # Write to a UNIQUE temp file first, then rename for
                # atomicity. The temp name must not be derived from
                # ``persistence_file`` — a fixed ``.tmp`` sibling is shared by
                # every process pointed at the same persistence path (stdio
                # servers are spawned one per client and each saves from
                # ``atexit``), so two savers interleaved their writes into one
                # file and the survivor renamed a truncated, unparseable
                # snapshot into place. ``mkstemp`` gives each writer its own
                # file in the same directory, so ``os.replace`` — atomic
                # within a filesystem — degrades the race to last-writer-wins.
                #
                # We deliberately omit ``default=str``: ``cache.set`` already
                # validates JSON-serializability when persistence is enabled
                # (see :meth:`set`), so any non-JSON value reaching this
                # point is a bug we want to surface rather than silently
                # coerce to a ``str()`` repr that loses type information on
                # reload.
                fd, temp_name = tempfile.mkstemp(
                    dir=str(persistence_file.parent),
                    prefix=f".{persistence_file.name}.",
                    suffix=".tmp",
                )
                replaced = False
                try:
                    with open(fd, "w", encoding="utf-8") as f:
                        json.dump(
                            {
                                "version": 1,
                                "saved_at": now_wall,
                                "entries": entries_to_save,
                            },
                            f,
                            indent=2,
                        )
                        # Flush + fsync before the rename so a crash between
                        # the two cannot publish a zero-length file.
                        f.flush()
                        os.fsync(f.fileno())
                    os.replace(temp_name, str(persistence_file))
                    replaced = True
                    # Remember exactly what we published, so a later empty
                    # save can tell our own snapshot from a peer's.
                    self._saved_snapshot_id = self._snapshot_id(persistence_file)
                finally:
                    # Never leave the unique temp behind on failure. ``finally``
                    # rather than ``except BaseException``: this must also clean
                    # up when the interpreter is tearing down (KeyboardInterrupt
                    # landing in the ``atexit`` save), but nothing here should
                    # intercept such an exit — ``finally`` runs the cleanup and
                    # lets it propagate untouched.
                    #
                    # Guarded on ``replaced`` because a successful ``os.replace``
                    # consumed the temp name, and a concurrent saver's ``mkstemp``
                    # may already have reused it.
                    if not replaced:
                        with contextlib.suppress(OSError):
                            os.unlink(temp_name)
                logger.debug(f"Saved {len(entries_to_save)} cache entries to disk")
                self._persistence_error = None

        except Exception as e:
            # Recorded as well as logged: the log line lands on stderr at
            # process exit, which is after the last moment anyone could act
            # on it, so ``stats()`` carries it to ``zim_health`` too.
            self._persistence_error = f"cannot write {self._persistence_path} ({e})"
            logger.warning(f"Failed to save cache to disk: {e}")

    def _restore_entry(
        self, key: str, entry_data: Any, now_wall: float, now_monotonic: float
    ) -> bool:
        """Restore a single cache entry from its serialized form.

        Returns True if the entry was loaded, False if it was skipped because
        it had already expired. Raises on malformed input so the caller can
        log and continue.
        """
        if not isinstance(entry_data, dict):
            raise ValueError("entry payload is not a dict")
        if "value" not in entry_data:
            raise ValueError("entry missing 'value' field")

        created_at = entry_data.get("created_at", 0)
        ttl_seconds = entry_data.get("ttl_seconds", self.config.ttl_seconds)

        # Skip expired entries (compare wall-clock-to-wall-clock).
        # Clamp: a persisted timestamp ahead of our wall clock (NTP step-back,
        # snapshot restore, file copied from a fast-clock host) must not grant
        # bonus TTL by producing a monotonic created_at in the future.
        if not isinstance(created_at, (int, float)) or isinstance(created_at, bool):
            raise ValueError("entry 'created_at' is not numeric")
        age = max(0.0, now_wall - created_at)
        if age > ttl_seconds:
            return False

        # Restore entry. CacheEntry.__init__ stamps a monotonic created_at;
        # rewind it by the entry's age so remaining TTL is preserved across
        # the restart.
        entry = CacheEntry(entry_data["value"], ttl_seconds)
        entry.created_at = now_monotonic - age
        self._cache[key] = entry
        # Re-apply the fragment marker under the *current* config: a
        # snapshot written with a byte budget may be loaded without one, in
        # which case fragments must be charged to the count cap again.
        if not self._counts_toward_cap(bool(entry_data.get("ancillary", False))):
            self._ancillary_keys.add(key)
        # ``_total_bytes`` must reflect every cached entry's size — without
        # this, ``max_bytes`` enforcement in ``set()`` reads zero across a
        # warm-start (the eviction loop's ``while self._total_bytes > max_bytes``
        # never fires on already-loaded entries) and the byte budget is
        # silently inoperative until enough new sets accumulate to cross
        # the threshold from zero. ``set()`` and ``_remove()`` maintain
        # this invariant; ``_restore_entry`` was the lone gap.
        self._total_bytes += entry.size_bytes

        # Assign a fresh access_counter value to preserve LRU ordering across
        # restart. Loaded entries get successively higher counters in
        # iteration order; live operations after restart continue from a
        # higher counter.
        self._touch(key)
        return True

    def _load_from_disk(self) -> None:
        """Load cache contents from disk.

        Skips expired entries and entries with non-deserializable values.
        """
        if not self._persistence_enabled:
            return

        persistence_file = self._get_persistence_file()
        if not persistence_file.exists():
            logger.debug("No cache persistence file found")
            return

        try:
            # Hold ``_lock`` across the file read AND the entry restore.
            # The window between ``json.load()`` and lock acquisition was
            # narrow (this is normally called from ``__init__`` before
            # other threads hold a reference to the cache) but a test
            # fixture sharing a server instance across threads could race
            # a concurrent ``clear()`` or ``set()`` against the loaded
            # snapshot. JSON parse inside the critical section adds a
            # brief one-time blocking window at startup with no
            # contention in production.
            with self._lock:
                with open(persistence_file, "r", encoding="utf-8") as f:
                    data = json.load(f)

                if data.get("version") != 1:
                    logger.warning(
                        f"Unsupported cache persistence version: "
                        f"{data.get('version')}"
                    )
                    return

                entries = data.get("entries", {})
                now_wall = time.time()
                now_monotonic = time.monotonic()
                loaded_count = 0
                skipped_count = 0

                for key, entry_data in entries.items():
                    # Per-entry try/except so a single malformed entry
                    # doesn't abort the load of every other valid entry.
                    try:
                        if self._restore_entry(
                            key, entry_data, now_wall, now_monotonic
                        ):
                            loaded_count += 1
                    except Exception as entry_err:
                        skipped_count += 1
                        logger.debug(
                            f"Skipped malformed cache entry {key!r}: {entry_err}"
                        )

                # Enforce the configured caps against the loaded snapshot.
                # A persistence file written under one config can be loaded
                # under a smaller ``max_size`` / ``max_bytes`` (operator
                # tightened limits between restarts). Without these passes,
                # the loaded cache violates the configured cap until enough
                # new sets force eviction. Eviction here uses the same LRU
                # heap that ``set()`` maintains.
                while self._cache and self._primary_count() > self.config.max_size:
                    self._evict_lru()
                self._enforce_byte_budget()

            if skipped_count:
                logger.warning(
                    f"Loaded {loaded_count} cache entries from disk; "
                    f"skipped {skipped_count} malformed entries"
                )
            else:
                logger.info(f"Loaded {loaded_count} cache entries from disk")

        except json.JSONDecodeError as e:
            logger.warning(f"Failed to parse cache persistence file: {e}")
        except Exception as e:
            logger.warning(f"Failed to load cache from disk: {e}")
