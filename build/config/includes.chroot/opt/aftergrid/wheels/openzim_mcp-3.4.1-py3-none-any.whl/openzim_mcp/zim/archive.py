"""Archive coordinator module.

Holds the ``ZimOperations`` class, the ``zim_archive`` context manager,
and the small set of shared helpers/constants that don't fit a single
domain mixin.

This module is the source of truth for ``ZimOperations`` and the
module-level ZIM-archive primitives. ``openzim_mcp.zim_operations``
re-exports the public names for backward compatibility.

Layout:

* ``zim_archive`` — context manager that opens an archive with a timeout
  and surfaces a consistent error type.
* ``ZimOperations`` — coordinator class that mixes in
  ``_SearchMixin``/``_ContentMixin``/``_StructureMixin``/``_NamespaceMixin``
  for the bulk of the surface. Methods that don't fit a single domain
  (file listing, archive metadata, main-page lookup) live directly on
  the class here.
"""

import hashlib
import logging
import multiprocessing
import os
import re
import struct
import threading
from concurrent.futures import ProcessPoolExecutor
from concurrent.futures.process import BrokenProcessPool
from contextlib import contextmanager, suppress
from datetime import datetime
from pathlib import Path
from typing import TYPE_CHECKING, Any, Dict, Generator, List, Optional, Tuple, cast

import libzim  # type: ignore[import-untyped]
from libzim.reader import Archive  # type: ignore[import-untyped]
from libzim.search import (  # type: ignore[import-untyped]
    Query,
    Searcher,
)
from libzim.suggestion import (  # type: ignore[import-untyped]
    SuggestionSearcher,
)

from openzim_mcp.archive_types import detect_archive_type
from openzim_mcp.cache import OpenZimMcpCache
from openzim_mcp.config import OpenZimMcpConfig
from openzim_mcp.constants import DEFAULT_MAIN_PAGE_TRUNCATION
from openzim_mcp.content_processor import ContentProcessor
from openzim_mcp.defaults import CONTENT
from openzim_mcp.error_messages import url_shaped_path_hint
from openzim_mcp.exceptions import (
    ArchiveOpenTimeoutError,
    OpenZimMcpArchiveError,
    OpenZimMcpEntryNotFoundError,
)
from openzim_mcp.meta import attach_meta
from openzim_mcp.onboarding import acquisition_hint_markdown
from openzim_mcp.preset_data import ArchivePreset, resolve_preset_from_entries
from openzim_mcp.recovery_advice import locate_entry
from openzim_mcp.security import PathValidator
from openzim_mcp.timeout_utils import run_with_timeout
from openzim_mcp.zim._ops_base import _ArchiveAccessMixin, _json
from openzim_mcp.zim.content import _ContentMixin, rewrite_well_known_path
from openzim_mcp.zim.namespace import _NamespaceMixin
from openzim_mcp.zim.redirects import resolve_redirect_chain
from openzim_mcp.zim.search import _SearchMixin
from openzim_mcp.zim.structure import _StructureMixin

if TYPE_CHECKING:
    from openzim_mcp.tool_schemas import (
        ArchiveValidationResponse,
        EntryResponse,
        ListZimFilesResponse,
        ZimMetadataResponse,
    )

__all__ = [
    "ARCHIVE_OPEN_TIMEOUT",
    "Archive",
    "MAX_REDIRECT_DEPTH",
    "Query",
    "Searcher",
    "SuggestionSearcher",
    "ZIM_MAGIC",
    "ZimOperations",
    "check_archive_integrity",
    "configure_libzim_caches",
    "has_zim_signature",
    "is_truncated_zim",
    "unreadable_zim_warning",
    "zim_archive",
    "zim_signature_error",
]


# Timeout for opening ZIM archives (seconds)
ARCHIVE_OPEN_TIMEOUT = 30.0

# Every ZIM file starts with the little-endian magic number 72173914
# (0x044D495A). Checking these four bytes needs no libzim call, but it is only
# half a readability probe: a truncated download keeps them (see
# ``is_truncated_zim``).
ZIM_MAGIC = b"ZIM\x04"

# A complete ZIM header is 80 bytes and ends with ``checksumPos`` — a
# little-endian uint64 at offset 72 holding the offset of the 16-byte MD5 that
# closes the file. ``checksumPos + 16`` is therefore the total size the archive
# declares for itself, which is what makes a half-finished download detectable
# without reading (or checksumming) a single byte of its body.
ZIM_HEADER_SIZE = 80
_ZIM_CHECKSUM_POS_OFFSET = 72
_ZIM_CHECKSUM_LENGTH = 16

# Message attached to listing entries whose file fails the signature probe.
UNREADABLE_ZIM_WARNING = (
    "Not a ZIM archive: the file does not start with the ZIM signature "
    "and cannot be opened"
)

# Message for a file that starts like a ZIM archive but stops short of the
# size its own header declares. Kept distinct from UNREADABLE_ZIM_WARNING
# because the remedy is the opposite of "replace this junk file": the archive
# is the right one, the transfer is what failed.
TRUNCATED_ZIM_WARNING = (
    "Truncated ZIM archive: the file is smaller than its own header says it "
    "should be, so it cannot be opened — re-download it"
)

# Message for a listing entry this process is not allowed to read at all.
# Kept distinct from UNREADABLE_ZIM_WARNING: the file may be a perfectly good
# archive, and the fix is a permission change, not a deletion.
DENIED_ZIM_WARNING = (
    "Cannot read this file: the server lacks permission to open it, so "
    "whether it is a ZIM archive is unknown"
)


def zim_signature_error(path: Path) -> Optional[OSError]:
    """The error that stopped ``path`` from being read, or None if it was read.

    ``has_zim_signature`` collapses "could not open the file" into the same
    ``False`` as "opened it, and it is not a usable archive", which is right
    for "can libzim use this?" and wrong for telling an operator what to do about it:
    a permission problem answered with "not a ZIM archive, delete it"
    destroys a good archive. Callers that give advice ask this first.
    """
    try:
        with open(path, "rb") as fh:
            fh.read(len(ZIM_MAGIC))
        return None
    except OSError as e:
        return e


def _declared_zim_size(header: bytes) -> Optional[int]:
    """Total file size ``header`` claims for itself, or None if it makes none.

    Returns None when the header is too short to carry ``checksumPos`` or the
    field is zero (an archive written without a checksum): there is then no
    claim to compare a file size against, and inventing one would condemn a
    good archive.
    """
    if len(header) < ZIM_HEADER_SIZE:
        return None
    (checksum_pos,) = struct.unpack_from("<Q", header, _ZIM_CHECKSUM_POS_OFFSET)
    if not checksum_pos:
        return None
    return int(checksum_pos) + _ZIM_CHECKSUM_LENGTH


def is_truncated_zim(path: Path) -> bool:
    """Return whether ``path`` stops short of the size its header declares.

    This is the shape an interrupted multi-GB Kiwix download leaves behind —
    the single most common way a first-run install ends up broken. The magic
    bytes survive a truncation, so a probe that reads only those calls the
    file readable and every later query then fails; comparing the on-disk
    size against the header's own ``checksumPos`` costs one ``stat`` and
    catches it. A file *longer* than its declared size is not truncated (it
    may carry an appended payload) and is left to libzim to judge.
    """
    try:
        with open(path, "rb") as fh:
            header = fh.read(ZIM_HEADER_SIZE)
        # v3.3.1 field report: this used to read bytes 72..79 as a declared
        # size WITHOUT re-checking the magic — and it is only ever reached
        # after ``has_zim_signature`` already returned False, i.e. for files
        # that failed the magic check. For any readable non-ZIM file of at
        # least ``ZIM_HEADER_SIZE`` bytes those bytes are effectively random
        # and almost always form a huge value, so a stray text file renamed
        # ``.zim`` was reported as a truncated download and the user was told
        # to re-fetch it. That is the opposite of the remedy they need, and it
        # inverts the very distinction this warning exists to draw.
        if header[: len(ZIM_MAGIC)] != ZIM_MAGIC:
            return False
        # The magic is right but the file is too short to even carry a
        # header: a real archive always has all ``ZIM_HEADER_SIZE`` bytes, so
        # this IS an interrupted download — it simply stopped early enough
        # that there is no ``checksumPos`` to compare against.
        if len(header) < ZIM_HEADER_SIZE:
            return True
        declared = _declared_zim_size(header)
        if declared is None:
            return False
        return path.stat().st_size < declared
    except OSError:
        return False


def has_zim_signature(path: Path) -> bool:
    """Return whether ``path`` looks like an archive libzim could open.

    A ``False`` result means the file is not an openable archive (plain
    text, a truncated download, a stray file renamed ``.zim``). Two cheap
    probes back that claim: the ZIM magic bytes, and — since a half-finished
    download keeps those — the header's own declared total size against the
    size on disk (see ``is_truncated_zim``). A ``True`` result remains only a
    plausibility check: it does not verify the archive's integrity, which is
    what ``Archive.check()`` is for. Read errors (permissions, vanished file)
    count as unreadable; use ``zim_signature_error`` to tell those two apart.
    """
    try:
        with open(path, "rb") as fh:
            header = fh.read(ZIM_HEADER_SIZE)
    except OSError:
        return False
    if header[: len(ZIM_MAGIC)] != ZIM_MAGIC:
        return False
    declared = _declared_zim_size(header)
    if declared is None:
        return True
    try:
        return path.stat().st_size >= declared
    except OSError:
        # The bytes read fine a moment ago; a stat that fails now says
        # nothing about the archive, so keep the signature's verdict.
        return True


def unreadable_zim_warning(path: Path) -> str:
    """The listing warning for a readable file ``has_zim_signature`` rejected.

    Separates the two remedies: a truncated download must be fetched again,
    while a file that never was an archive must be removed or replaced.
    """
    return TRUNCATED_ZIM_WARNING if is_truncated_zim(path) else UNREADABLE_ZIM_WARNING


# ---------------------------------------------------------------------------
# Integrity-check worker process
#
# python-libzim's ``Archive.check()`` binding does not release the GIL
# (unlike the entry/cluster readers in the same module), so running the
# whole-file checksum on a worker thread still stalls every coroutine in this
# process for the duration — seconds on a 2 GB archive, minutes on a 90 GB
# one — including MCP keepalive pings from every connected client. The only
# way to keep the event loop responsive is to run the check in a separate
# process; the parent thread then blocks in a future wait, which does release
# the GIL.
#
# One lazily spawned worker is enough: validation is a rare, explicit
# diagnostic, and serialising checks bounds the cost to one extra
# interpreter. ``spawn`` (never ``fork``): the parent holds libzim handles,
# thread pools, and a running asyncio loop that must not be duplicated.
# ---------------------------------------------------------------------------

_VALIDATION_POOL: Optional[ProcessPoolExecutor] = None
_VALIDATION_POOL_LOCK = threading.Lock()

# None until a worker has been asked to start: True once one has, False once
# one has failed to. See ``_validation_pool``.
_WORKERS_START: Optional[bool] = None


def _worker_started() -> bool:
    """Worker-process body for the bootstrap probe. Module-level to be picklable."""
    return True


def _validation_pool() -> ProcessPoolExecutor:
    """Return the shared single-worker validation pool, spawning it on first use.

    The pool is probed with a no-op before it is kept, because ``spawn``
    re-executes the host's ``__main__`` in the child: an embedding script
    without an ``if __name__ == "__main__":`` guard kills every worker in
    bootstrap, forever. Probing separates that from a worker a particular
    archive crashes — the first has to be worked around, the second must stay
    a failed validation rather than take this process down with it.
    """
    global _VALIDATION_POOL, _WORKERS_START
    with _VALIDATION_POOL_LOCK:
        if _VALIDATION_POOL is None:
            pool = ProcessPoolExecutor(
                max_workers=1, mp_context=multiprocessing.get_context("spawn")
            )
            try:
                pool.submit(_worker_started).result()
            except BrokenProcessPool:
                pool.shutdown(wait=False, cancel_futures=True)
                _WORKERS_START = False
                raise
            _WORKERS_START = True
            _VALIDATION_POOL = pool
        return _VALIDATION_POOL


def _discard_validation_pool() -> None:
    """Drop a broken pool so the next validation spawns a fresh worker."""
    global _VALIDATION_POOL
    with _VALIDATION_POOL_LOCK:
        pool, _VALIDATION_POOL = _VALIDATION_POOL, None
    if pool is not None:
        pool.shutdown(wait=False, cancel_futures=True)


def _check_archive_integrity(path: str) -> bool:
    """Worker-process body: ``Archive.check()`` over ``path``.

    Module-level (not nested) so the spawn context can import it by name.
    """
    # The worker inherits the parent's descriptors, and on the stdio
    # transport fd 1 *is* the MCP wire. libzim chats on stdout when it opens
    # an index ("No stemming for language ..."), so point the child's stdout
    # at stderr before touching the archive.
    with suppress(OSError):
        os.dup2(2, 1)
    try:
        return bool(Archive(path).check())
    except Exception as e:
        # libzim's exceptions may not pickle across the process boundary;
        # re-raise as a plain RuntimeError that does.
        raise RuntimeError(f"{type(e).__name__}: {e}") from None


def _check_here(path: Path) -> bool:
    """``Archive.check()`` in this process, for hosts where no worker starts.

    Stalls this interpreter for the whole pass — the very thing the worker
    exists to avoid — but a host that cannot spawn one is better served by a
    slow answer than by a validation that can never succeed.
    """
    logger.warning(
        "Integrity-check workers cannot start in this process (spawn "
        "re-executes the host's __main__; an embedding script needs an "
        'if __name__ == "__main__": guard). Checking %s in-process, which '
        "blocks this interpreter until it finishes.",
        path,
    )
    return bool(Archive(str(path)).check())


def check_archive_integrity(path: Path) -> bool:
    """Run ``Archive.check()`` for ``path`` in the validation worker process.

    Falls back to this process when no worker can start at all; see
    ``_validation_pool``.

    Raises:
        OpenZimMcpArchiveError: if the worker died mid-check. The broken pool
            is discarded so the next call gets a fresh worker — a child crash
            must surface as a failed validation, never take the server down.
    """
    if _WORKERS_START is False:
        return _check_here(path)
    try:
        future = _validation_pool().submit(_check_archive_integrity, str(path))
        return bool(future.result())
    except BrokenProcessPool as e:
        _discard_validation_pool()
        if _WORKERS_START is False:
            return _check_here(path)
        raise OpenZimMcpArchiveError(
            f"Integrity check worker crashed while checking {path}"
        ) from e


# Maximum redirect chain length before bailing out. See
# ``ContentDefaults.MAX_REDIRECT_DEPTH`` in ``defaults.py``.
MAX_REDIRECT_DEPTH = CONTENT.MAX_REDIRECT_DEPTH

# Per-entry preview cap for ``_extract_zim_metadata``. Wikipedia ZIMs
# store ``M/Title`` as a full HTML document (~1 MB) rather than the
# archive's bare title string; without a cap, that single value dwarfs
# every other metadata field AND blows past the per-call response
# budget. 800 chars is enough to surface the actual title for archives
# that store it plain, AND a clear "[truncated, …]" marker for the
# pathological HTML-template case.
_METADATA_PREVIEW_CAP = 800


# Cheap heuristic: a value with one of these markers in its first ~200
# bytes is HTML and needs ``_extract_metadata_text`` to surface the
# real value. Anything else (Date, Tags, Counter, ...) is plain text
# and goes through unchanged.
_HTML_MARKERS = ("<!doctype html", "<html", "<head", "<title>")


# Optional per-archive dirent-cache size (number of cached dirents), applied
# to every archive opened via ``zim_archive``. ``None`` leaves libzim's
# default (512) untouched. The cluster cache, by contrast, is a *process*
# global tuned directly via ``libzim.set_cluster_cache_max_size`` — see
# ``configure_libzim_caches``. Stored at module scope because ``zim_archive``
# is a module-level function with no access to server config.
_LIBZIM_DIRENT_CACHE_MAX_COUNT: Optional[int] = None


def configure_libzim_caches(
    cluster_cache_max_size_bytes: Optional[int] = None,
    dirent_cache_max_count: Optional[int] = None,
) -> None:
    """Apply optional libzim cache tuning.

    libzim exposes two read-side caches with *different* units and scopes:

    * The cluster cache is sized in **bytes** and is a **process-global**
      setting (``libzim.set_cluster_cache_max_size``); the default is 16 MiB.
    * The dirent cache is sized as a **count of dirents** and is a
      **per-archive** property (``Archive.dirent_cache_max_size``); the
      default is 512. It is applied per-open in ``zim_archive`` from the
      module-level ``_LIBZIM_DIRENT_CACHE_MAX_COUNT`` set here.

    ``None`` for either argument leaves libzim's default in place.
    """
    global _LIBZIM_DIRENT_CACHE_MAX_COUNT
    if cluster_cache_max_size_bytes is not None:
        try:
            libzim.set_cluster_cache_max_size(cluster_cache_max_size_bytes)
            logger.info(
                "libzim cluster cache max size set to %d bytes (process-global)",
                cluster_cache_max_size_bytes,
            )
        except Exception as e:  # pragma: no cover — defensive across versions
            logger.debug("set_cluster_cache_max_size unavailable: %s", e)
    # Guard on None so a caller tuning only the cluster cache doesn't clobber
    # a dirent count another caller already set — ``None`` means "leave as-is",
    # not "reset to default" (symmetric with the cluster branch above).
    if dirent_cache_max_count is not None:
        _LIBZIM_DIRENT_CACHE_MAX_COUNT = dirent_cache_max_count


_COUNTER_COMPLETE_RE = re.compile(r"=\d+\s*$")


def _parse_counter_metadata(counter_str: str) -> Dict[str, int]:
    """Parse an ``M/Counter`` value into a ``{mimetype: count}`` mapping.

    The ``Counter`` metadata value is a ``;``-separated list of
    ``mimetype=count`` pairs (e.g. ``"text/html=123;image/png=45"``).

    A content-type may itself be *parameterized* and so contain ``;`` and
    ``=`` (e.g. ``image/svg+xml; charset=utf-8; profile="..."=575138``). A
    naive ``split(';')`` shatters those buckets and silently drops their
    counts, so we reassemble them: a fragment whose head (text before its
    first ``=``) looks like a ``type/subtype`` mimetype starts a new bucket;
    any other fragment is a parameter continuation of the still-open bucket
    (unless that bucket is already complete, in which case the stray
    fragment is dropped). The terminal ``=count`` is split off with
    ``rpartition`` so embedded ``param=value`` segments stay in the key.

    Malformed pairs — no terminal integer count — are skipped rather than
    failing the whole parse; metadata is best-effort.
    """
    breakdown: Dict[str, int] = {}

    def _emit(bucket: str) -> None:
        mime, sep, count_str = bucket.rpartition("=")
        count_str = count_str.strip()
        if not sep or not count_str.isdigit():
            logger.debug("Skipping malformed Counter pair: %r", bucket)
            return
        breakdown[mime.strip()] = int(count_str)

    current: Optional[str] = None
    for frag in counter_str.split(";"):
        head = frag.split("=", 1)[0].strip()
        starts_new_bucket = "/" in head and head[:1].isalnum()
        if starts_new_bucket:
            if current is not None:
                _emit(current)
            current = frag
        elif current is None:
            # Stray fragment with no open bucket (e.g. ``bad-pair``).
            continue
        elif _COUNTER_COMPLETE_RE.search(current):
            # Current bucket is already complete; the stray fragment is junk.
            continue
        else:
            current += ";" + frag
    if current is not None:
        _emit(current)
    return breakdown


def _extract_metadata_text(raw: str) -> str:
    """Distil an M-namespace value down to its readable text.

    Wikipedia (and other MediaWiki-derived) ZIMs wrap each metadata
    field in a full HTML document — the literal title string ``"en"``
    arrives as ``<!DOCTYPE html><html …><head>…<title>en</title>…``
    plus a body. ``_METADATA_PREVIEW_CAP`` alone can't recover from
    this: the cap clips inside the boilerplate prefix, every field
    looks identical, and the caller never sees the real value.

    Strategy:
      1. If the content doesn't look like HTML, return as-is.
      2. Parse via BeautifulSoup. Prefer ``<title>`` text (often the
         exact field value on Wikipedia-flavour exports). Fall back
         to visible ``<body>`` text with scripts/styles stripped.
      3. Collapse whitespace runs so multi-line HTML doesn't bleed
         into the preview.
      4. If parsing fails, return the raw input — the cap path will
         still produce a (less useful but honest) preview.
    """
    if not raw:
        return raw
    head = raw[:200].lstrip().lower()
    if not any(marker in head for marker in _HTML_MARKERS):
        return raw
    try:
        from bs4 import BeautifulSoup  # imported lazily; only needed for HTML metadata
    except Exception:
        return raw
    try:
        soup = BeautifulSoup(raw, "html.parser")
    except Exception:
        return raw
    # Prefer the body's visible text — on Wikipedia ZIMs the body
    # carries the actual field value (``en``, ``Wikipedia``,
    # ``The Free Encyclopedia``, ...), while ``<title>`` typically
    # echoes the M-key name (``Title``, ``Date``, ``Language``).
    # Strip script/style first so injected analytics don't leak
    # into the preview.
    for noise in soup(("script", "style", "noscript")):
        noise.decompose()
    body = soup.find("body")
    if body is not None:
        body_text = " ".join(body.get_text(separator=" ", strip=True).split())
        if body_text:
            return body_text
    # No body / empty body — fall back to <title>, then to all-text.
    title = soup.find("title")
    if title is not None:
        title_text = " ".join(title.get_text(separator=" ", strip=True).split())
        if title_text:
            return title_text
    return " ".join(soup.get_text(separator=" ", strip=True).split())


logger = logging.getLogger(__name__)


@contextmanager
def zim_archive(
    file_path: Path, timeout_seconds: float = ARCHIVE_OPEN_TIMEOUT
) -> Generator[Archive, None, None]:
    """Context manager for ZIM archive operations with resource cleanup and timeout.

    Args:
        file_path: Path to the ZIM file
        timeout_seconds: Maximum time to wait for archive to open (default: 30s)

    Yields:
        Archive object for reading ZIM content

    Raises:
        OpenZimMcpArchiveError: If archive fails to open or times out
    """

    # Open phase: wrap any failure as OpenZimMcpArchiveError so callers see
    # a consistent error type. This block must NOT contain the yield —
    # otherwise exceptions from the with-body get re-wrapped here as
    # misleading "Failed to open ZIM archive" errors.
    #
    # ``Archive`` is looked up on the ``openzim_mcp.zim_operations`` shim at
    # call time so tests that patch ``openzim_mcp.zim_operations.Archive``
    # see their patch take effect here. Late-binding via attribute lookup
    # also avoids any import cycle when the mixins import this module.
    import openzim_mcp.zim_operations as _zim_ops_shim

    def open_archive() -> Archive:
        archive = _zim_ops_shim.Archive(str(file_path))
        # Apply the optional per-archive dirent-cache size (count of
        # dirents). ``None`` leaves libzim's default. Guarded so a binding
        # that predates the settable property degrades silently.
        if _LIBZIM_DIRENT_CACHE_MAX_COUNT is not None:
            try:
                archive.dirent_cache_max_size = _LIBZIM_DIRENT_CACHE_MAX_COUNT
            except Exception as e:  # pragma: no cover — defensive across versions
                logger.debug("dirent_cache_max_size unavailable: %s", e)
        return archive

    try:
        archive = run_with_timeout(
            open_archive,
            timeout_seconds,
            f"Timed out opening ZIM archive after {timeout_seconds}s: {file_path}",
            ArchiveOpenTimeoutError,
        )
    except ArchiveOpenTimeoutError as e:
        raise OpenZimMcpArchiveError(str(e)) from e
    except Exception as e:
        # Carry libzim's own diagnosis into the message. Only the message
        # reaches an MCP client — the ``__cause__`` chain stops at this
        # process — and "Zim file(s) is of bad size or corrupted" vs
        # "zim-file is too small to contain a header" is the difference
        # between "re-download it" and "that is not an archive". Without it
        # a half-download, a renamed text file and a header stub all read as
        # one string. The path is already in the message, so nothing new is
        # disclosed.
        detail = " ".join(str(e).split())
        suffix = f" ({detail})" if detail else ""
        raise OpenZimMcpArchiveError(
            f"Failed to open ZIM archive: {file_path}{suffix}"
        ) from e

    logger.debug(f"Opened ZIM archive: {file_path}")
    try:
        yield archive
    finally:
        logger.debug(f"Releasing ZIM archive: {file_path}")


def _link_graph_report(archive_path: Any, live_uuid: str) -> Dict[str, Any]:
    """Describe the archive's link-graph sidecar for ``zim_health``.

    v3.3.1 field report (fid 91): nothing on any surface said whether an
    archive had a link graph, so the only way to find out was to issue an
    inbound call and read the failure. Every number here is already stored
    in the sidecar's own meta table, which the reader opens and discards.

    ``is_stale`` is the load-bearing part. Presence is not usability: a
    sidecar built for a different archive revision or an older schema
    refuses every inbound query, and a planner that saw only
    ``has_link_graph: true`` would keep issuing them. The staleness test
    repeats ``LinkGraphReader.open_for``'s two gates rather than calling it,
    because that function returns ``None`` for a stale sidecar and a stale
    one is exactly what this has to be able to describe.
    """
    try:
        from openzim_mcp.linkgraph.reader import read_sidecar_meta
        from openzim_mcp.linkgraph.schema import SCHEMA_VERSION

        meta = read_sidecar_meta(str(archive_path))
    except Exception:  # pragma: no cover — a probe must not fail a health call
        return {"has_link_graph": False}
    if meta is None:
        return {"has_link_graph": False}

    def _as_int(key: str) -> Optional[int]:
        try:
            return int(meta[key])
        except (KeyError, TypeError, ValueError):
            return None

    return {
        "has_link_graph": True,
        "link_graph": {
            "built_at": meta.get("built_at"),
            "builder_version": meta.get("builder_version"),
            "schema_version": meta.get("schema_version"),
            "node_count": _as_int("node_count"),
            "edge_count": _as_int("edge_count"),
            "is_stale": (
                meta.get("schema_version") != str(SCHEMA_VERSION)
                or meta.get("archive_uuid") != live_uuid
            ),
        },
    }


class ZimOperations(
    _ArchiveAccessMixin, _SearchMixin, _ContentMixin, _StructureMixin, _NamespaceMixin
):
    """Handles all ZIM file operations with caching and security.

    The bulk of the surface is contributed by domain mixins; this class
    holds the constructor and a handful of coordinator methods that
    don't fit a single domain (file listing, archive metadata, main-page
    lookup, and the shared entry-resolution fallback).
    """

    def __init__(
        self,
        config: OpenZimMcpConfig,
        path_validator: PathValidator,
        cache: OpenZimMcpCache,
        content_processor: ContentProcessor,
    ):
        """Initialize ZIM operations.

        Args:
            config: Server configuration
            path_validator: Path validation service
            cache: Cache service
            content_processor: Content processing service
        """
        self.config = config
        self.path_validator = path_validator
        self.cache = cache
        self.content_processor = content_processor
        # Apply optional libzim cache tuning from config. Only touches
        # process/global libzim state when at least one knob is set, so
        # the default configuration leaves libzim's behaviour unchanged.
        cluster_bytes = config.cache.libzim_cluster_cache_max_size_bytes
        dirent_count = config.cache.libzim_dirent_cache_max_count
        if cluster_bytes is not None or dirent_count is not None:
            configure_libzim_caches(
                cluster_cache_max_size_bytes=cluster_bytes,
                dirent_cache_max_count=dirent_count,
            )
        logger.info("ZimOperations initialized")

    def _glob_zim_paths(self) -> List[Tuple[Path, List[Path]]]:
        """Walk each allowed directory once for ``*.zim`` candidates.

        Single source of the ``glob("**/*.zim")`` traversal shared by the
        listing scan and its cache signature, so ``list_zim_files_data``
        walks the tree at most once per call (previously the signature and
        the scan each globbed independently — a redundant walk on every
        cache miss). Returns ``(directory, [candidate_paths])`` pairs; the
        raw candidates (before symlink/allowed-root filtering, which happens
        in :meth:`_scan_zim_files`) also drive the signature, so adding,
        removing, or renaming any ``.zim`` — even a to-be-rejected symlink —
        changes the signature and rebuilds the listing.
        """
        grouped: List[Tuple[Path, List[Path]]] = []
        for directory_str in self.config.allowed_directories:
            directory = Path(directory_str)
            # Resilience: a directory that can't be walked is skipped so the
            # signature and the scan degrade together rather than raising.
            try:
                grouped.append((directory, list(directory.glob("**/*.zim"))))
            except Exception as e:
                logger.debug("ZIM glob failed for %s: %s", directory_str, e)
        return grouped

    def _zim_dir_signature(self, grouped: List[Tuple[Path, List[Path]]]) -> str:
        """Content-free fingerprint of which ``.zim`` files currently exist.

        Folded into the ``list_zim_files_data`` cache key so that adding,
        removing, or renaming a ``.zim`` file in an allowed directory at
        runtime invalidates the cached listing instead of serving the prior
        snapshot until the TTL expires or the server restarts (issue #307).
        Built from the shared :meth:`_glob_zim_paths` walk, so it adds no
        traversal of its own.

        A path-set fingerprint (rather than a directory ``mtime``) is used
        deliberately: it is robust to coarse-resolution filesystem
        timestamps and detects nested-subdirectory changes, at the cost of
        one ``readdir`` per call. An in-place same-name replacement
        (identical path, new bytes) is intentionally not reflected here —
        that archive's *content* caches invalidate via their own
        ``archive_stat_token`` and the listing's stale size/mtime is bounded
        by the cache TTL.
        """
        paths = sorted(str(p) for _dir, files in grouped for p in files)
        blob = "\n".join(paths).encode("utf-8", "surrogatepass")
        # Not a security digest — just a stable fingerprint of the directory
        # contents for cache invalidation; usedforsecurity=False documents
        # that and silences the weak-hash warning (bandit B324).
        return hashlib.sha1(blob, usedforsecurity=False).hexdigest()[:16]

    def _scan_zim_files(  # NOSONAR(python:S3776)
        self, grouped: List[Tuple[Path, List[Path]]]
    ) -> List[Dict[str, Any]]:
        """Build the structured listing from the shared glob walk (uncached).

        Takes the ``(directory, candidate_paths)`` pairs from
        :meth:`_glob_zim_paths` so the tree is not re-globbed here.
        """
        logger.info(
            f"Searching for ZIM files in {len(self.config.allowed_directories)} "
            "directories:"
        )
        for dir_path in self.config.allowed_directories:
            logger.info(f"  - {dir_path}")

        all_zim_files: List[Dict[str, Any]] = []
        # Overlapping / nested allowed_directories (e.g. ``/data`` and
        # ``/data/wiki``) surface the same archive once per directory walk.
        # Duplicate rows also broke exactly-one auto-select. Dedupe by
        # resolved path; first (outermost-configured) sighting wins.
        seen_resolved: set = set()
        for directory, zim_files_in_dir in grouped:
            logger.debug(f"Scanning directory: {directory}")
            try:
                # ``Path.glob`` follows symlinks by default, which would let a
                # symlink inside an allowed directory point at a ZIM file
                # outside the allowed tree. Resolve each candidate and check
                # that it still lives under the directory we were told to
                # scan; reject otherwise (without raising — a stray symlink
                # in a watched directory is a misconfiguration, not a fatal
                # error).
                allowed_root = directory.resolve()
                logger.debug(f"Found {len(zim_files_in_dir)} ZIM files in {directory}")

                for file_path in zim_files_in_dir:
                    # ``is_file()`` follows symlinks, so a symlink to a real
                    # file passes it — verify membership in the allowed
                    # tree before accepting the entry.
                    if not file_path.is_file():
                        continue
                    try:
                        resolved = file_path.resolve()
                    except OSError as e:
                        logger.warning(f"Could not resolve {file_path}: {e}; skipping")
                        continue
                    if not resolved.is_relative_to(allowed_root):
                        logger.warning(
                            f"Skipping {file_path}: resolved path "
                            f"{resolved} is outside allowed root {allowed_root}"
                        )
                        continue
                    if str(resolved) in seen_resolved:
                        continue
                    seen_resolved.add(str(resolved))
                    try:
                        stats = file_path.stat()
                        entry: Dict[str, Any] = {
                            "name": file_path.name,
                            "path": str(file_path),
                            "directory": str(directory),
                            "size": f"{stats.st_size / (1024 * 1024):.2f} MB",
                            "size_bytes": stats.st_size,
                            "modified": datetime.fromtimestamp(
                                stats.st_mtime
                            ).isoformat(),
                        }
                        # The extension glob accepts anything named ``*.zim``.
                        # Probe the signature so a garbage file is marked
                        # rather than presented as a loaded archive; it stays
                        # in the listing so the operator can see and fix it.
                        entry["readable"] = has_zim_signature(file_path)
                        if not entry["readable"]:
                            denied = zim_signature_error(file_path)
                            if denied is not None:
                                entry["warning"] = DENIED_ZIM_WARNING
                                logger.warning(f"{file_path} cannot be read: {denied}")
                            else:
                                # Truncated download vs never-an-archive: the
                                # remedies are opposite, so the warning says
                                # which one this is.
                                entry["warning"] = unreadable_zim_warning(file_path)
                                logger.warning(
                                    f"{file_path} cannot be opened as an archive; "
                                    f"listed as unreadable: {entry['warning']}"
                                )
                        all_zim_files.append(entry)
                    except OSError as e:
                        logger.warning(f"Error reading file stats for {file_path}: {e}")
            except Exception as e:
                logger.error(f"Error processing directory {directory}: {e}")

        return all_zim_files

    def list_zim_files_data(
        self, name_filter: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        """List all ZIM files in allowed directories as structured data.

        The directory scan is cached once. Filtering is applied in-memory
        against the cached list, so distinct filters share a single cache slot.

        Args:
            name_filter: Optional case-insensitive substring; only files whose
                filename contains it are returned. Surrounding whitespace is
                ignored. Empty/None disables filtering.

        Returns:
            List of dictionaries containing ZIM file information.
            Each dict has: name, path, directory, size, size_bytes, modified,
            readable — plus ``warning`` when ``readable`` is False.
        """
        # Cache key bumped to v2c when the per-file dict gained the
        # ``readable`` / ``warning`` signature-probe fields, so a persisted
        # v2b listing (no marker) can't be served as if it had been probed.
        # The files→results / count→total rename happens one layer up in
        # ``list_zim_files_summary_data``.
        #
        # The directory signature is folded into the key so that adding,
        # removing, or renaming a ``.zim`` file at runtime invalidates the
        # listing instead of serving the prior snapshot until the TTL
        # expires or the server restarts (issue #307). An unchanged
        # directory yields a stable signature, so repeat calls still hit
        # the cache rather than rescanning. The tree is globbed once here
        # and reused for both the signature and (on a miss) the scan.
        grouped = self._glob_zim_paths()
        cache_key = f"zim_files_list_data_v2c:{self._zim_dir_signature(grouped)}"
        cached_result = self.cache.get(cache_key)
        if cached_result is not None:
            logger.debug("Returning cached ZIM files list data")
            all_zim_files: List[Dict[str, Any]] = cached_result
        else:
            all_zim_files = self._scan_zim_files(grouped)
            self.cache.set(cache_key, all_zim_files)
            logger.info(f"Listed {len(all_zim_files)} ZIM files")

        needle = (name_filter or "").strip().lower()
        if not needle:
            return all_zim_files
        return [f for f in all_zim_files if needle in f["name"].lower()]

    def list_zim_files_summary_data(
        self, name_filter: Optional[str] = None
    ) -> "ListZimFilesResponse":
        """Structured ``list_zim_files`` payload.

        Wraps :py:meth:`list_zim_files_data` with the directories metadata
        that the legacy markdown-header string variant carries in its
        prose preamble, so MCP clients consuming the structured output
        get the same context without reparsing a header.

        v2 Phase B contract: the response carries the canonical pagination
        keys (``results`` / ``next_cursor`` / ``total`` / ``done`` /
        ``page_info``) plus the tool-specific ``directories_count`` and
        ``name_filter`` fields. ``list_zim_files`` is non-paginated — every
        matching file in the allowed directories is returned in a single
        call — so ``next_cursor`` is always ``None`` and ``done`` is
        always ``True``. The contract is applied for uniformity with the
        other list-shaped responses.

        Returns:
            ``ListZimFilesResponse``-shaped dict carrying ``results`` (the
            per-file dicts with name/path/directory/size/size_bytes/modified
            — formerly ``files``), ``next_cursor`` (always ``None``),
            ``total`` (the count, formerly ``count``), ``done`` (always
            ``True``), ``page_info``, plus ``directories_count``,
            ``name_filter``, and the ``_meta`` envelope.
        """
        files_list = self.list_zim_files_data(name_filter=name_filter)
        payload: Dict[str, Any] = {
            "name_filter": name_filter or "",
            "directories_count": len(self.config.allowed_directories),
            "results": files_list,
            "next_cursor": None,
            "total": len(files_list),
            "done": True,
            "page_info": {
                "offset": 0,
                "limit": len(files_list),
                "returned_count": len(files_list),
            },
        }
        return cast("ListZimFilesResponse", attach_meta(payload))

    def list_zim_files(self, name_filter: Optional[str] = None) -> str:
        """List all ZIM files in allowed directories.

        Args:
            name_filter: Optional case-insensitive substring; only files whose
                filename contains it are listed. Surrounding whitespace is
                ignored. Empty/None disables filtering.

        Returns:
            JSON string containing the list of ZIM files
        """
        all_zim_files = self.list_zim_files_data(name_filter=name_filter)

        if not all_zim_files:
            if (name_filter or "").strip():
                # A filter that matched nothing is not an empty library, so
                # this arm deliberately stays free of download advice — the
                # caller has archives, just none whose name contains this
                # substring.
                return (
                    "No ZIM files found in allowed directories matching filter "
                    f"{name_filter!r}"
                )
            # Nothing at all. This string is the whole user interface for a
            # GUI client, which keeps the server's stderr in a log file
            # nobody opens, so the startup warning never reaches the person
            # who most needs it. Say where an archive comes from here too.
            #
            # The first line stays byte-identical to what it always was —
            # the docs site quotes it verbatim in two places, and callers
            # match on it — so this only ever appends.
            return (
                "No ZIM files found in allowed directories\n\n"
                f"{acquisition_hint_markdown()}"
            )

        result_text = (
            f"Found {len(all_zim_files)} ZIM files in "
            f"{len(self.config.allowed_directories)} directories:\n\n"
        )
        result_text += _json(all_zim_files)
        return result_text

    def get_zim_metadata_data(self, zim_file_path: str) -> "ZimMetadataResponse":
        """Structured variant of ``get_zim_metadata``.

        Returns the metadata dict directly (not a JSON string) so MCP
        tools can hand it straight to the SDK's structured-content path.

        Raises:
            OpenZimMcpFileNotFoundError: If ZIM file not found
            OpenZimMcpArchiveError: If metadata retrieval fails
        """
        # Validate and resolve file path
        validated_path = self._validate_zim_path(zim_file_path)

        # Distinct cache key from the legacy string variant so the two
        # don't collide on shared cache backends. Bumped to v2c when the
        # shape gained uuid / is_multipart / has_*_index / counter_breakdown
        # so pre-upgrade cached responses (old shape) don't leak through.
        #
        # The stat token (mtime_ns:size) makes an in-place archive
        # replacement at the same path a cache miss instead of stale
        # metadata (archive_stat_token contract).
        from openzim_mcp.bundle import archive_stat_token

        cache_key = (
            f"metadata_data:v2c:{validated_path}:"
            f"{archive_stat_token(validated_path)}"
        )
        cached_result = self.cache.get(cache_key)
        if cached_result is not None:
            logger.debug(f"Returning cached metadata dict for: {validated_path}")
            return cast("ZimMetadataResponse", cached_result)

        # Late-bound lookup so test patches against
        # ``openzim_mcp.zim_operations.zim_archive`` apply here too.
        import openzim_mcp.zim_operations as _zim_ops_shim

        try:
            with _zim_ops_shim.zim_archive(validated_path) as archive:
                metadata = self._extract_zim_metadata(archive)

            # Detect archive type from the M-namespace dict and surface it
            # in _meta only (never the public body). detect_archive_type is
            # pure + cheap; called directly here (not via resolve_preset_from_entries)
            # because we only need the type/confidence for the _meta annotation.
            entries = metadata.get("metadata_entries", {})
            if not isinstance(entries, dict):
                entries = {}
            atype, confidence = detect_archive_type(entries)

            # Attach _meta before caching so cold and warm reads return
            # bit-identical responses (Phase B #12).
            with_meta = attach_meta(
                metadata, detected_type=atype, detection_confidence=confidence
            )
            self.cache.set(cache_key, with_meta)
            logger.info(f"Retrieved metadata for: {validated_path}")
            return cast("ZimMetadataResponse", with_meta)

        except Exception as e:
            logger.error(f"Metadata retrieval failed for {validated_path}: {e}")
            raise OpenZimMcpArchiveError(f"Metadata retrieval failed: {e}") from e

    def get_zim_metadata(self, zim_file_path: str) -> str:
        """Legacy JSON-string variant of ``get_zim_metadata_data``.

        Args:
            zim_file_path: Path to the ZIM file

        Returns:
            JSON string containing ZIM metadata

        Raises:
            OpenZimMcpFileNotFoundError: If ZIM file not found
            OpenZimMcpArchiveError: If metadata retrieval fails
        """
        return _json(self.get_zim_metadata_data(zim_file_path))

    def get_archive_validation_data(
        self, zim_file_path: str
    ) -> "ArchiveValidationResponse":
        """Validate a single ZIM archive and report its integrity + state.

        Runs ``Archive.check()`` (the native MD5 verification) and reports
        checksum availability, index capabilities, and identity. This is the
        per-archive diagnostic behind ``zim_health(zim_file_path=...)`` —
        distinct from the server-state report ``zim_health`` returns with no
        argument.

        Raises:
            OpenZimMcpFileNotFoundError: If ZIM file not found
            OpenZimMcpArchiveError: If validation fails
        """
        validated_path = self._validate_zim_path(zim_file_path)

        # Include a file-identity (mtime:size) token so an in-place ZIM
        # replacement invalidates the cached verdict. ``is_valid`` is an
        # integrity assertion derived from the file's bytes — serving it
        # stale after the file changed would be exactly backwards for a
        # diagnostic tool. Mirrors the bundle / namespace / content caches.
        from openzim_mcp.bundle import archive_stat_token

        cache_key = (
            f"validation_data:{validated_path}:{archive_stat_token(validated_path)}"
        )
        cached_result = self.cache.get(cache_key)
        if cached_result is not None:
            logger.debug(f"Returning cached validation for: {validated_path}")
            return cast("ArchiveValidationResponse", cached_result)

        import openzim_mcp.zim_operations as _zim_ops_shim

        try:
            with _zim_ops_shim.zim_archive(validated_path) as archive:
                has_checksum = bool(archive.has_checksum)
                data: Dict[str, Any] = {
                    "path": str(validated_path),
                    "name": validated_path.name,
                    # ``check()`` verifies the archive's internal checksum
                    # over the whole file — the authoritative integrity test.
                    # It runs in the validation worker process because the
                    # binding holds the GIL for the whole pass; in-process it
                    # froze the event loop for every client (D64).
                    "is_valid": check_archive_integrity(validated_path),
                    "has_checksum": has_checksum,
                    "checksum": archive.checksum if has_checksum else None,
                    "has_fulltext_index": bool(archive.has_fulltext_index),
                    "has_title_index": bool(archive.has_title_index),
                    "uuid": str(archive.uuid),
                    "is_multipart": bool(archive.is_multipart),
                }
                data.update(_link_graph_report(validated_path, str(archive.uuid)))

            with_meta = attach_meta(data)
            self.cache.set(cache_key, with_meta)
            logger.info(f"Validated archive: {validated_path}")
            return cast("ArchiveValidationResponse", with_meta)

        except Exception as e:
            logger.error(f"Validation failed for {validated_path}: {e}")
            raise OpenZimMcpArchiveError(f"Validation failed: {e}") from e

    def _extract_zim_metadata(self, archive: Archive) -> Dict[str, Any]:
        """Extract metadata from ZIM archive."""
        # Basic archive information
        metadata: Dict[str, Any] = {
            "entry_count": archive.entry_count,
            "all_entry_count": archive.all_entry_count,
            "article_count": archive.article_count,
            "media_count": archive.media_count,
        }

        # Archive identity + index capabilities (native libzim reader fields).
        # ``uuid`` is a ``uuid.UUID`` object — stringify for JSON. These are
        # intrinsic, cheap reads and let callers know up front whether
        # search/suggest will work without provoking an exception.
        metadata["uuid"] = str(archive.uuid)
        metadata["is_multipart"] = bool(archive.is_multipart)
        metadata["has_fulltext_index"] = bool(archive.has_fulltext_index)
        metadata["has_title_index"] = bool(archive.has_title_index)

        # Try to get metadata from M namespace
        metadata_entries = {}
        # Raw (uncapped) ``M/Counter`` value: the display entries below are
        # capped at ``_METADATA_PREVIEW_CAP``, and parsing the breakdown from
        # the capped preview silently dropped every bucket past the cap.
        counter_raw_full: Optional[str] = None
        try:
            # DD1 (beta, second pass): new-scheme ZIM archives serve
            # ``M/<key>`` via ``archive.get_metadata_item`` — the
            # entry-by-path API silently strips the ``M/`` prefix and
            # resolves to the C-namespace article with that name,
            # which is why ``metadata for <file>`` returned 172 KB
            # Wikipedia article bodies for Title / Description /
            # Language. (D7 fixed this for the per-entry
            # ``get article M/Title`` surface; this fix extends the
            # same routing to the aggregator.) On old-scheme archives
            # fall back to ``get_entry_by_path`` since the M namespace
            # actually lives on the entry surface there.
            has_new_scheme = getattr(archive, "has_new_namespace_scheme", False)
            common_metadata = self._discover_metadata_keys(archive, has_new_scheme)
            for meta_key in common_metadata:
                try:
                    raw = (
                        self._read_new_scheme_metadata_raw(archive, meta_key)
                        if has_new_scheme
                        else self._read_old_scheme_metadata_raw(archive, meta_key)
                    )
                    if raw is None:
                        continue
                    if meta_key == "Counter":
                        counter_raw_full = raw
                    metadata_entries[meta_key] = (
                        self._cap_metadata_preview(raw)
                        if has_new_scheme
                        else self._format_metadata_html_value(raw)
                    )
                except Exception as e:
                    # Entry doesn't exist or can't be read - expected for optional
                    logger.debug(f"Metadata 'M/{meta_key}' not available: {e}")

        except Exception as e:
            logger.warning(f"Error extracting metadata entries: {e}")

        if metadata_entries:
            metadata["metadata_entries"] = metadata_entries
            # Parse the ``M/Counter`` field (``mimetype=count;...``) into a
            # structured breakdown so callers can answer "how many
            # images/articles" without walking the archive. Parse the RAW
            # value — the display entry is preview-capped, and a long
            # Counter's tail buckets vanished from the breakdown.
            counter_raw = counter_raw_full or metadata_entries.get("Counter")
            if counter_raw:
                breakdown = _parse_counter_metadata(counter_raw)
                if breakdown:
                    metadata["counter_breakdown"] = breakdown

        return metadata

    def _resolve_preset_for_open_archive(
        self, archive: Archive, validated_path: Optional[str] = None
    ) -> Tuple[Optional[ArchivePreset], Optional[str]]:
        """Resolve ``(preset, applied_type)`` from an already-open archive.

        Reuses the open handle (no second open) and funnels through the
        single shared resolver. Never raises — degrades to no-preset on any
        failure so a behavior-shaping read can't break the underlying tool.

        M32: the expensive part is ``_extract_zim_metadata`` (probes ~15
        M-namespace keys and, on old-scheme archives, decodes + BeautifulSoup-
        parses ~1MB HTML per field). The result depends only on the archive, so
        when ``validated_path`` is supplied the JSON-safe ``metadata_entries``
        dict is cached per (path, archive stat token) — turning a per-uncached-
        search cost into a one-time-per-archive cost. ``resolve_preset_from_
        entries`` itself is pure and cheap, so it is re-run on the cached dict.
        """
        # Caching is isolated from resolution: a cache failure must never
        # prevent the (working) preset resolution from running.
        entries: Optional[Dict[str, str]] = None
        cache_key: Optional[str] = None
        if validated_path is not None:
            try:
                from openzim_mcp.bundle import archive_stat_token

                cache_key = (
                    f"preset_entries:v1:{validated_path}:"
                    f"{archive_stat_token(Path(validated_path))}"
                )
                cached = self.cache.get(cache_key)
                if isinstance(cached, dict):
                    entries = cached
            except Exception:  # pragma: no cover - cache is best-effort
                cache_key = None
        if entries is None:
            try:
                extracted = self._extract_zim_metadata(archive).get(
                    "metadata_entries", {}
                )
            except Exception as exc:  # pragma: no cover - defensive
                logger.debug("Preset metadata extraction failed: %s", exc)
                return None, None
            entries = extracted if isinstance(extracted, dict) else {}
            if cache_key is not None:
                try:
                    self.cache.set(cache_key, entries)
                except Exception as exc:  # pragma: no cover - cache is best-effort
                    logger.debug("preset metadata cache set failed: %s", exc)
        try:
            return resolve_preset_from_entries(
                entries, self.config.presets_override_path
            )
        except Exception as exc:  # pragma: no cover - defensive
            logger.debug("Preset resolution failed; using no-preset: %s", exc)
            return None, None

    def _discover_metadata_keys(
        self, archive: Archive, has_new_scheme: bool
    ) -> List[str]:
        """Build the ordered list of M-namespace keys to probe.

        Starts from the conventional hardcoded list (so the most common
        keys lead) and, for new-scheme archives, appends any extra keys
        the archive exposes via ``archive.metadata_keys``.
        """
        # Common metadata entries in M namespace.
        # A11 F6 (post-a10, second pass): for new-scheme
        # archives, enumerate ``archive.metadata_keys`` directly
        # instead of probing a hardcoded list — that's exactly
        # what ``walk namespace M`` does, and using the same
        # source guarantees the two operations agree on the set.
        # Filter out illustration keys (binary, can't surface as
        # text). The hardcoded list is retained as the old-scheme
        # fallback since ``metadata_keys`` is a new-scheme API.
        common_metadata = [
            "Title",
            "Description",
            "Long_Description",
            "Language",
            "Creator",
            "Publisher",
            "Date",
            "Source",
            "License",
            "Relation",
            "Flavour",
            "Tags",
            "Counter",
            "Name",
            "Scraper",
        ]

        if has_new_scheme:
            try:
                # A11 post-a11 M1: shared filter — see
                # ``zim.namespace.is_human_readable_metadata_key``.
                # Walk-namespace M and metadata-for must agree on
                # what counts as metadata; sharing the predicate
                # guarantees that.
                from openzim_mcp.zim.namespace import (
                    is_human_readable_metadata_key,
                )

                discovered = [
                    k
                    for k in (getattr(archive, "metadata_keys", []) or [])
                    if is_human_readable_metadata_key(k)
                ]
            except Exception as e:
                logger.debug(f"metadata_keys read failed: {e}")
                discovered = []
            # Stable order: start with the conventional list (so
            # the most common keys lead), then append any extras
            # the archive exposes that aren't in the list. This
            # keeps the previous response shape for archives
            # whose key set exactly matches the conventional
            # list and gracefully extends for archives that
            # carry custom keys.
            extras = [k for k in discovered if k not in common_metadata]
            common_metadata = common_metadata + extras
        return common_metadata

    @staticmethod
    def _cap_metadata_preview(content: str) -> str:
        """Cap a plain-text metadata value at ``_METADATA_PREVIEW_CAP``."""
        if len(content) > _METADATA_PREVIEW_CAP:
            return (
                f"{content[:_METADATA_PREVIEW_CAP].rstrip()}… "
                f"[truncated, {len(content):,} chars total]"
            )
        return content

    def _read_new_scheme_metadata_raw(
        self, archive: Archive, meta_key: str
    ) -> Optional[str]:
        """Read a single new-scheme ``M/<meta_key>`` value, uncapped.

        New-scheme archives serve metadata via ``get_metadata_item`` as
        plain text (no HTML wrapper). Returns the raw value, or ``None``
        to skip the key (missing item / empty content). Display callers
        cap via :meth:`_cap_metadata_preview`; structured consumers
        (``counter_breakdown``) parse this raw form.
        """
        try:
            item = archive.get_metadata_item(meta_key)
        except Exception as e:
            logger.debug(f"get_metadata_item failed for {meta_key}: {e}")
            return None
        if item is None:
            return None
        content = bytes(item.content).decode("utf-8", errors="replace").strip()
        return content or None

    def _read_new_scheme_metadata_value(
        self, archive: Archive, meta_key: str
    ) -> Optional[str]:
        """Capped display form of :meth:`_read_new_scheme_metadata_raw`."""
        content = self._read_new_scheme_metadata_raw(archive, meta_key)
        if content is None:
            return None
        return self._cap_metadata_preview(content)

    def _read_old_scheme_metadata_raw(
        self, archive: Archive, meta_key: str
    ) -> Optional[str]:
        """Read a single old-scheme ``M/<meta_key>`` value, undistilled.

        Old-scheme archives expose the M namespace on the entry surface
        (``get_entry_by_path``). Resolves redirects (bounded best-effort
        walk) and returns the decoded content, or ``None`` to skip.
        Display callers distil/cap via :meth:`_format_metadata_html_value`;
        structured consumers (``counter_breakdown``) parse this raw form.
        """
        entry = archive.get_entry_by_path(f"M/{meta_key}")
        if not entry:
            return None
        # libzim raises RuntimeError if get_item() is called
        # on a redirect entry. Resolve the full redirect chain
        # (with cycle + depth bounds) so a legitimate metadata
        # redirect doesn't disappear from the response simply
        # because it points at the canonical key. A bare
        # ``get_redirect_entry`` only resolves one hop, which
        # would still raise RuntimeError on a 2-hop chain.
        seen_meta: set[str] = set()
        hops = 0
        while getattr(entry, "is_redirect", False):
            if hops >= MAX_REDIRECT_DEPTH or entry.path in seen_meta:
                break
            seen_meta.add(entry.path)
            entry = entry.get_redirect_entry()
            hops += 1
        if getattr(entry, "is_redirect", False):
            # Cycle or runaway chain — skip rather than raise,
            # metadata is best-effort.
            return None
        item = entry.get_item()
        content = bytes(item.content).decode("utf-8", errors="replace").strip()
        return content or None

    def _read_old_scheme_metadata_value(
        self, archive: Archive, meta_key: str
    ) -> Optional[str]:
        """Distilled + capped display form of
        :meth:`_read_old_scheme_metadata_raw`."""
        content = self._read_old_scheme_metadata_raw(archive, meta_key)
        if content is None:
            return None
        return self._format_metadata_html_value(content)

    def _format_metadata_html_value(self, content: str) -> str:
        """Distil an old-scheme metadata value's HTML wrapper + cap it.

        D4 / Op2 (v2.0.0a9): Wikipedia ZIMs store ``M/Title``,
        ``M/Description``, ``M/Language`` etc. as full HTML documents
        (~1 MB each) rather than bare strings. The original a7 fix capped
        to 800 chars but every value then leads with the SAME 800 chars of
        ``<!DOCTYPE html>…<title>X</title>`` boilerplate — the actual field
        value lives buried past the cap in ``<body>``. Extract the readable
        text (preferring the ``<title>`` element, then ``<body>`` text)
        before the cap so the response surfaces the actual archive title /
        description / language instead of identical HTML prefixes.
        """
        extracted = _extract_metadata_text(content)
        original_chars = len(content)
        if len(extracted) > _METADATA_PREVIEW_CAP:
            preview = extracted[:_METADATA_PREVIEW_CAP].rstrip()
            return f"{preview}… [truncated, {original_chars:,} chars total]"
        elif extracted != content:
            # The field was HTML — record the
            # extracted text alongside an indicator
            # of the source-document size so the
            # caller knows the value was distilled
            # from a larger HTML wrapper.
            return (
                f"{extracted}"
                if original_chars <= len(extracted) + 16
                else (f"{extracted} [extracted from {original_chars:,}-char HTML]")
            )
        else:
            return content

    def _main_page_cache_lookup(
        self,
        zim_file_path: str,
        prefix: str,
        *,
        compact: bool,
        max_content_length: Optional[int] = None,
    ) -> Tuple[Path, str, Any]:
        """Validate the path and probe the response cache for a main-page call.

        Shared by ``get_main_page`` / ``get_main_page_data`` so the
        stat-token cache-key contract lives in one place. The stat token
        (mtime_ns:size) invalidates the entry when the archive is replaced
        in place (archive_stat_token contract). The two callers use
        distinct ``prefix`` values so old persisted text entries don't
        collide with the dict shape.

        The key carries a ``v2`` marker (the rendering became chrome-scoped,
        so a persisted v1 body must not be served) and the caller's cap,
        which is part of the response identity: an uncapped read must never
        be answered with a capped rendering or vice versa.

        Returns:
            ``(validated_path, cache_key, cached_value)`` —
            ``cached_value`` is ``None`` on a cache miss.
        """
        validated_path = self._validate_zim_path(zim_file_path)
        from openzim_mcp.bundle import archive_stat_token

        cache_key = (
            f"{prefix}:v2:{validated_path}:"
            f"{archive_stat_token(validated_path)}:compact={compact}:"
            f"cap={max_content_length}"
        )
        return validated_path, cache_key, self.cache.get(cache_key)

    def get_main_page(self, zim_file_path: str, *, compact: bool = False) -> str:
        """Get the main page entry from W namespace.

        Args:
            zim_file_path: Path to the ZIM file

        Returns:
            Main page content or information about main page

        Raises:
            OpenZimMcpFileNotFoundError: If ZIM file not found
            OpenZimMcpArchiveError: If main page retrieval fails
        """
        validated_path, cache_key, cached_result = self._main_page_cache_lookup(
            zim_file_path, "main_page", compact=compact
        )
        if cached_result is not None:
            logger.debug(f"Returning cached main page for: {validated_path}")
            return cached_result  # type: ignore[no-any-return]

        # Late-bound lookup so test patches against
        # ``openzim_mcp.zim_operations.zim_archive`` apply here too.
        import openzim_mcp.zim_operations as _zim_ops_shim

        try:
            with _zim_ops_shim.zim_archive(validated_path) as archive:
                result, content_ok = self._get_main_page_content(
                    archive, compact=compact
                )

            # Don't cache error sentinels: a transient failure (e.g. MIME
            # processing error) should not be locked in for the TTL.
            if content_ok:
                self.cache.set(cache_key, result)
            logger.info(f"Retrieved main page for: {validated_path}")
            return result

        except Exception as e:
            logger.error(f"Main page retrieval failed for {validated_path}: {e}")
            raise OpenZimMcpArchiveError(f"Main page retrieval failed: {e}") from e

    def _get_main_page_content(
        self, archive: Archive, *, compact: bool = False
    ) -> Tuple[str, bool]:
        """Get main page content from archive.

        Thin text presenter over ``_get_main_page_result`` — the shared
        core owns redirect-following, the ``main_entry``/fallback-path
        ladder, truncation, and the error-sentinel rule.

        Returns:
            (text, content_ok) — ``content_ok`` is False when the body holds an
            error sentinel produced by a fallback path (MIME processing or
            outer exception), so the caller can skip caching it.
        """
        kind, payload, content_ok, found_at = self._get_main_page_result(
            archive, compact=compact
        )
        if kind == "no_main_page":
            return (
                "# Main Page\n\nNo main page found in this ZIM file.\n\n"
                "The archive may not have a designated main page entry."
            ), True
        if kind == "error":
            # ``payload["content"]`` already reads "Error retrieving main
            # page: <e>".
            return f"# Main Page\n\n{payload['content']}", False
        if kind == "content_error":
            # ``payload["content"]`` is the "(Error retrieving content: <e>)"
            # sentinel; the text variant historically headed it with the
            # generic "Main Page" title rather than the entry title.
            return (
                f"# Main Page\n\nPath: {payload['path']}\n\n{payload['content']}"
            ), False
        # kind == "entry"
        type_line = (
            "Type: Main Page Entry"
            if found_at is None
            else f"Type: Main Page (found at {found_at})"
        )
        result = (
            f"# {payload['title']}\n\n"
            f"Path: {payload['path']}\n"
            f"{type_line}\n"
            "## Content\n\n"
            f"{payload['content']}"
        )
        return result, content_ok

    def get_main_page_data(
        self,
        zim_file_path: str,
        *,
        compact: bool = False,
        max_content_length: Optional[int] = None,
    ) -> "EntryResponse":
        """Structured variant of ``get_main_page``.

        Returns the entry dict directly (path/title/content/content_type)
        so MCP tools can hand it to the SDK's structured-content path.

        ``max_content_length`` caps the body like a path fetch does; when
        ``None`` the branch keeps its ``DEFAULT_MAIN_PAGE_TRUNCATION`` cap.

        Raises:
            OpenZimMcpFileNotFoundError: If ZIM file not found
            OpenZimMcpArchiveError: If main page retrieval fails
        """
        validated_path, cache_key, cached_result = self._main_page_cache_lookup(
            zim_file_path,
            "main_page_data",
            compact=compact,
            max_content_length=max_content_length,
        )
        if cached_result is not None:
            logger.debug(f"Returning cached main page dict for: {validated_path}")
            return cast("EntryResponse", cached_result)

        # Late-bound lookup so test patches against
        # ``openzim_mcp.zim_operations.zim_archive`` apply here too.
        import openzim_mcp.zim_operations as _zim_ops_shim

        try:
            with _zim_ops_shim.zim_archive(validated_path) as archive:
                payload, content_ok = self._get_main_page_data_content(
                    archive, compact=compact, max_content_length=max_content_length
                )
        except Exception as e:
            logger.error(f"Main page retrieval failed for {validated_path}: {e}")
            raise OpenZimMcpArchiveError(f"Main page retrieval failed: {e}") from e

        truncated = bool(payload.pop("_truncated", False))
        total_chars = payload.pop("_total_chars", None)
        # main_page is not paginable so no ``content_chars`` is supplied;
        # ``more_at_offset`` is intentionally omitted on a truncated
        # response (callers can't follow-up with a content_offset here).
        with_meta = attach_meta(
            payload,
            truncated=truncated,
            total_chars=total_chars,
        )
        if content_ok:
            self.cache.set(cache_key, with_meta)
        logger.info(f"Retrieved main page data for: {validated_path}")
        return cast("EntryResponse", with_meta)

    def _get_main_page_data_content(
        self,
        archive: Archive,
        *,
        compact: bool = False,
        max_content_length: Optional[int] = None,
    ) -> Tuple[Dict[str, Any], bool]:
        """Build the main-page dict payload from an open archive.

        Thin structured presenter over ``_get_main_page_result`` — the
        payload is served exactly as the shared core builds it.

        Returns:
            ``(payload, content_ok)`` — ``content_ok`` is False when MIME
            processing raised; the caller must skip caching it.
        """
        _kind, payload, content_ok, _found_at = self._get_main_page_result(
            archive, compact=compact, max_content_length=max_content_length
        )
        return payload, content_ok

    def _get_main_page_result(  # NOSONAR(python:S3776)
        self,
        archive: Archive,
        *,
        compact: bool = False,
        max_content_length: Optional[int] = None,
    ) -> Tuple[str, Dict[str, Any], bool, Optional[str]]:
        """Resolve the main page and build its structured payload.

        Single source of truth for the main-page control flow shared by
        the text (``_get_main_page_content``) and structured
        (``_get_main_page_data_content``) presenters: redirect-following,
        the ``main_entry``/fallback-path probing ladder, truncation, and
        the error-sentinel / don't-cache rule.

        ``max_content_length`` overrides the ``DEFAULT_MAIN_PAGE_TRUNCATION``
        body cap; the default is read at call time so tests can patch it.

        Returns:
            ``(kind, payload, content_ok, found_at)``:

            * ``kind`` — ``"entry"`` (main page resolved and content
              built), ``"content_error"`` (``main_entry`` resolved but
              content extraction raised), ``"no_main_page"`` (structural
              property of the archive — safe to cache), or ``"error"``
              (unexpected failure).
            * ``payload`` — the structured dict, including the internal
              ``_truncated``/``_total_chars`` hints on a truncated body.
            * ``content_ok`` — False when the payload content is an error
              sentinel that must not be cached.
            * ``found_at`` — the probe path when the main page was found
              via the named-path fallback, ``None`` when resolved via
              ``archive.main_entry``.
        """

        # Most ZIM files generated by Kiwix tools point W/mainPage at the
        # canonical article via a redirect. libzim raises RuntimeError if
        # get_item() is called on a redirect entry, so walk the chain (cycle
        # detection + shared MAX_REDIRECT_DEPTH cap) before any caller reaches
        # get_item(). The shared resolver raises OpenZimMcpArchiveError on
        # cycle/depth-exceeded — a targeted diagnostic instead of an opaque
        # libzim RuntimeError surfaced via get_item().
        def _follow_redirect(entry: Any) -> Any:
            return resolve_redirect_chain(entry, context="in main-page lookup")

        def _build(entry_obj: Any) -> Tuple[Dict[str, Any], bool]:
            title = entry_obj.title or "Main Page"
            path = entry_obj.path
            try:
                item = entry_obj.get_item()
                mime_type = item.mimetype or ""
                # ``scope_main_content`` matches the path-fetch branch
                # (``_build_entry_payload``): the main page of a warc2zim
                # archive is an ordinary entry wrapped in the same site
                # chrome, and it used to be the one entry-rendering path
                # that served the banner / skip-nav / menus.
                content = self.content_processor.process_mime_content(
                    bytes(item.content),
                    mime_type,
                    compact=compact,
                    scope_main_content=True,
                )
                total_length = len(content)
                cap = (
                    max_content_length
                    if max_content_length is not None
                    else DEFAULT_MAIN_PAGE_TRUNCATION
                )
                # Truncate content for main page display. ``paginatable
                # = False`` because ``_handle_main_page`` doesn't
                # thread ``content_offset`` — point the caller at
                # ``get article`` for the rest (A11 third pass).
                truncated_content = self.content_processor.truncate_content(
                    content, cap, paginatable=False
                )
                # Key on the cap, not the rendered lengths: ``truncate_content``
                # appends a ~150-char note, so a length comparison reports
                # "not truncated" whenever the overflow is smaller than the note.
                was_truncated = total_length > cap
                payload: Dict[str, Any] = {
                    "path": path,
                    "title": title,
                    "content": truncated_content,
                }
                if mime_type:
                    payload["content_type"] = mime_type
                if was_truncated:
                    payload["_truncated"] = True
                    payload["_total_chars"] = total_length
                return payload, True
            except Exception as e:
                logger.warning(f"Error getting main page content: {e}")
                return (
                    {
                        "path": path,
                        "title": title,
                        "content": f"(Error retrieving content: {e})",
                    },
                    False,
                )

        try:
            # Try to get main page from archive metadata. libzim's
            # ``main_entry`` raises RuntimeError when the header has no main
            # page (it never returns a falsy value), so guard the access
            # itself and fall through to the named-path fallback.
            main_entry_raw = None
            try:
                main_entry_raw = archive.main_entry
            except Exception as e:
                logger.debug(f"main_entry resolution failed: {e}")
            if main_entry_raw:
                main_entry = _follow_redirect(main_entry_raw)
                payload, ok = _build(main_entry)
                return ("entry" if ok else "content_error"), payload, ok, None

            # Fallback: try common main page paths. Entry-zero is NOT a
            # main-page candidate — libzim's internal ordering doesn't map
            # to the ZIM main-page pointer, so serving entry 0 would return
            # an arbitrary article. If main_entry is missing and none of
            # these named paths resolve, the archive simply has no main
            # page, which the presenters handle via ``"no_main_page"``.
            main_page_paths = ["W/mainPage", "A/Main_Page", "A/index"]
            # Sweep follow-up: distinguish "probe path absent" from "probe
            # path FOUND but unreadable". The old single try/except sent
            # both to the next candidate, so a transient read failure on
            # an existing main-page entry fell through to the
            # ``no_main_page`` arm — which is content_ok=True and cached,
            # turning a transient into a durable "archive has no main
            # page" claim.
            probe_failed_after_found = False
            for path in main_page_paths:
                try:
                    entry = archive.get_entry_by_path(path)
                except Exception:  # nosec B112 - intentional fallback
                    # Path doesn't exist, try next
                    continue
                if not entry:
                    continue
                try:
                    entry = _follow_redirect(entry)
                except Exception as e:
                    logger.warning(
                        f"Main-page probe {path} resolved but its redirect "
                        f"chain failed: {e}"
                    )
                    probe_failed_after_found = True
                    continue
                payload, ok = _build(entry)
                if ok:
                    return "entry", payload, True, path
                # Content extraction failed for this probe path — drop the
                # sentinel and try the next candidate, but remember that a
                # main-page entry does exist.
                probe_failed_after_found = True

            if probe_failed_after_found:
                # A main-page entry exists but couldn't be served —
                # content_ok=False keeps this out of the cache so the next
                # request retries instead of inheriting a wrong
                # "no main page" answer.
                return (
                    "content_error",
                    {
                        "path": "",
                        "title": "Main Page",
                        "content": (
                            "(Error retrieving content: a main-page entry "
                            "exists but its content could not be read)"
                        ),
                    },
                    False,
                    None,
                )

            # No main page found — this is a structural property of the
            # archive, so it's safe to cache.
            return (
                "no_main_page",
                {
                    "path": "",
                    "title": "Main Page",
                    "content": (
                        "No main page found in this ZIM file. "
                        "The archive may not have a designated main page entry."
                    ),
                },
                True,
                None,
            )

        except Exception as e:
            logger.error(f"Error getting main page: {e}")
            return (
                "error",
                {
                    "path": "",
                    "title": "Main Page",
                    "content": f"Error retrieving main page: {e}",
                },
                False,
                None,
            )

    def _resolve_entry_with_fallback(
        self, archive: Archive, entry_path: str
    ) -> Tuple[Any, str]:
        """Resolve an entry by direct path, falling back to search.

        Returns (entry, resolved_path) with redirects already followed so the
        caller can call ``entry.get_item()`` directly — libzim raises
        RuntimeError when get_item() is invoked on a redirect entry. The
        returned ``resolved_path`` is the post-redirect ``entry.path`` so
        callers that surface it in JSON responses (and downstream
        relative-link resolution in ``get_related_articles``) reflect the
        canonical target rather than the redirect stub.

        Raises OpenZimMcpArchiveError cleanly (without an implicit __context__
        chain to a transient direct-access error) if neither direct access
        nor search yields a result, and also when the redirect chain
        contains a cycle or exceeds ``MAX_REDIRECT_DEPTH`` hops.
        """

        def _follow(entry: Any) -> Any:
            return resolve_redirect_chain(entry, context=f"starting at {entry_path}")

        # Suppress only the transient direct-access lookup error so callers
        # see a clean "not found" message rather than a chained exception
        # with the underlying archive error as context. Redirect errors
        # raised from _follow propagate — they are real failures, not
        # "not found", and falling through to a search fallback would mask
        # malformed-archive bugs.
        # A synthetic ``W/`` browse path names an entry not stored under that
        # name, so rewrite before probing — otherwise this ladder answers
        # not-found for a path the plain-body ladder serves.
        entry_path = rewrite_well_known_path(
            archive, entry_path, tool_mode=self.config.tool_mode
        )

        entry = None
        with suppress(Exception):
            entry = archive.get_entry_by_path(entry_path)
        if entry is not None:
            resolved = _follow(entry)
            return resolved, resolved.path
        actual_path = self._find_entry_by_search(archive, entry_path)
        if actual_path:
            resolved = _follow(archive.get_entry_by_path(actual_path))
            return resolved, resolved.path
        raise OpenZimMcpEntryNotFoundError(
            f"Entry not found: '{entry_path}'. "
            + locate_entry(self.config.tool_mode)
            + url_shaped_path_hint(entry_path)
        ) from None
