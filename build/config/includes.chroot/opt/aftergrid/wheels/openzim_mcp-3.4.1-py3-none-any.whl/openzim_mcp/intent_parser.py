"""Intent parsing for the OpenZIM MCP simple-tools handler.

This module contains the regex-heavy, pure-parsing layer that turns a
natural-language query into a structured ``(intent, params, confidence)``
tuple. It intentionally has no dependency on :mod:`openzim_mcp.zim_operations`
or any I/O, which makes it cheap to unit-test in isolation.
"""

import logging
import re
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple, Union
from urllib.parse import unquote

from .constants import REGEX_TIMEOUT_SECONDS
from .exceptions import RegexTimeoutError
from .query_rewrite_data import load_exclusions, load_misspellings
from .timeout_utils import run_with_timeout

logger = logging.getLogger(__name__)

__all__ = [
    "IntentParser",
    "safe_regex_search",
    "safe_regex_findall",
    "safe_regex_sub",
]


def safe_regex_search(
    pattern: str,
    text: str,
    flags: int = 0,
    timeout_seconds: float = REGEX_TIMEOUT_SECONDS,
) -> Optional[re.Match[str]]:
    """Perform a regex search with cross-platform timeout protection.

    Always uses a threading-based timeout so it works on every platform and
    on any thread (asyncio executors, worker threads, etc.). Signal-based
    timeouts are not safe outside the main thread.

    IMPORTANT — this is NOT a wall-clock bound on the match. ``re`` holds the
    GIL for the whole operation and CPython cannot cancel a running thread, so
    a catastrophically-backtracking pattern runs to completion; the timeout
    only bounds how long *this* caller blocks, and it can't even fire until
    the worker releases the GIL. Patterns reachable from untrusted input must
    therefore be linear by construction (no greedy repeat followed by a
    failing alternation), and the input itself must be length-capped.

    Args:
        pattern: Regular expression pattern
        text: Text to search
        flags: Regex flags (e.g., re.IGNORECASE)
        timeout_seconds: Maximum time allowed for the operation

    Returns:
        Match object if found, None otherwise

    Raises:
        RegexTimeoutError: If the operation exceeds the time limit
    """
    return run_with_timeout(
        lambda: re.search(pattern, text, flags),
        timeout_seconds,
        f"Regex operation timed out after {timeout_seconds} seconds",
        RegexTimeoutError,
        pool="regex",
    )


# Character class covering ASCII and common Unicode "smart" quotes that LLMs
# and copy-pasted text frequently use. Used wherever we extract a quoted token
# from a user query.
_QUOTE_CHARS = "'\"‘’“”"
_QUOTE_OPEN = f"[{_QUOTE_CHARS}]"
_QUOTE_NOT = f"[^{_QUOTE_CHARS}]"

# Section/title names legitimately contain apostrophes (``Earth's atmosphere``,
# ``Murphy's law``), so a value capture that must tolerate them excludes only
# the DOUBLE-quote delimiters, not the apostrophe / single-quote chars in
# _QUOTE_CHARS (M8). The lazy quantifier plus the surrounding optional
# _QUOTE_OPEN still peels an explicitly single-quoted value cleanly.
_QUOTE_NOT_APOS = '[^"“”]'

# Search verbs stripped off the front of a query to recover the bare terms.
# ``search``/``find``/``look`` read as verbs wherever they appear, but
# ``query`` is overwhelmingly a NOUN mid-sentence ("SQL query optimization",
# "database query languages"), so only a LEADING ``query`` counts as the
# verb — otherwise the strip silently discarded every term before it.
_SEARCH_VERB = r"(?:^\s*query|search|find|look)"

# A ZIM namespace-prefixed path: exactly one letter, then ``/`` (``A/Berlin``,
# ``C/Photosynthesis``, ``I/logo.png``). Used by ``_restore_nonascii_case`` to
# exempt case-sensitive paths from Tier-1 Rule 1's lowercasing.
_NAMESPACE_PREFIXED_RE = re.compile(r"^[A-Za-z]/")

# D50: the path shape zimit / warc2zim archives store and this tool prints
# (``Path: medlineplus.gov/measles.html``, ``iep.utm.edu/kantview/``): a
# dotted host, then ``/``, then the page path. The host must contain a dot
# so a bare ZIM filename (``wikipedia.zim`` — no slash) and slashed prose
# (``and/or``, ``km/h``) stay excluded. Shares the suffix class of the
# namespace-prefixed shape. ``_restore_nonascii_case`` exempts it from
# Rule 1's lowercasing for the same reason it exempts ``A/...``: libzim's
# path lookup is case-sensitive.
_DOMAIN_PATH_BODY = r"[A-Za-z0-9][A-Za-z0-9\-]*(?:\.[A-Za-z0-9\-]+)+/"
_DOMAIN_PATH_RE = re.compile(rf"^{_DOMAIN_PATH_BODY}")


def _strip_quote_pair(value: str) -> str:
    """Peel a single surrounding matched quote-pair from ``value`` and
    trim interior whitespace.

    Post-v2.0.0 D-E: when a caller types ``""`` (or ``''`` / curly
    equivalents) as an entry path or title, several extractors capture
    the 2-char literal verbatim, the handler's ``.strip()`` only trims
    whitespace, and the backend's title-promotion fuzzy-matches the
    empty input to the ``Empty_string`` article at score 1.00. Stripping
    surrounding quotes here drops the value cleanly so the handler's
    missing-arg guard can fire.

    Stripping is opportunistic — both endpoints just need to live in
    ``_QUOTE_CHARS``. Mixed quote endpoints (``"foo'``) are stripped too
    so LLM-generated mismatched pairs don't survive as wrong values.
    Single-char inputs (already < 2 chars) pass through unchanged.
    """
    if len(value) >= 2 and value[0] in _QUOTE_CHARS and value[-1] in _QUOTE_CHARS:
        return value[1:-1].strip()
    return value


def safe_regex_findall(
    pattern: str,
    text: str,
    flags: int = 0,
    timeout_seconds: float = REGEX_TIMEOUT_SECONDS,
) -> List[Any]:
    """Find all regex matches with timeout protection.

    Same protections as safe_regex_search; returns the list of capture groups
    (re.findall semantics).
    """
    return run_with_timeout(
        lambda: re.findall(pattern, text, flags),
        timeout_seconds,
        f"Regex operation timed out after {timeout_seconds} seconds",
        RegexTimeoutError,
        pool="regex",
    )


def safe_regex_sub(
    pattern: Union[str, "re.Pattern[str]"],
    repl: Union[str, Callable[["re.Match[str]"], str]],
    text: str,
    flags: int = 0,
    timeout_seconds: float = REGEX_TIMEOUT_SECONDS,
) -> str:
    """re.sub with cross-platform timeout protection.

    Accepts either a string pattern or a pre-compiled :class:`re.Pattern`.
    When a pre-compiled pattern is passed, ``flags`` is ignored (use the
    pattern's own flags). Same threading-based timeout as
    :func:`safe_regex_search`.

    Used by the compact-rendering layer to bound how long a caller waits on
    adversarial article bodies (long unclosed markdown links, pathological
    snippet headers, etc.). It does NOT defang catastrophic backtracking: see
    the warning on :func:`safe_regex_search` — the match still runs to
    completion on its worker thread. Keep the patterns linear.
    """
    if isinstance(pattern, re.Pattern):
        return run_with_timeout(
            lambda: pattern.sub(repl, text),
            timeout_seconds,
            f"Regex operation timed out after {timeout_seconds} seconds",
            RegexTimeoutError,
            pool="regex",
        )
    return run_with_timeout(
        lambda: re.sub(pattern, repl, text, flags=flags),
        timeout_seconds,
        f"Regex operation timed out after {timeout_seconds} seconds",
        RegexTimeoutError,
        pool="regex",
    )


# Per-intent parameter extractors. Each mutates ``params`` in place so the
# dispatching wrapper in ``IntentParser._extract_params`` stays small and the
# overall flow reads as one regex per intent rather than one giant if/elif.


def _extract_browse(query: str, params: Dict[str, Any]) -> None:
    # A15 post-a15 P6-D2: the original regex
    # ``namespace\s+['\"]?([A-Za-z0-9_.-]+)['\"]?`` accepted multi-
    # character, digit, and special-char namespace arguments
    # (``browse namespace AB``, ``browse namespace 1``,
    # ``browse namespace _``) and didn't uppercase lowercase input.
    # The sibling ``_extract_walk_namespace`` is strict (single
    # letter, ``.upper()``); these two should agree. Tighten the
    # regex so a malformed argument fails to match and the handler's
    # missing-arg guard fires consistently across the two tools.
    namespace_match = safe_regex_search(
        r"namespace\s+['\"]?([A-Za-z])\b['\"]?",
        query,
        re.IGNORECASE,
    )
    if namespace_match:
        params["namespace"] = namespace_match.group(1).upper()


def _extract_filtered_search(query: str, params: Dict[str, Any]) -> None:
    # H5: anchor the capture's end on the real ``in namespace`` / ``in type``
    # filter keyword. Without the trailing ``\b`` + lookahead the lazy capture
    # stopped at the FIRST whitespace-preceded ``in``-prefixed word (internet,
    # insulin, India…), silently truncating the query — e.g. ``search for
    # history of the internet in namespace A`` captured only ``history of the``.
    #
    # ``_QUOTE_NOT_APOS`` (not ``_QUOTE_NOT``) so a possessive apostrophe is
    # not read as a value delimiter: ``search for Murphy's law in namespace
    # C`` previously matched nothing at all and the handler fell back to
    # sending the ENTIRE command sentence to the backend. The H5 lookahead is
    # what keeps the now-permissive lazy capture from over-running — keep it.
    search_match = safe_regex_search(
        rf"(?:search|find|look)\s+(?:for\s+)?{_QUOTE_OPEN}?"
        rf"({_QUOTE_NOT_APOS}+?){_QUOTE_OPEN}?\s+(?:in|within)\b"
        rf"(?=\s+(?:namespace|type)\b)",
        query,
        re.IGNORECASE,
    )
    if search_match:
        params["query"] = _strip_quote_pair(search_match.group(1).strip())

    # A16 post-a16 D6: tighten the namespace regex to a single letter
    # with a word boundary so ``search foo in namespace AB`` / ``... 1``
    # / ``... _`` fails to match and the handler's validation guard
    # fires consistently — matching the input-validation parity that
    # P6-D1/D2 added to ``browse_namespace`` and ``walk_namespace`` in
    # a16. Pre-fix, the regex accepted ``[A-Za-z0-9_.-]+`` and silently
    # passed the malformed argument through to the backend, which
    # returned ``No filtered matches`` with no signal that the
    # namespace itself was invalid.
    namespace_match = safe_regex_search(
        rf"namespace\s+{_QUOTE_OPEN}?([A-Za-z])\b{_QUOTE_OPEN}?",
        query,
        re.IGNORECASE,
    )
    if namespace_match:
        params["namespace"] = namespace_match.group(1).upper()

    # Anchor on the ``in type`` / ``within type`` filter keyword (the way
    # INTENT_PATTERN does). A bare ``type\s+...`` matched the word 'type'
    # anywhere in the search terms — ``search for type 2 diabetes in
    # namespace A`` produced content_type='2', ``search for blood type in
    # namespace A`` produced content_type='in' — and no mimetype starts
    # with those, so every entry was silently filtered out.
    type_match = safe_regex_search(
        rf"\b(?:in|within)\s+type\s+{_QUOTE_OPEN}?([A-Za-z0-9_/.-]+){_QUOTE_OPEN}?",
        query,
        re.IGNORECASE,
    )
    if type_match:
        params["content_type"] = type_match.group(1)


# Post-v2.0.0 D-C/D-D fallback: when the shared keyworded extractor
# finds no canonical ``article|entry|page|of|for|in|from|to`` anchor,
# fall back to peeling a leading intent-keyword prefix. Covers the
# bare-verb forms surfaced by the v2.0.0 live sweep:
#
#   structure Photosynthesis    summary Photosynthesis
#   outline Photosynthesis      summarize Photosynthesis
#   sections Photosynthesis     overview Photosynthesis
#   headings Photosynthesis     toc Photosynthesis
#   table of contents X         contents Photosynthesis
#   show structure Photosynthesis
#
# The optional ``show|display|give|tell`` preamble (with optional
# ``me``/``the``) handles natural-language preambles. Each verb is the
# same one that lights up the corresponding intent regex; if a future
# contributor widens the intent regex (e.g. adds ``layout`` as a
# structure synonym) the prefix set must be widened in lockstep —
# pinned by ``TestEntryPathExtractorVerbSetCanonicalPin`` in the
# post-v2.0.0 sweep file.
_LEADING_INTENT_KEYWORDS_RE = re.compile(
    r"^\s*"
    r"(?:(?:show|display|give|tell)\s+(?:me\s+)?(?:the\s+)?)?"
    r"(?:"
    r"table\s+of\s+contents|"
    r"structure|outline|sections?|headings?|"
    r"summary|summarize|summarise|overview|brief|"
    r"toc|contents"
    r")"
    r"\b\s+",
    re.IGNORECASE,
)

# Post-v2.0.0 D-C: when the canonical-keyword extractor anchors on
# ``of`` inside ``table of contents X``, the captured tail is
# ``contents X``. Peel the leading ``contents`` token so the
# downstream path-resolver sees ``X``. Confined to a leading position
# so legitimate entries containing the word ``contents`` mid-title
# (rare but possible) are untouched.
_TAIL_LEADING_CONTENTS_RE = re.compile(r"^contents\s+", re.IGNORECASE)

# D48: ``get (the) article about X`` anchors on ``article`` and leaves
# ``about X`` as the tail; ``about`` is a bridge word, not part of the
# title, so peel it. Only ``about`` — ``on`` / ``for`` / ``of`` open real
# titles far too often (``On the Origin of Species``) to be safe. And only
# after the object noun: past a preposition the user is spelling the title
# out (``summary of About a Boy``), where ``about`` is the title's own
# first word.
_TAIL_LEADING_ABOUT_RE = re.compile(r"^about\s+", re.IGNORECASE)


def _extract_entry_path_keyworded(query: str, params: Dict[str, Any]) -> None:
    """Shared extractor for get_article / structure / links / toc / summary.

    Locates the LAST keyword (article / entry / page / of / for / in /
    from / to) and treats everything after it as the entry path. This
    captures multi-word titles (``United States``, ``World War II``,
    ``Albert Einstein``) and Wikipedia-legal punctuation like ``@`` (in
    metadata illustration paths ``M/Illustration_48x48@1``), apostrophes,
    parens, etc. — all of which the previous ``[A-Za-z0-9_/.-]+`` capture
    silently truncated, dropping the user at the wrong article (the
    common silent-fall-through failure mode for ``show structure of
    United States`` returning the ``United`` disambig page).

    Post-v2.0.0 D-C / D-D additions: when no canonical anchor matches,
    fall back to stripping a leading intent-keyword prefix
    (``structure``/``summary``/``toc``/etc.) so bare-verb forms
    ``structure Photosynthesis`` and ``toc Photosynthesis`` resolve
    correctly. When the canonical anchor matched on ``of`` inside
    ``table of contents X``, peel the leading ``contents`` token from
    the tail so ``X`` survives as the entry_path.

    The downstream :meth:`SimpleToolsHandler._resolve_natural_language_path`
    helper then runs the captured tail through ``find_title_match`` so a
    free-form title like ``United States`` resolves to the canonical
    stored path ``United_States``.
    """
    # M8: only treat a quote char as a value delimiter when it sits at a token
    # boundary (start/space before the opener, space/end/punct after the
    # closer). Otherwise possessive apostrophes were read as quote delimiters,
    # so ``links in Murphy's law and Sod's law`` matched the span between the
    # two apostrophes and captured ``s law and Sod``.
    #
    # The opener is additionally required to sit in a VALUE SLOT: either at
    # the very start of the query or immediately after an anchor keyword
    # (``article``/``entry``/``page``/``of``/``for``/``in``/``from``/``to``).
    # A title-internal elision's opening apostrophe is always preceded by a
    # title word (``get article Rock 'n' Roll`` → entry_path ``n``), never by
    # an anchor, so it can no longer be read as a value delimiter — while an
    # explicitly quoted value keeps working WHEREVER it appears, including
    # when a modifier clause follows it (``structure of "Photosynthesis" in
    # compact mode``, ``links in "Berlin" and "Paris"``). Anchoring on
    # end-of-query instead would drop those, silently falling through to the
    # last-preposition branch and resolving a confidently WRONG article.
    # ``re`` disallows variable-width lookbehind, so the anchor is consumed
    # in a non-capturing group; only group(1) is ever read.
    quoted_match = safe_regex_search(
        rf"(?:^|\b(?:article|entry|page|of|for|in|from|to)\s+)"
        rf"{_QUOTE_OPEN}({_QUOTE_NOT}+){_QUOTE_OPEN}"
        rf"(?=\s|$|[?.,;:!])",
        query,
    )
    if quoted_match:
        # Post-v2.0.4 D-E sibling: ``get article "  "`` /
        # ``structure of "  "`` (whitespace-only between matched
        # quotes) bypassed the canonical-branch's empty-drop guard
        # because the ``+`` quantifier matches whitespace chars. Trim
        # the captured value and drop the param entirely when empty
        # so the handler's missing-arg guard fires instead of
        # propagating ``"  "`` to the backend's title-promotion.
        captured = quoted_match.group(1).strip()
        if captured:
            params["entry_path"] = captured
        return

    # H6: prefer an explicit object keyword (article / entry / page). Everything
    # after the LAST such keyword is the title, so title-internal prepositions
    # are preserved — ``get article History of France`` → ``History of France``,
    # ``get article Lord of the Rings`` → ``Lord of the Rings`` (previously the
    # last-preposition anchor truncated these to ``France`` / ``the Rings``).
    #
    # Sweep follow-up: without an object keyword, anchor on the FIRST
    # preposition after the intent verb, not the last one in the query.
    # The last-preposition anchor truncated title-internal prepositions
    # the same way the pre-H6 object branch did — ``toc of Battle of
    # Britain`` → ``Britain``, ``links in Lord of the Rings`` → ``the
    # Rings``. ``table of contents`` is matched as one verb phrase so its
    # internal ``of`` can't act as the anchor (``list the table of
    # contents for Marie Curie`` still anchors on ``for``), and the scan
    # starts at the verb phrase's end so a preposition inside a leading
    # scoping clause can't win either. When no verb is found the scan
    # starts at the beginning of the query.
    object_re = re.compile(r"\b(?:article|entry|page)\s+", re.IGNORECASE)
    keyword_re = re.compile(
        r"\b(?:of|for|in|from|to)\s+",
        re.IGNORECASE,
    )
    # Must cover every word the intent regexes accept as the verb, or the
    # scan starts at 0 and a preposition in a LEADING noun phrase wins the
    # anchor: ``list of references in Photosynthesis`` anchored on the
    # ``of`` in ``list of``, yielding ``references in photosynthesis``.
    # ``references``/``related`` mirror the links pattern at line 1021.
    verb_re = re.compile(
        r"\b(?:"
        r"table\s+of\s+contents|"
        r"structure|outline|sections?|headings?|"
        r"summary|summarize|summarise|overview|brief|"
        r"toc|contents|links?|references?|related"
        r")\b",
        re.IGNORECASE,
    )
    matches = list(object_re.finditer(query))
    # Whether the tail follows the object noun rather than a preposition —
    # the ``about`` peel below is confined to that shape.
    anchored_on_object = bool(matches)
    if not matches:
        verb_match = verb_re.search(query)
        scan_from = verb_match.end() if verb_match else 0
        first_prep = keyword_re.search(query, scan_from)
        matches = [first_prep] if first_prep else []
    if matches:
        tail = query[matches[-1].end() :].strip().rstrip("?.,;:!").strip()
        # Post-v2.0.0 D-C: ``table of contents X`` anchors on ``of`` →
        # tail = ``contents X``. Peel the leading ``contents`` so the
        # downstream resolver sees ``X``.
        cleaned = _TAIL_LEADING_CONTENTS_RE.sub("", tail, count=1).strip()
        if cleaned and cleaned != tail:
            tail = cleaned
        # D48: ``get the article about X`` -> tail ``about X``; drop the
        # bridge word so the title probe sees ``X``. Never past a
        # preposition — ``summary of About a Boy`` resolved to "A Boy",
        # and where the index holds both spellings it did so at score 1.0.
        if anchored_on_object:
            cleaned = _TAIL_LEADING_ABOUT_RE.sub("", tail, count=1).strip()
            if cleaned and cleaned != tail:
                tail = cleaned
        # Post-v2.0.0 D-E: peel a surrounding quote pair so an
        # empty-quoted tail (``structure of ""`` / ``get article ""``)
        # doesn't survive to the backend, which would otherwise
        # fuzzy-match it to the Empty_string article at score 1.00.
        # When the quote-pair encloses a real entity (``get article
        # "Photosynthesis"``) the strip also improves the lookup score.
        tail = _strip_quote_pair(tail)
        if tail:
            params["entry_path"] = tail
        return

    # Post-v2.0.0 D-D fallback: no canonical anchor — the intent verb
    # itself acts as the of/for anchor (``structure X``, ``summary X``,
    # ``toc X``). Strip the leading verb (with optional show/give
    # preamble) and use the remainder as the entry_path.
    prefix_match = _LEADING_INTENT_KEYWORDS_RE.match(query)
    if prefix_match:
        tail = query[prefix_match.end() :].strip().rstrip("?.,;:!").strip()
        # Post-v2.0.0 D-E: same quote-pair peel as the canonical branch.
        tail = _strip_quote_pair(tail)
        if tail:
            params["entry_path"] = tail


def _extract_binary(query: str, params: Dict[str, Any]) -> None:
    quoted_match = safe_regex_search(
        rf"{_QUOTE_OPEN}({_QUOTE_NOT}+){_QUOTE_OPEN}", query
    )
    if quoted_match:
        params["entry_path"] = quoted_match.group(1)
    else:
        # "get binary content from I/image.png", "extract pdf I/document.pdf",
        # "retrieve image logo.png".
        #
        # H7: require the connector (from/of/for) AFTER the anchor instead of
        # listing connectors as anchors. re.search matches leftmost, so the old
        # alternation matched ``content`` first and then captured the next
        # token ``from`` as the path — ``get binary content from I/image.png``
        # yielded entry_path ``from``. The connector is now optional but, when
        # present, is consumed before the capture so a bare connector can never
        # be returned as the path.
        # Prefer a path-shaped token (contains ``/`` or ``.``) anywhere
        # after the connector, tolerating filler words: ``get binary
        # content from the file I/logo.png`` must capture ``I/logo.png``,
        # not the determiner ``the`` (the first token after the connector).
        binary_pattern_pathish = (
            r"(?:content|data|entry|pdf|image|video|audio|media)"
            r"\s+(?:from|of|for)\s+"
            r"(?:[A-Za-z0-9_-]+\s+)*?"
            rf"{_QUOTE_OPEN}?([A-Za-z0-9_/.-]*[/.][A-Za-z0-9_/.-]*)"
            rf"{_QUOTE_OPEN}?"
        )
        path_match = safe_regex_search(binary_pattern_pathish, query, re.IGNORECASE)
        if not path_match:
            binary_pattern = (
                r"(?:content|data|entry|pdf|image|video|audio|media)"
                r"\s+(?:from|of|for)\s+"
                r"(?:(?:the|a|an)\s+)*"
                rf"{_QUOTE_OPEN}?([A-Za-z0-9_/.-]+){_QUOTE_OPEN}?"
            )
            path_match = safe_regex_search(binary_pattern, query, re.IGNORECASE)
        if not path_match:
            # No connector form: ``extract pdf I/document.pdf``,
            # ``retrieve image logo.png`` — anchor directly on the media word.
            binary_pattern_no_conn = (
                r"(?:content|data|entry|pdf|image|video|audio|media)"
                rf"\s+{_QUOTE_OPEN}?(?!(?:from|of|for)\b)"
                r"([A-Za-z0-9_/.-]+)"
                rf"{_QUOTE_OPEN}?"
            )
            path_match = safe_regex_search(binary_pattern_no_conn, query, re.IGNORECASE)
        if path_match:
            params["entry_path"] = path_match.group(1)

    metadata_match = safe_regex_search(
        r"\b(metadata|info)\s+only\b", query, re.IGNORECASE
    )
    if metadata_match:
        params["include_data"] = False


def _extract_suggestions(query: str, params: Dict[str, Any]) -> None:
    suggest_pattern = (
        # M9: kept in lockstep with the suggestions INTENT_PATTERN — bare
        # ``complete`` removed; ``autocomplete`` still anchors the verb form.
        r"(?:suggestions?|autocomplete|hints?)"
        rf"\s+(?:for\s+)?{_QUOTE_OPEN}?({_QUOTE_NOT}+){_QUOTE_OPEN}?"
    )
    suggest_match = safe_regex_search(suggest_pattern, query, re.IGNORECASE)
    if suggest_match:
        candidate = suggest_match.group(1).strip()
        # A15 post-a15 P4-D1: when the user types ``suggestions for``
        # with no actual prefix after it, the optional ``(?:for\s+)?``
        # fails to match (no trailing whitespace before EOL), and the
        # regex's mandatory capture group falls back to swallowing
        # "for" itself as the prefix. Handler's missing-arg guard
        # (``if not partial_query``) then never fires because "for"
        # is non-empty. Treat a bare-"for" capture as if no prefix
        # was supplied so the existing guard takes over and the user
        # gets the structured "Missing Search Term" error instead of
        # autocompleting against the literal "for".
        if candidate.lower() != "for":
            params["partial_query"] = candidate


def _extract_search(query: str, params: Dict[str, Any]) -> None:
    # An explicitly delimited term wins wherever it appears, so ``find "World
    # War II" articles`` yields the quoted term alone and the quote chars
    # never reach the backend. ``_QUOTE_NOT`` inside the pair is safe here
    # because BOTH delimiters are mandatory — a possessive apostrophe has no
    # partner immediately after the verb, so this branch simply misses.
    # ``query`` is in the search INTENT_PATTERN's verb set, so it must be
    # stripped here like its siblings — otherwise ``query solar eclipse``
    # searched for the literal terms ``query solar eclipse``. Unlike them it
    # is anchored to the front (``_SEARCH_VERB``): ``query`` is overwhelmingly
    # a NOUN mid-sentence, and an unanchored strip silently discarded the
    # terms before it (``SQL query optimization`` -> ``optimization``).
    quoted = safe_regex_search(
        rf"{_SEARCH_VERB}\s+(?:for\s+)?" rf"{_QUOTE_OPEN}({_QUOTE_NOT}+){_QUOTE_OPEN}",
        query,
        re.IGNORECASE,
    )
    if quoted:
        params["query"] = quoted.group(1).strip()
        return
    # Unquoted: the capture must NOT exclude quote chars, because
    # ``_QUOTE_NOT`` treats a possessive apostrophe as a value delimiter and
    # ``search for Murphy's law`` then captured only ``Murphy`` (``search for
    # O'Brien`` only ``o``). Take everything after the verb (+ optional
    # ``for``). ``(\S[\s\S]*)`` requires a non-space first char, so the
    # degenerate ``search for `` backtracks the optional ``(?:for\s+)?`` off
    # and captures ``for`` — keeping the A11-B4 "search terms required" guard
    # reachable. Do NOT ``_strip_quote_pair`` this tail: it is not a delimited
    # token, and peeling its first and last chars mangles any query that
    # merely begins and ends with a quote char (``search for "Berlin" or
    # "Paris"`` -> ``berlin" or "paris``).
    search_match = safe_regex_search(
        rf"{_SEARCH_VERB}\s+(?:for\s+)?(\S[\s\S]*)",
        query,
        re.IGNORECASE,
    )
    params["query"] = search_match.group(1).strip() if search_match else query


def _extract_search_all(query: str, params: Dict[str, Any]) -> None:
    """Strip "search all files for" prefix to recover the bare query.

    The prefix accepted here must be at least as wide as the ``search_all``
    INTENT_PATTERN that gated this extractor: that pattern makes the target
    noun optional and tolerates bridging words, so ``search across all files
    for X`` / ``search all archives for X`` classify as ``search_all`` — and
    a prefix sub that fails to match silently returns the whole command
    sentence, which is then dispatched as the cross-archive search terms.
    Hence the determiner/quantifier bridge, ``archives`` alongside
    ``files``/``zims``, and the optional ``for``.

    ``zim`` is matched as a *qualifier* ahead of the head noun as well as a
    head noun in its own right. Without that, ``zims?`` claimed the ``zim`` in
    ``search all zim files for X`` and the alternation stopped there, leaving
    ``files for X`` as the cross-archive search terms — the head noun and the
    preposition both polluting the BM25 query for the most natural way there
    is to say this.

    The lazy ``^.*?`` in the substitution is a known ReDoS vector on
    adversarial input, so wrap it in the standard timeout helper and
    fall back to the raw query on timeout — better to search a slightly
    noisy term than to hang the worker.
    """
    try:
        cleaned = run_with_timeout(
            lambda: re.sub(
                r"^.*?(search\s+(all|every(thing|where)?|across)"
                r"\s+((the|all|of|my|our|your|loaded|available)\s+)*"
                r"(\.?zim\s+)?(files?|zims?|archives?)?\s*(for\s+)?)",
                "",
                query,
                flags=re.IGNORECASE,
            ),
            REGEX_TIMEOUT_SECONDS,
            f"Regex operation timed out after {REGEX_TIMEOUT_SECONDS} seconds",
            RegexTimeoutError,
            pool="regex",
        ).strip()
        # A cue-only query (``search all files``) carries no terms; keep the
        # raw sentence rather than dispatching an empty cross-archive search.
        params["query"] = cleaned or query.strip()
    except RegexTimeoutError:
        logger.warning(
            "Regex timeout while extracting search_all query " f"from: {query[:50]}..."
        )
        params["query"] = query.strip()


def _extract_walk_namespace(query: str, params: Dict[str, Any]) -> None:
    m = safe_regex_search(r"namespace\s+([A-Za-z])\b", query, re.IGNORECASE)
    if m:
        params["namespace"] = m.group(1).upper()


def _extract_find_by_title(query: str, params: Dict[str, Any]) -> None:
    m = safe_regex_search(
        r"(?:titled|named|called|path\s+for)\s+(.+?)$", query, re.IGNORECASE
    )
    if m:
        title = _strip_quote_pair(m.group(1).strip().rstrip("?."))
        # Post-v2.0.0 D-E: empty-quoted input must not survive to the
        # handler — the backend fuzzy-matches '""' to the Empty_string
        # article at score 1.00.
        if title:
            params["title"] = title


def _extract_related(query: str, params: Dict[str, Any]) -> None:
    m = safe_regex_search(
        r"(?:related\s+to|linking\s+to|links\s+(?:to|from))\s+(.+?)$",
        query,
        re.IGNORECASE,
    )
    if m:
        entry_path = _strip_quote_pair(m.group(1).strip().rstrip("?."))
        # Post-v2.0.0 D-E: see _extract_find_by_title.
        if entry_path:
            params["entry_path"] = entry_path


def _normalize_url_topic(topic: str) -> str:
    """Collapse a pasted ``http(s)://host/path/Title`` URL to its final
    path segment as the topic.

    A pasted Wikipedia URL was otherwise tokenised on ``/`` downstream and
    the scheme token (``https:``) was taken as the topic, returning the
    wrong article. Only fires on an ``http(s)://host/<path>`` shape with a
    non-empty last segment; anything else is returned unchanged so ordinary
    topics (including ones that merely contain a slash) are not disturbed.
    """
    # Capture the path greedily and trim in code: the older ``(.+?)\s*$`` let
    # the lazy dot and the trailing ``\s*`` overlap on whitespace, which is
    # polynomial-backtracking (ReDoS) bait. ``(.+)$`` is linear, and the
    # match runs under the timeout-bounded wrapper like every other regex here.
    m = safe_regex_search(r"^\s*https?://[^/\s]+/(.+)$", topic, re.IGNORECASE)
    if not m:
        return topic
    path = m.group(1).strip().split("#", 1)[0].split("?", 1)[0].rstrip("/")
    if not path:
        return topic
    segment = path.rsplit("/", 1)[-1]
    segment = unquote(segment).replace("_", " ").strip()
    return segment or topic


def _extract_tell_me_about(query: str, params: Dict[str, Any]) -> None:
    """Extract the topic from a ``tell_me_about``-shaped query.

    Examples:
      * ``"tell me about Photosynthesis"`` -> topic ``"Photosynthesis"``
      * ``"who is Martin Luther King Jr."`` -> topic ``"Martin Luther King Jr."``
      * ``"what is DNA"`` -> topic ``"DNA"``
      * ``"info about the Apollo program"`` -> topic ``"the Apollo program"``
      * ``"explain Berlin to me"`` -> topic ``"Berlin"``  (A11 B3)

    Strips the verb / interrogative prefix, any trailing politeness
    tail ("to me", "for me", "please"), and any trailing sentence
    punctuation. Falls back to the raw query so the search has
    *something* to look up if no prefix matched.
    """
    # A15 post-a15: politeness lead-in ("could you tell me about X",
    # "can you describe Y", "would you explain Z") used to bypass the
    # verb prefix entirely — the regex anchors at ``^\s*`` and "could
    # you" doesn't match the verb alternation, so the whole query fell
    # through to ``topic = query.strip()`` and downstream relied on the
    # tail-probe entity resolver to rescue the actual article. Strip
    # the leading modal scaffold first so the verb regex sees the
    # cleaned query.
    #
    # A15 post-a15 P6-D3: loop the strip so successive politeness
    # phrases peel cleanly (``please could you tell me about X`` →
    # ``could you tell me about X`` → ``tell me about X``). Two
    # separate patterns rather than one combined regex because
    # ``please`` is also legitimate trailing politeness (already
    # handled below) — keeping the leading-only strip narrow
    # (``please``, ``kindly``) avoids accidentally matching mid-
    # query mentions.
    for _ in range(3):
        before = query
        query = safe_regex_sub(
            r"^\s*(?:please|kindly)\s+",
            "",
            query,
            flags=re.IGNORECASE,
        ).strip()
        query = safe_regex_sub(
            r"^\s*(?:could|can|would|will)\s+(?:you|we|i)\s+(?:please\s+)?",
            "",
            query,
            flags=re.IGNORECASE,
        ).strip()
        if query == before:
            break
    # A11 B2: verb prefix uses ``\b`` (word boundary) and the topic
    # capture is ``(.*?)`` (zero-or-more, non-greedy) so ``tell me
    # about`` / ``tell me about `` / ``describe`` produce ``topic=""``
    # instead of falling through to the else-branch with the entire
    # raw query as the topic ("tell me about" → topic="tell me about"
    # → disambiguation to articles titled "Tell Me About Tomorrow").
    # The caller (simple_tools) checks for empty topic and surfaces a
    # ``Topic Required`` error.
    m = safe_regex_search(
        r"^\s*("
        r"tell\s+me\s+about\b|"
        r"show\s+me\s+(?:everything|all|more)\s+(?:about|on)\b|"
        r"everything\s+(?:about|on)\b|"
        r"who\s+(?:is|was|are|were)\b|"
        r"what\s+(?:is|are|was|were)\b|"
        r"describe\b|"
        r"explain\b|"
        r"info(?:rmation)?\s+(?:about|on)\b"
        r")\s*(.*?)\s*\??\s*$",
        query,
        re.IGNORECASE,
    )
    if m:
        topic = m.group(2).strip().rstrip("?.,;:!")
    else:
        topic = query.strip().rstrip("?.,;:!")
    # A11 B3 (post-a10 review): topic-asking phrasings commonly carry a
    # politeness tail — ``explain Berlin to me``, ``describe DNA for
    # me``, ``tell me about cats please``, ``describe DNA for me
    # please``. Strip the trailing politeness so the topic that
    # reaches the search query is clean.
    #
    # Order matters: ``please`` can wrap an inner ``to me`` /
    # ``for me`` (``DNA for me please``), so strip ``please`` FIRST,
    # then strip the bare ``to/for me`` tail. Loop both strips until
    # idempotent in case an unusual phrasing carries both forms.
    # Post-b2 D1: trailing modal politeness — ``tell me about Tokyo
    # if you would``, ``... if you could``, ``... would you``,
    # ``... could you``. Pre-fix the trailing strip only matched
    # ``please`` / ``to me`` / ``for me``; the modal class
    # (``could/would/will/can`` + ``you``, with optional leading
    # ``if you``) was handled at the LEADING site (line ~374) but
    # not the trailing one — the two regexes drifted out of sync.
    # Falling through left the trailing modal in the topic, which
    # then resolved to the stub article for the trailing word
    # (``Would`` / ``Could`` / ``Would_You``). Require an ``if you``
    # OR a trailing ``you`` so a single ``would`` (rare but possible
    # in real article titles) isn't stripped.
    for _ in range(3):
        before = topic
        topic = safe_regex_sub(
            r"\s*,?\s*please\s*$",
            "",
            topic,
            flags=re.IGNORECASE,
        ).strip()
        topic = safe_regex_sub(
            r"\s+(?:to|for)\s+(?:me|us)\s*$",
            "",
            topic,
            flags=re.IGNORECASE,
        ).strip()
        topic = safe_regex_sub(
            r"\s+(?:if\s+you\s+(?:could|would|will|can)"
            r"|(?:could|would|will|can)\s+you)\s*$",
            "",
            topic,
            flags=re.IGNORECASE,
        ).strip()
        if topic == before:
            break
    # D-T1: strip a trailing purpose / aspect qualifier. ``what is X
    # good for?`` is one of the most common shapes of consumer-health
    # question, and the tail rode into the topic: ``aspirin good for``
    # put "Drugs beginning with G" at rank 1 on MedlinePlus and lost the
    # "Aspirin: MedlinePlus Drug Information" article entirely, while
    # the identical ``what is aspirin?`` resolved it first. The tail
    # asks something ABOUT the topic; it is never part of the topic's
    # name. Same class as the politeness tails swept above, and equally
    # end-anchored. Guarded so a query that is ONLY the qualifier
    # (``what is it good for``) keeps a non-empty topic for the
    # downstream topic-required / filler checks to judge.
    _purpose_stripped = safe_regex_sub(
        r"\s+(?:"
        r"(?:good|great|useful|helpful|used|prescribed|indicated|recommended)"
        r"\s+for"
        r"|(?:used|prescribed|indicated|recommended)\s+to\s+treat"
        r"|made\s+(?:of|from|out\s+of)"
        r")\s*$",
        "",
        topic,
        flags=re.IGNORECASE,
    ).strip()
    if _purpose_stripped:
        topic = _purpose_stripped
    # A16 post-a16 D2: strip orphan trailing chain connectors. ``tell
    # me about Apollo 11 also`` with no right-hand topic used to leave
    # ``Apollo 11 also`` as the search topic, where the fuzzy ranker
    # promoted the unrelated ``Also`` disambig article above Apollo 11
    # (the word ``also`` is a stronger exact-title-token match than the
    # full phrase). The chained-intent guidance can't help here — the
    # connector regex requires a right-hand operand. Strip the orphan
    # tail before the search sees it.
    #
    # Pass-2 self-audit: ``then`` deliberately NOT in the strip list.
    # Real article titles end with ``Then`` (``Now and Then``,
    # ``Back Then``, ``Once Upon a Time ... Then ...``) often enough
    # that stripping it would mangle valid topics. ``then`` orphans
    # (``Apollo 11 then``) are rare and the search ranker degrades
    # gracefully.
    for _ in range(3):
        before = topic
        topic = safe_regex_sub(
            r"\s+(?:and|or|also|plus)\s*$",
            "",
            topic,
            flags=re.IGNORECASE,
        ).strip()
        topic = safe_regex_sub(r"\s*[,&]\s*$", "", topic).strip()
        if topic == before:
            break
    # Post-v2.0.0 D-E (extended pass-4): strip a surrounding matched
    # quote pair so ``tell me about ""`` doesn't survive as the literal
    # 2-char ``""`` and silently resolve to the ``Empty_string``
    # Wikipedia article (the same shape D-E fixed for find_by_title,
    # related, and entry_path_keyworded). Bonus regression upside:
    # ``tell me about "Photosynthesis"`` now searches the bare topic
    # instead of the quoted form, which is a cleaner search input.
    topic = _strip_quote_pair(topic)
    topic = _normalize_url_topic(topic)
    params["topic"] = topic


def _trim_entry_token(token: str) -> str:
    """Peel prose punctuation off a captured entry path.

    Trailing sentence punctuation always goes (``A/Bar.`` -> ``A/Bar``). A
    closing paren goes only when it has no opener inside the token, so a
    parenthesised aside (``see A/Foo)``) is trimmed while a disambiguated
    title (``A/Mercury_(planet)``) keeps its own parens.

    A trailing apostrophe follows the same balance rule. Quoting the paths —
    ``get entries 'A/Foo' and 'A/Bar'`` — is an obvious thing to type, and the
    opening quote is excluded by the namespace lookbehind while the closing
    one is inside the suffix class, so every quoted path arrived at
    ``get_entries`` as ``A/Foo'`` and resolved to nothing. An odd count means
    the token closes a quote that opened outside it; an even one means the
    apostrophes are the title's own (``A/Rock_'n'_Roll``), which must survive.
    """
    token = token.rstrip(".?,;:!")
    peeled = True
    while peeled:
        peeled = False
        while token.endswith(")") and token.count("(") < token.count(")"):
            token = token[:-1].rstrip(".?,;:!")
            peeled = True
        if token.endswith("'") and token.count("'") % 2 == 1:
            token = token[:-1].rstrip(".?,;:!")
            peeled = True
    return token


def _extract_get_zim_entries(query: str, params: Dict[str, Any]) -> None:
    """Extract namespace/path tokens like ``A/Foo`` or ``M/Image.png``.

    Both uppercase and lowercase namespace letters are accepted so that
    Sub-D-2 Rule 1 (which lowercases the query before extraction) does
    not suppress matches. The single-letter + ``/`` + non-dot-only suffix
    shape is specific enough to exclude bare file paths like
    ``wikipedia.zim`` while matching ZIM entry paths (``a/foo``,
    ``m/image.png``, etc.).
    """
    # M7: a negative lookbehind anchors the namespace letter so only a
    # standalone single-letter namespace matches. Without it the last letter of
    # a longer word qualified — ``get entries A/Foo and/or B/Bar`` captured the
    # bogus ``d/or`` (from ``an[d/or]``); ``km/h``, ``either/or``, URLs, etc.
    # produced the same false captures.
    #
    # The suffix class carries the same Wikipedia-legal punctuation the
    # single-entry sibling ``_extract_entry_path_keyworded`` accepts —
    # disambiguated titles (``A/Mercury_(planet)``), metadata illustration
    # paths (``M/Illustration_48x48@1``), ``A/C++``, apostrophes. A narrower
    # class truncated those at the first offending character and shipped the
    # stump to ``get_entries`` as if the caller had typed it.
    #
    # D50: zimit / warc2zim archives store domain-shaped paths
    # (``medlineplus.gov/measles.html``) and that is what this tool's own
    # ``Path:`` lines print for them, so the batch intent must accept that
    # shape alongside the single-letter namespace one. The lookbehind
    # still anchors the token start; the dotted host keeps ``wikipedia.zim``
    # (no slash) and ``and/or`` (no dot) excluded.
    entries = safe_regex_findall(
        rf"(?<![A-Za-z0-9])(?:[A-Za-z]/|{_DOMAIN_PATH_BODY})[\w\-./%()@+'~*]+",
        query,
    )
    if entries:
        params["entries"] = [_trim_entry_token(e) for e in entries]


def _extract_get_section(query: str, params: Dict[str, Any]) -> None:
    """Extract ``section_name`` and ``entry_path`` from a section query.

    Examples:
      * ``"section Evolution of Biology"`` -> name=Evolution, path=Biology
      * ``"the Evolution section of Biology"`` -> name=Evolution, path=Biology
      * ``"section 'Cellular respiration' of Biology"`` -> name=Cellular
        respiration, path=Biology
      * ``"section 3 of Biology"`` -> name="3" (numeric) — handler treats
        bare integers as 1-indexed positions into the article's headings.
      * ``"narrow section Geography of Berlin"`` (or ``"just section …"``)
        -> name=Geography, path=Berlin, narrow=True. Tells the handler
        to scope the slice to the heading itself (no nested
        subsections). Op3: surfaces ``include_subsections=False`` to
        small-model callers via a memorable verb.

    Two separate patterns because the section-name placement differs:
    pre-keyword (``"section X of Y"``) vs. pre-keyword-with-determiner
    (``"the X section of Y"``). Quoted names take precedence so a
    section called ``"In the news"`` doesn't get parsed as ``"In"`` +
    `` the news`` of nothing.
    """
    # Op3: detect a "narrow" / "just" prefix and strip it before the
    # regular section-extraction passes run. Stays a flag in ``params``
    # so the handler can switch ``include_subsections``.
    narrow_match = safe_regex_search(
        r"^\s*(?:narrow|just|only)\s+", query, re.IGNORECASE
    )
    if narrow_match:
        params["narrow"] = True
        query = query[narrow_match.end() :]
    # Form A-quoted / B-quoted: an explicitly quoted section name is taken
    # WHOLE, up to its closing quote, before the unquoted forms get a
    # chance to split it. The docstring above promises exactly this
    # ("Quoted names take precedence so a section called ``In the news``
    # doesn't get parsed as ``In`` + `` the news`` of nothing"), but the
    # unquoted forms only ever had an *optional* closing quote, so
    # ``section "Table of Contents" of X`` still split at the first
    # `` of `` and leaked the closing quote into the path
    # (``entry_path='contents" of X'``). Requiring the closing quote —
    # and matching the name greedily so the LAST quote before the
    # connector closes it — restores the guarantee.
    for quoted_pattern in (
        rf"\b(?:the\s+)?section\s+{_QUOTE_OPEN}(.+){_QUOTE_OPEN}"
        rf"\s+(?:of|in|from)\s+{_QUOTE_OPEN}?(.+?){_QUOTE_OPEN}?\s*\??\s*$",
        rf"\bthe\s+{_QUOTE_OPEN}(.+){_QUOTE_OPEN}\s+section"
        rf"\s+(?:of|in|from)\s+{_QUOTE_OPEN}?(.+?){_QUOTE_OPEN}?\s*\??\s*$",
    ):
        m = safe_regex_search(quoted_pattern, query, re.IGNORECASE)
        if m:
            params["section_name"] = m.group(1).strip()
            params["entry_path"] = m.group(2).strip().rstrip("?.,;:!")
            return
    # Form A: ``[the] section <name> of|in|from <path>``
    #
    # v3.3.1 field report: the lazy name capture split at the FIRST
    # connector, so every heading with "of" in it was unreachable —
    # including "Table of Contents", which the tool's own ``view='toc'``
    # prints unquoted and thereby invites a caller to type back. Quoting it
    # worked; typing it did not.
    #
    # Neither end of the string is reliably right. Last-wins breaks
    # ``section History of A/The History of Rome``, where the second " of "
    # belongs to the PATH; first-wins breaks the reported case. So the split
    # is chosen by which tail actually looks like an entry path, and falls
    # back to the historical first-connector reading when none does — a
    # genuinely ambiguous ``section Symptoms of Diabetes`` keeps the answer
    # it has always given.
    split = _split_section_name_and_path(query)
    if split is not None:
        params["section_name"], params["entry_path"] = split
        return
    # M8: the name capture must tolerate an apostrophe (``section Earth's
    # atmosphere of Earth``). It also has to tolerate the curly DOUBLE
    # quotes an archive puts inside a heading it authored — ``section 2.
    # Analytics or "Logic" of iep.utm.edu/aristotle/`` extracted nothing
    # at all while ``_QUOTE_NOT_APOS`` excluded them, so a heading the
    # tool itself printed was unreachable. The quoted forms above already
    # peeled a *deliberately* quoted name, so an unrestricted class here
    # can no longer swallow one.
    m = safe_regex_search(
        r"\b(?:the\s+)?section\s+(.+?)"
        rf"\s+(?:of|in|from)\s+{_QUOTE_OPEN}?(.+?){_QUOTE_OPEN}?\s*\??\s*$",
        query,
        re.IGNORECASE,
    )
    if m:
        params["section_name"] = m.group(1).strip()
        params["entry_path"] = m.group(2).strip().rstrip("?.,;:!")
        return
    # Form B: ``the <name> section of|in|from <path>``
    m = safe_regex_search(
        r"\bthe\s+(.+?)\s+section"
        rf"\s+(?:of|in|from)\s+{_QUOTE_OPEN}?(.+?){_QUOTE_OPEN}?\s*\??\s*$",
        query,
        re.IGNORECASE,
    )
    if m:
        params["section_name"] = m.group(1).strip()
        params["entry_path"] = m.group(2).strip().rstrip("?.,;:!")
        return
    # Form C: ``[get article] <path> section <name>`` — section name as a
    # trailing suffix with no of/in/from connector (``get article Quantum
    # computing section History``). Strip an optional leading get-article
    # verb so the path is just the article title.
    m = safe_regex_search(
        r"^\s*(?:(?:get|show|read|display|fetch|open)\s+"
        r"(?:article|entry|page)?\s*)?"
        rf"(.+?)\s+section\s+{_QUOTE_OPEN}?({_QUOTE_NOT_APOS}+?){_QUOTE_OPEN}?"
        r"\s*\??\s*$",
        query,
        re.IGNORECASE,
    )
    if m:
        params["entry_path"] = m.group(1).strip().rstrip("?.,;:!")
        params["section_name"] = m.group(2).strip()


# A tail that reads as an entry path rather than as more prose: it carries a
# path separator, names an HTML file, or is a single token holding a dot or
# underscore (``A/Page``, ``medlineplus.gov/asthma.html``,
# ``wikipedia_en_all``). Deliberately NOT "any single word": ``Rome`` is a
# perfectly good article title, and treating it as path-shaped would split
# ``section History of A/The History of Rome`` in the middle of its path.
_PATH_SHAPED_RE = re.compile(
    # Each alternative is grouped explicitly: two of the three are anchored
    # and one is not, and a bare top-level ``|`` between them reads as though
    # the anchors might bind to the whole pattern.
    r"(?:/)"  # a path separator anywhere in the tail
    r"|(?:\.html?$)"  # ...or it names an HTML file
    r"|(?:^\S*[._]\S*$)",  # ...or it is one token carrying a dot/underscore
    re.IGNORECASE,
)

# ``[the] section`` prefix, and the of/in/from connector, for the Form A
# split. An optional leading verb is consumed so ``get section X of Y`` is
# read the same way as ``section X of Y`` — the pattern this replaces used a
# bare ``\b`` and so matched mid-string for free.
_SECTION_PREFIX_RE = re.compile(
    r"^\s*(?:(?:get|show|read|display|fetch|open)\s+)?(?:the\s+)?section\s+",
    re.IGNORECASE,
)
_SECTION_CONNECTOR_RE = re.compile(r"\s+(?:of|in|from)\s+", re.IGNORECASE)


def _split_section_name_and_path(query: str) -> Optional[Tuple[str, str]]:
    """``section <name> of <path>`` -> ``(name, path)``, or ``None``.

    Picks among the connectors rather than assuming the first or the last:
    the LAST one whose tail is path-shaped wins, because the path is the
    tail and a section name may legitimately contain "of". When no tail is
    path-shaped the first connector wins, which is what this parser has
    always done and the only defensible reading of ``section Symptoms of
    Diabetes``.

    Returns ``None`` when the query is not Form A at all, leaving the
    remaining forms to try.
    """
    prefix = _SECTION_PREFIX_RE.match(query)
    if not prefix:
        return None
    remainder = query[prefix.end() :].strip().rstrip("?")
    connectors = list(_SECTION_CONNECTOR_RE.finditer(remainder))
    if not connectors:
        return None

    def _clean(text: str) -> str:
        return text.strip().strip("\"'\u201c\u201d\u2018\u2019").strip()

    chosen = connectors[0]
    for match in reversed(connectors):
        tail = remainder[match.end() :].strip()
        if tail and _PATH_SHAPED_RE.search(tail):
            chosen = match
            break
    name = remainder[: chosen.start()].strip()
    path = remainder[chosen.end() :].strip().rstrip("?.,;:!")
    if not name or not path:
        return None
    return _clean(name), _clean(path)


# Post-v2.0.0 D-B: filename hint extractor for the ``metadata`` intent.
# ``metadata for wikipedia_en_all_maxi_2026-02.zim`` carries the target
# file name in the query body; pre-fix the parser ignored it and the
# dispatcher's no-zim-file gate fired when 2+ archives were loaded. The
# hint is stashed in ``params["metadata_target"]`` and resolved against
# ``zim_operations.list_zim_files_data()`` in the dispatcher.
#
# Limited to ``.zim``-suffixed tokens — a permissive bare-name match
# would collide with phrasings like ``info about Python`` (where
# ``Python`` is a topic, not a file). The ``.zim`` suffix is the
# canonical disambiguator.
_METADATA_FILENAME_RE = re.compile(
    r"\b(metadata|info|details?)\s+(?:for|about|of)\s+" r"([A-Za-z0-9_.\-]+\.zim)\b",
    re.IGNORECASE,
)


def _extract_metadata(query: str, params: Dict[str, Any]) -> None:
    """Extract a filename hint for the ``metadata`` intent.

    See module-level ``_METADATA_FILENAME_RE`` docstring. Only ``.zim``
    targets are captured. Bare ``metadata`` (no filename) leaves
    ``metadata_target`` unset and the dispatcher's existing no-zim-file
    behaviour kicks in.
    """
    match = _METADATA_FILENAME_RE.search(query)
    if match:
        params["metadata_target"] = match.group(2)


_PARAM_EXTRACTORS = {
    "browse": _extract_browse,
    "filtered_search": _extract_filtered_search,
    "get_article": _extract_entry_path_keyworded,
    "structure": _extract_entry_path_keyworded,
    "links": _extract_entry_path_keyworded,
    "toc": _extract_entry_path_keyworded,
    "summary": _extract_entry_path_keyworded,
    "binary": _extract_binary,
    "suggestions": _extract_suggestions,
    "search": _extract_search,
    "search_all": _extract_search_all,
    "tell_me_about": _extract_tell_me_about,
    "walk_namespace": _extract_walk_namespace,
    "find_by_title": _extract_find_by_title,
    "related": _extract_related,
    # Same shape as ``related``: the topic/entry path trails the direction
    # phrase, so the existing extractor handles it unchanged.
    "inbound_links": _extract_related,
    "get_zim_entries": _extract_get_zim_entries,
    "get_section": _extract_get_section,
    "metadata": _extract_metadata,
}


class IntentParser:
    """Parse natural language queries to determine user intent."""

    # Intent patterns with priority, confidence scores, and intent type
    # Format: (pattern, intent, base_confidence, specificity_weight)
    # specificity_weight: higher = more specific pattern, used for tie-breaking
    INTENT_PATTERNS = [
        # File listing - very specific
        (
            r"\b(list|show|what|available|get)\s+(files?|zim|archives?)\b",
            "list_files",
            0.95,
            10,
        ),
        # Metadata - specific keywords.
        # H8: the literal word ``metadata`` is an unambiguous archive cue, so
        # ``metadata for|about|of <X>`` routes to metadata as before. But
        # ``info`` / ``details`` are ambiguous — ``info about Python`` /
        # ``details of the French Revolution`` are TOPIC asks, not file
        # metadata — so they only route to ``metadata`` when the target is
        # file-shaped (a ``.zim`` token, or ``this/the/that file|archive|zim``).
        # Bare topic forms now fall through to ``tell_me_about``. (The
        # ``metadata\s+(for|about|of)`` anchor also keeps the binary
        # ``... content metadata only for X`` query out of this branch.)
        (r"\bmetadata\s+(?:for|about|of)\b", "metadata", 0.9, 9),
        (
            r"\b(info|details?)\s+(?:for|about|of)\s+"
            r"(?:[A-Za-z0-9_.\-]+\.zim\b|"
            r"(?:this|the|that)\s+(?:zim|file|archive))",
            "metadata",
            0.9,
            9,
        ),
        # Main page - very specific
        (r"\b(main|home|start)\s+page\b", "main_page", 0.95, 10),
        # Namespace listing - very specific
        (r"\b(list|show|what)\s+namespaces?\b", "list_namespaces", 0.95, 10),
        # Browse - moderately specific
        (
            r"\b(browse|explore|show|list)\s+(namespace|articles?|entries)\b",
            "browse",
            0.85,
            7,
        ),
        # Get specific article section — must beat the generic
        # ``structure`` pattern below (which also matches ``section``).
        # Two surface forms: ``section X of Y`` and ``the X section of Y``.
        # Specificity 10 + base 0.95 keeps it well above the
        # ``sections? of`` pattern (specificity 8, base 0.85).
        (
            r"\bsection\s+\S+.*\s+(?:of|in|from)\s+\S+",
            "get_section",
            0.95,
            10,
        ),
        (
            r"\bthe\s+\S+.*\s+section\s+(?:of|in|from)\s+\S+",
            "get_section",
            0.95,
            10,
        ),
        # Trailing-suffix form: ``[get article] <path> section <name>`` —
        # the section name follows the path with no of/in/from connector.
        # The live tool mis-routed this to ``structure`` (which also matches
        # ``section``) and then errored "Cannot find entry" looking up the
        # whole literal phrase as a title. Specificity 9 beats ``structure``
        # (8) but stays below the ``... of <path>`` forms (10).
        (
            r"\bsection\s+\S+\s*\??\s*$",
            "get_section",
            0.9,
            9,
        ),
        # Article structure - moderately specific
        (
            r"\b(structure|outline|sections?|headings?)\s+(of|for)?\b",
            "structure",
            0.85,
            8,
        ),
        # Table of contents - specific
        (r"\b(table\s+of\s+contents|toc|contents)\s*(of|for)?\b", "toc", 0.95, 10),
        # Summary - specific
        (
            r"\b(summary|summarize|summarise|overview|brief)\s*(of|for)?\b",
            "summary",
            0.9,
            9,
        ),
        # Links - moderately specific
        (r"\b(links?|references?|related)\s+(in|from|to)\b", "links", 0.85, 7),
        # Binary/media - specific keywords
        (
            r"\b(get|retrieve|download|extract|fetch)\s+"
            r"(binary|raw|pdf|image|video|audio|media)\b",
            "binary",
            0.9,
            9,
        ),
        (r"\b(binary|raw)\s+(content|data)\s+(for|from|of)\b", "binary", 0.9, 9),
        # Suggestions - moderately specific. The trailing assertion
        # accepts a word boundary (``autocomplete evol``) OR a quote
        # character (``autocomplete "evol"``) so the quoted form
        # advertised in the missing-arg hint actually routes to this
        # intent (P3-D4). Pre-fix, the bare ``\b`` after the optional
        # ``(for|of)?`` group failed before a quote char and the query
        # silently fell through to the ``search`` general fallback.
        (
            # M9: the bare verb ``complete`` was dropped — the adjective
            # ``complete`` (``complete works of Shakespeare``,
            # ``complete history of X``) is far more common than the verb and
            # hijacked get_article/topic queries into autocomplete.
            # ``autocomplete`` / ``suggestions`` / ``hints`` remain reliable.
            r"\b(suggestions?|autocomplete|hints?)\s+(for|of)?" r"(?=\b|['\"‘’“”])",
            "suggestions",
            0.85,
            7,
        ),
        # Filtered search - less specific
        (
            r"\b(search|find|look)\s+.+\s+(in|within)\s+(namespace|type)\b",
            "filtered_search",
            0.8,
            6,
        ),
        # Get multiple entries (batch) - explicit plural cue, beats singular.
        # Singular `(article|entry|page)\b` won't match plural `articles` /
        # `entries` because of the word-boundary, so this pattern lights up
        # only on plural cues.
        (
            r"\b(get|fetch|retrieve|read)\s+(articles|entries|multiple)\b",
            "get_zim_entries",
            0.9,
            8,
        ),
        # Get article - common words. D48: tolerate a determiner between
        # the verb and the noun (``get the article about X``) — the
        # natural phrasing otherwise fell to the search fallback with the
        # whole sentence as terms, ``**the**`` highlighted in every
        # snippet. Same tolerance ``_LEADING_INTENT_KEYWORDS_RE`` and the
        # section patterns already grant their verbs.
        (
            r"\b(get|show|read|display|fetch)\s+"
            r"(?:(?:the|an?|this|that)\s+)?(article|entry|page)\b",
            "get_article",
            0.75,
            5,
        ),
        # search_all - very specific
        (
            # ``(\.?zim\s+)?`` lets ``zim``/``.zim`` qualify the head noun
            # ("search all zim files for X"). Without it the alternation below
            # claimed the qualifier, and the extractor's matching group has to
            # stay at least this wide or the head noun leaks into the terms.
            r"\bsearch\s+(all|every(thing|where)?|across)"
            r"\s+(\.?zim\s+)?(files?|zims?)?\b",
            "search_all",
            0.95,
            10,
        ),
        # walk_namespace - very specific
        (
            r"\b(walk|iterate|dump|enumerate)\s+namespace\b",
            "walk_namespace",
            0.95,
            10,
        ),
        # find_by_title - moderately specific
        (
            r"\b(find|locate|resolve)\s+(article|entry|page)?"
            r"\s*(titled|named|called)\b",
            "find_by_title",
            0.9,
            8,
        ),
        (r"\bwhat'?s\s+the\s+path\s+for\b", "find_by_title", 0.9, 8),
        # Inbound links — "what links HERE", the reverse-direction question.
        # v3.3.1 field report: every one of these phrasings used to fall
        # through to the outbound ``related`` / ``links`` intents and be
        # rendered under a header asserting the opposite direction, so simple
        # mode answered "what links to X" with what X links FROM. Priority 10
        # so these beat ``related`` (8) and ``links`` (7); ``what links from``
        # deliberately stays outbound below.
        (
            r"\b(backlinks?\s+(for|to)|inbound\s+links?\s+(to|for)"
            r"|what\s+links\s+(to|here)"
            r"|wh(ich|at)\s+articles?\s+link\s+to"
            r"|articles?\s+linking\s+to)\b",
            "inbound_links",
            0.92,
            10,
        ),
        # related - moderately specific
        (
            r"\b(related\s+to|what\s+links\s+from)\b",
            "related",
            0.9,
            8,
        ),
        # Search - general fallback
        (r"\b(search|find|look\s+for|query)\b", "search", 0.7, 3),
        # Topic ask — explicit interrogative or "tell me about" phrasing.
        # Routes to the ``tell_me_about`` handler which runs a search and,
        # when the top result is a strong title match, also fetches the
        # article body so the caller gets primary content in a single
        # round trip. Confidence is set to beat the bare ``search``
        # fallback (0.7) but stay below specific intents like
        # ``walk_namespace`` / ``search_all`` (>= 0.9).
        (
            r"\b(tell\s+me\s+about|"
            r"show\s+me\s+(everything|all|more)\s+(about|on)|"
            r"everything\s+(about|on)|"
            r"who\s+(is|was|are|were)|"
            r"what\s+(is|are|was|were)|"
            r"describe|explain|"
            r"info(rmation)?\s+(about|on))\b",
            "tell_me_about",
            0.85,
            7,
        ),
    ]

    # Post-a20 PD2-1: trailing politeness markers ("please", "thanks",
    # "thank you", "kindly") were stripped only by
    # ``_extract_tell_me_about``. Every other extractor that captures
    # the topic / search-terms with a greedy tail
    # ((``_extract_search``, ``_extract_search_all``, ``_extract_find_by_title``,
    # ``_extract_related``, ``_extract_suggestions``,
    # ``_extract_entry_path_keyworded`` — feeding get_article / links /
    # structure / toc / summary, ``_extract_get_zim_entries``,
    # ``_extract_get_section``) silently swallowed the politeness as
    # part of the captured value:
    #
    #   * ``search for biology please`` → ``query="biology please"`` →
    #     ranks ``Thanks Maa`` etc. above ``Biology``.
    #   * ``find article titled Berlin please`` → looks up
    #     ``Berlin please`` (not found).
    #   * ``links in Photosynthesis please`` → tries to fetch
    #     ``Photosynthesis please`` (not found).
    #
    # Strip universally at the top of ``parse_intent`` so every
    # extractor sees the cleaned query. The strip is end-anchored
    # (``\s*$``), so legitimate uses of the politeness word as content
    # (``search for "Please Understand Me"`` — song title; the quoted
    # form fully encloses the content phrase, and the trailing ``please``
    # after the close-quote is what gets stripped) are unaffected. Loop
    # the strip so combinations like ``biology, thanks please`` peel
    # cleanly.
    # Post-a21 P1-D6 + P1-D7: widen the politeness token list to cover
    # British/texting variants (``ta`` / ``cheers`` / ``thx`` / ``ty``
    # / ``pls``) and the obvious multi-language tokens (``bitte`` /
    # ``danke`` / ``merci`` / ``gracias`` / ``por favor``). Live
    # transcripts show small models speculatively appending these
    # too — same shape as the post-a20 PD2-1 ``please``/``thanks``
    # leak. Several of the new tokens are short (``ta`` is 2 chars,
    # ``ty`` is 2 chars) so the leading anchor must guarantee a
    # word boundary or ``cantata`` / ``feta`` / ``Dante`` would get
    # their last 2 chars eaten. Pre-extension, the leading anchor
    # was ``\s*[,;.!?]?\s*`` — zero-or-more whitespace lets the
    # regex match mid-word. The extension tightens to
    # ``(?:^|\s+|[,;.!?]\s*)`` — start-of-string OR at least one
    # whitespace OR punctuation + optional whitespace. Embedded
    # ``ta`` / ``ty`` substrings inside other words no longer match.
    #
    # Post-a22 P1-D2: further extend with the SMS / chat variants the
    # post-a21 enumeration didn't cover — ``thnx`` / ``thanx`` /
    # ``tysm`` / ``kthx`` / ``kthxbai``. Live a22 sweep observed
    # ``search for biology thnx`` searching for ``"biology thnx"``
    # (3 irrelevant matches), and ``search for biology thanx``
    # searching for ``"biology thanx"`` — same shape as the missed
    # ``ta`` / ``cheers`` class in the post-a21 sweep. The leading
    # word-boundary anchor still protects against in-word matches
    # (``thank`` ends ``cathank``? no, but ``thnx`` inside another
    # word is structurally unlikely; ``ty`` inside ``cantata``
    # is — and the existing anchor already handles that). All new
    # tokens are also ≥4 chars except ``kthx``, which is still
    # word-anchored.
    #
    # Post-a23 P1-D2: narrow-scope sibling sweep widened the SMS family
    # to cover live-observed misses — ``tx`` / ``txs`` / ``tyvm`` /
    # ``thnks`` / ``thxx`` / ``kthxbye``, multi-word ``thanks a million``
    # and ``thank (you|u) (so|very) much``, and the second wave of
    # multilingual tokens ``obrigado(a)?`` (Portuguese), ``arigatou?``
    # (Japanese romaji), ``spasibo`` (Russian). Same narrow-enumeration
    # shape as the a22 → a23 progression — every politeness sweep so
    # far has shipped narrower than the natural family. The 2-char
    # token ``tx`` keeps the leading word-boundary anchor (already
    # tightened post-a21) so it can't eat the last two chars of
    # embedded words; word-anchored 2-char tokens are still safer than
    # mid-word matches.
    # Post-a24 P1-D3 / P1-D4: third-wave multilingual extensions.
    # P1-D3 — multi-word counterparts of the existing single-word
    # multilingual tokens (``merci beaucoup``, ``vielen dank``,
    # ``muchas gracias``, ``arigatou gozaimasu``, ``domo arigato``,
    # ``terima kasih``). Pre-fix, the regex only matched the single-word
    # form, leaving the leading qualifier behind (``muchas gracias`` →
    # ``gracias`` peeled, ``muchas`` left → ``"biology muchas"`` searched).
    # P1-D4 — more single-word tokens live-observed in post-a24 probes:
    # ``mahalo`` (Hawaiian), ``xie xie``/``xièxie`` (Chinese romaji),
    # ``shukran`` (Arabic), ``kiitos`` (Finnish), ``tack`` (Swedish),
    # ``gomawo``/``kamsahamnida`` (Korean romaji), ``dhanyavad`` (Hindi
    # romaji), ``domo`` (Japanese), ``gozaimasu`` (Japanese formal
    # suffix). Same narrow-scope sibling pattern as a23 → a24 — each
    # sweep has shipped the politeness regex narrower than the natural
    # family.
    #
    # Embedded-token safety: every new token preserves the leading
    # ``(?:^|\s|[,;.!?]\s*)`` anchor, so ``tack`` inside ``attack`` /
    # ``thumbtack`` and ``domo`` inside ``domoic`` / ``Komodo`` don't
    # match — there's no whitespace / punctuation between the embedding
    # word's prefix and the politeness candidate. Multi-word entries are
    # listed BEFORE their single-word counterparts so the alternation
    # engine matches the maximal phrase even though Python's regex is
    # leftmost-first (the end-anchor + backtracking would still find the
    # longer match, but explicit ordering keeps the pattern's intent
    # readable).
    _TRAILING_POLITENESS_RE = (
        # A SINGLE leading whitespace atom, deliberately not ``\s+`` — the
        # same fixed-width shape ``_PARAM_LEAK_RE`` uses, and for the same
        # reason: a greedy repeat whose tail is a failing alternation
        # backtracks O(n^2) over a long whitespace run, and ``safe_regex_sub``
        # cannot bound that cost because CPython's ``re`` holds the GIL for
        # the whole match. Callers that hand over a raw, un-collapsed query
        # (``_normalize_and_validate_query_params``, the chain-detection
        # halves) would otherwise burn seconds of CPU on a 4 KB query.
        # Behaviour is unchanged: with a run of spaces the match simply
        # starts at the last one and the caller's ``.strip()`` removes the
        # remainder.
        r"(?:^|\s|[,;.!?]\s*)"
        r"(?:please|kindly|"
        # ``thanks (a lot|a million)`` — multi-word extensions of the
        # base ``thanks`` token.
        r"thanks(?:\s+a\s+(?:lot|million))?|"
        # ``thank (you|u) (so|very) much`` + plain ``thank (you|u)``.
        # Optional ``(so|very) much`` tail captures the heavier
        # politeness wrap small models emit.
        r"thank\s+(?:you|u)(?:\s+(?:so|very)\s+much)?|"
        # Post-b2 D1 sibling: modal politeness — ``if you (would|could
        # |will|can)`` and ``(could|would|will|can) you``. Symmetric
        # to the LEADING-modal regex in ``_extract_tell_me_about``
        # (line ~374), which has handled ``could you tell me about X``
        # since post-a15 P6-D3. The b2 D1 sweep added the modal class
        # to the trailing strip inside ``_extract_tell_me_about``;
        # this sibling extension lifts it to the universal layer so
        # EVERY extractor benefits — pre-fix, ``search for biology
        # if you would`` searched for ``"biology if you would"``,
        # same shape as the post-a20 PD2-1 ``please`` leak that
        # motivated the universal strip in the first place. Both
        # alternation branches require a ``you`` so a bare trailing
        # modal verb (``Berlin would``) isn't stripped from real
        # article titles.
        r"if\s+you\s+(?:could|would|will|can)|"
        r"(?:could|would|will|can)\s+you|"
        # Longest-first within each family so the regex engine matches
        # the maximal token even though Python's alternation is
        # leftmost-first (backtracking would still find the longer
        # match thanks to the end-anchor, but explicit ordering keeps
        # the pattern readable and avoids relying on backtracking).
        r"kthxbai|kthxbye|kthx|"
        r"tyvm|tysm|ty|"
        r"thnks|thanx|thnx|thxx|thx|"
        r"pls|ta|cheers|txs|tx|"
        # Post-a24 P1-D3: multi-word multilingual variants — listed
        # before their single-word forms so the longer phrase wins. The
        # single-word forms still match alone when the qualifier is
        # absent.
        r"merci\s+beaucoup|"
        r"vielen\s+dank|"
        r"muchas\s+gracias|"
        r"arigatou?\s+gozaimasu|"
        r"domo\s+arigatou?|"
        r"terima\s+kasih|"
        r"por\s+favor|"
        # Multilingual politeness — Latin family + Asian-language
        # romaji. The Cyrillic ``спасибо`` and Devanagari forms aren't
        # included because they don't appear in ASCII-leaked queries
        # from current small models; revisit if live transcripts show
        # them.
        r"bitte|danke|merci|gracias|"
        r"obrigad[oa]|arigatou?|spasibo|"
        # Post-a24 P1-D4: third-wave single-word multilingual tokens.
        # ``xie\s*xie`` handles ``xie xie`` (space) and ``xiexie`` (no
        # space); ``xièxie`` listed separately because ``[eè]`` would
        # bloat the prior alternation. ``gozaimasu`` / ``domo`` are
        # listed for the post-strip remainders of ``arigatou
        # gozaimasu`` / ``domo arigato`` chains (the multi-word forms
        # above peel the whole pair in one match).
        r"mahalo|xi[eè]\s*xie|shukran|kiitos|tack|"
        r"gomawo|kamsahamnida|dhanyavad|"
        r"gozaimasu|domo)"
        r"\s*[,;.!?]*\s*$"
    )

    # Politeness tokens that are ALSO ordinary topics — ``Cheers`` the TV
    # series, ``tack`` the sailing manoeuvre / horse equipment, the
    # multilingual thank-yous that all have their own articles. The
    # alternation above is deliberately broad and its safety analysis only
    # covers EMBEDDED tokens (``attack``, ``Komodo``); this set is the
    # complementary guard for the case where the token IS the operand.
    _TOPIC_LIKE_POLITENESS = frozenset(
        {
            "ta",
            "tx",
            "ty",
            "tack",
            "cheers",
            "domo",
            "merci",
            "gracias",
            "danke",
            "bitte",
            "kiitos",
            "mahalo",
            "shukran",
            "spasibo",
            "obrigado",
            "obrigada",
            "arigato",
            "arigatou",
            "gomawo",
            "dhanyavad",
        }
    )

    # Scaffolding words of the intent phrases — verbs, question words,
    # determiners, connectors. A query built only from these carries no
    # operand for the intent to act on.
    #
    # It has to cover the scaffolding of EVERY phrase that reaches a
    # greedy-tail extractor, not just the ``tell me about`` family. It held
    # ``structure`` / ``section`` / ``toc`` but not ``outline`` / ``table`` /
    # ``contents``, so ``outline of tack`` left ``outline of`` behind, which
    # read as topic-bearing; the guard stayed silent, the politeness strip ate
    # the operand, and the extractor anchored on the last keyword and returned
    # ``entry_path='of'``. Adding a word here can only make the guard fire
    # MORE often, and firing means keeping the query the user typed.
    _NON_TOPIC_TOKENS = frozenset(
        {
            "a",
            "about",
            "an",
            "and",
            "are",
            "article",
            "browse",
            "called",
            "contents",
            "define",
            "describe",
            "display",
            "entry",
            "everything",
            "explain",
            "fetch",
            "find",
            "for",
            "from",
            "get",
            "give",
            "heading",
            "headings",
            "in",
            "info",
            "information",
            "is",
            "linking",
            "links",
            "list",
            "lists",
            "locate",
            "me",
            "named",
            "of",
            "on",
            "outline",
            "outlines",
            "page",
            "read",
            "related",
            "retrieve",
            "search",
            "section",
            "sections",
            "show",
            "structure",
            "summarize",
            "summary",
            "table",
            "tell",
            "the",
            "titled",
            "to",
            "toc",
            "walk",
            "was",
            "were",
            "what",
            "when",
            "where",
            "which",
            "who",
            "why",
        }
    )

    @classmethod
    def _carries_topic(cls, query: str) -> bool:
        """True when ``query`` still holds a token that could name an entry."""
        for token in query.lower().split():
            core = token.strip(".,;:!?'\"")
            if core and core not in cls._NON_TOPIC_TOKENS:
                return True
        return False

    @classmethod
    def _strip_trailing_politeness(
        cls, query: str, *, preserve_topic: bool = False
    ) -> str:
        """Peel trailing politeness tokens (``please`` / ``thanks`` /
        ``thank you`` / ``kindly``) off ``query``. Idempotent; loops
        until a pass produces no change so combinations like
        ``biology, thanks please`` strip in one call.

        With ``preserve_topic`` the loop refuses a pass that would consume
        the query's last topic-bearing token when the peeled token is also
        an ordinary word: ``tell me about tack`` must keep its topic, while
        ``biology tack`` still peels because ``biology`` survives. Callers
        that deliberately want the bare verb phrase (the empty-search-tail
        guards) leave it off.
        """
        for _ in range(4):
            before = query
            stripped = safe_regex_sub(
                cls._TRAILING_POLITENESS_RE,
                "",
                query,
                flags=re.IGNORECASE,
            ).strip()
            if stripped == before:
                break
            if preserve_topic and not cls._carries_topic(stripped):
                peeled = before.strip()[len(stripped) :].strip(" ,;.!?").lower()
                if peeled in cls._TOPIC_LIKE_POLITENESS:
                    break
            query = stripped
        return query

    # Post-a23 P1-D3: small models occasionally leak MCP tool parameters
    # INTO the natural-language query as text — ``tell me about
    # Photosynthesis limit=10`` or ``Berlin compact_budget=200`` instead
    # of passing them as the typed ``limit`` / ``compact_budget`` kwargs.
    # The title-promotion tokeniser then sees ``"10"`` / ``"200"`` as
    # clean ASCII digit tails, scores them against the title index, and
    # silently returns the ``10`` / ``200`` number article (or year
    # article) — a wildly unrelated body that masks the model's actual
    # topic.
    #
    # Live a23 sweep reproduced for ``limit=N`` (returns ``"N"``),
    # ``content_offset=N`` (returns ``"N"``), ``compact_budget=N``
    # (returns year ``"N"`` article), ``offset=N`` (returns ``"N"``)
    # on ``tell me about <topic> <param>=<value>``. Strip these BEFORE
    # the politeness loop / pattern matching so every downstream
    # extractor sees the cleaned query. Token list mostly mirrors the
    # public ``zim_query`` argument set; covers the param names live a23
    # sweep observed plus their obvious neighbours. NOTE the set is NOT
    # exactly the public argument set — ``namespace``, ``entry_path``,
    # ``partial_query`` and ``max_words`` are not ``zim_query`` kwargs at
    # all, so for those the query string is the only channel. See
    # ``_strip_param_leaks`` for the ``namespace`` operand carve-out.
    #
    # Word-boundary anchored at the front so we don't eat the leading
    # part of a multi-word topic (``offsetting`` / ``compactor`` /
    # ``cursor`` mid-topic are protected by the ``\s+`` requirement —
    # we only strip when the param keyword is preceded by whitespace,
    # and we require ``=`` so prose mentions of these words stay
    # intact). The value side matches ``\S+`` so quoted strings,
    # paths, numbers, and booleans all peel cleanly.
    # Post-a24 P1-D5: ``query`` was the only missing argument from the
    # public ``zim_query`` parameter set. Live a24 probe of
    # ``tell me about Photosynthesis query=biology`` returned the
    # ``Biology`` disambiguation page (the ``=biology`` suffix prevented
    # the title-promotion tokeniser from matching ``Photosynthesis``
    # cleanly; ``Biology`` won via fuzzy match on the trailing tokens).
    # Adding ``query`` closes the loop — every public ``zim_query``
    # parameter name now strips when a model leaks it as a query suffix.
    _PARAM_LEAK_RE = (
        # A SINGLE leading whitespace atom, deliberately not ``\s+``. A greedy
        # repeat whose tail is a failing alternation backtracks O(n^2) over a
        # long whitespace run, and ``safe_regex_sub`` cannot bound that cost:
        # CPython's ``re`` holds the GIL for the whole match, so the worker
        # thread timeout in ``run_with_timeout`` can't fire until it completes.
        # ``\s`` makes the leading atom fixed-width, so no backtracking is
        # possible. Behaviour is unchanged: ``_strip_param_leaks`` already
        # ``.strip()``s after every pass and loops until stable.
        r"\s"
        r"(?:limit|offset|content_offset|max_content_length|"
        r"max_words|compact_budget|compact|synthesize|cursor|"
        r"zim_file_path|entry_path|namespace|partial_query|"
        r"query)"
        r"\s*=\s*\S+"
    )

    @classmethod
    def _strip_param_leaks(cls, query: str) -> str:
        """Peel leaked ``param=value`` suffixes off ``query``. Idempotent;
        loops until stable so a query carrying multiple params
        (``Photosynthesis limit=10 compact_budget=200``) strips in one
        call.
        """
        # ``namespace`` is the OPERAND of browse / walk / "in namespace"
        # queries, not a redundant duplicate of a typed kwarg — ``zim_query``
        # has no ``namespace`` parameter, so the query string is the only
        # channel for it. Rewrite ``namespace=A`` -> ``namespace A`` so the
        # operand survives the strip below.
        #
        # The browse-family verb must INTRODUCE the operand (optionally
        # bridged by a determiner/connector), not merely appear somewhere in
        # the query: gating on "any browse verb anywhere" turned a genuine
        # leak in ordinary topical prose (``explore the history of Berlin
        # namespace=A``, ``walk me through X namespace=C``) into prose that
        # ``_PARAM_LEAK_RE`` can no longer see — the exact post-a23 P1-D3
        # pollution the strip exists to prevent. Queries with no such
        # introducer (``tell me about X namespace=C``) still strip, preserving
        # post-a23 P1-D3 / post-a24. The bridge is a bounded repeat over a
        # fixed alternation, so the pattern stays linear.
        query = safe_regex_sub(
            r"\b((?:browse|explore|walk|iterate|dump|enumerate|in|within)"
            r"(?:\s+(?:the|all|entries|of|in|within))*\s+namespace)"
            r"\s*=\s*['\"]?([A-Za-z])\b['\"]?",
            r"\1 \2",
            query,
            flags=re.IGNORECASE,
        )
        for _ in range(4):
            before = query
            query = safe_regex_sub(
                cls._PARAM_LEAK_RE,
                "",
                query,
                flags=re.IGNORECASE,
            ).strip()
            if query == before:
                break
        return query

    @classmethod
    def _apply_tier1_rewrites(
        cls,
        query: str,
        *,
        title_probe: Optional[Callable[[str], bool]],
        enabled: bool,
    ) -> Tuple[str, Optional[Dict[str, str]]]:
        """Sub-D-2: run all four Tier 1 rules in fixed order
        (1 → 2 → 3 → 4). Returns ``(rewritten_query, hint_or_None)``.

        Master kill switch: when ``enabled=False``, all four rules
        skip — the query is returned unchanged, hint is None.
        Operators set ``QueryRewriteConfig.enabled=False`` to bypass
        every rule including Rule 1's lowercasing."""
        if not enabled:
            return query, None
        query = cls._normalize_topic_case(query)
        query = cls._apply_misspelling_map(query, title_probe=title_probe)
        query = cls._detect_stopword_phrase(query, title_probe=title_probe)
        # Post-b1 P1-D3: Rule 4 now also consults the probe so it can
        # suppress decomposition of canonical multi-word titles.
        return cls._decompose_x_of_y(query, title_probe=title_probe)

    @staticmethod
    def _attach_decomposition_hint(
        params: Dict[str, Any],
        hint: Optional[Dict[str, str]],
    ) -> Dict[str, Any]:
        """Sub-D-2: attach the rule-4 decomposition hint to a params
        dict in-place when present. No-op when hint is None. Returns
        the same params dict for chaining."""
        if hint is not None:
            params["decomposition_hint"] = hint
        return params

    @classmethod
    def _restore_nonascii_case(
        cls,
        params: Dict[str, Any],
        original_query: str,
    ) -> Dict[str, Any]:
        """Re-case non-ASCII string params from the pre-Rule-1 query.

        Tier 1 Rule 1 lowercases the query before param extraction.
        ASCII values recover downstream (Xapian title probes plus the
        ``_find_entry_fast_path`` case-variant ladder), but non-Latin
        scripts have no such ladder: on an archive without a title
        index, ``індыйская кухня`` never round-trips back to the
        stored title ``Індыйская кухня`` and the lookup degrades to
        "Article not found" even though ``zim_search`` resolves the
        same string. Restore the caller's typed casing by
        case-insensitive substring lookup in the pre-rewrite query —
        the recovery ``SimpleToolsHandler._recase_from_original``
        already applies to guidance text. Values reshaped by rules
        2-4 miss the lookup and pass through unchanged; ASCII values
        keep Rule 1's lowercase contract. Mutates ``params`` in place
        and returns it for chaining."""
        lowered = original_query.lower()
        # Rare code points lowercase to a different length (``İ`` ->
        # ``i̇``), which shifts every index past them; skip rather than
        # slice the original at a misaligned offset.
        if not original_query or len(lowered) != len(original_query):
            return params

        def _one(value: Any) -> Any:
            # A ZIM namespace prefix (a single letter followed by ``/``) is
            # never a natural-language token, so Rule 1's "ASCII values
            # recover downstream" contract does not hold for it: libzim's
            # path lookup is case-sensitive and ``A/Climate_change`` ->
            # ``a/climate_change`` 404s — on paths this tool emits itself
            # (browse listings, search hits, ``links in X``, and the
            # not-found recovery hints all print ``A/...``). Re-case those
            # too. The prefix is matched with the same strict single-letter
            # shape the namespace extractors use, so a slash-bearing natural
            # topic (``TCP/IP``, ``AC/DC``) keeps Rule 1's lowercasing.
            if (
                not isinstance(value, str)
                or not value
                or (
                    value.isascii()
                    and not _NAMESPACE_PREFIXED_RE.match(value)
                    and not _DOMAIN_PATH_RE.match(value)
                )
            ):
                return value
            idx = lowered.find(value)
            if idx < 0:
                return value
            restored = original_query[idx : idx + len(value)]
            return restored if restored.lower() == value else value

        for key, value in params.items():
            # ``get_zim_entries`` stores its paths as a LIST
            # (``params["entries"] == ["a/foo", "a/bar"]``), so a scalar-only
            # loop skipped the highest-volume consumer of self-emitted
            # ``A/...`` paths entirely and batch fetches kept 404ing. Map the
            # per-value logic over list elements the same way the sibling
            # politeness strip in ``simple_tools`` does.
            if isinstance(value, list):
                new_list = [_one(item) for item in value]
                if new_list != value:
                    params[key] = new_list
            else:
                restored = _one(value)
                if restored != value:
                    params[key] = restored
        return params

    @classmethod
    def parse_intent(
        cls,
        query: str,
        *,
        title_probe: Optional[Callable[[str], bool]] = None,
        query_rewrite_enabled: bool = True,
    ) -> Tuple[str, Dict[str, Any], float]:
        """Parse a natural language query to determine intent.

        This method collects ALL matching patterns and uses a weighted scoring
        system to select the best match. This prevents earlier patterns from
        incorrectly shadowing more specific patterns that match later.

        Args:
            query: Natural language query string
            title_probe: Optional callback for rules 2 and 3 to suppress
                false-positive rewrites. When ``None``, those rules run in
                degraded mode.
            query_rewrite_enabled: Master kill switch. When ``False``, all
                four Sub-D-2 Tier 1 rules are skipped entirely — the query
                reaches the existing intent-regex chain unmodified. Mirrors
                ``QueryRewriteConfig.enabled`` so operators who set
                ``OPENZIM_MCP_QUERY_REWRITE__ENABLED=false`` get a true
                opt-out rather than only bypassing telemetry.

        Returns:
            Tuple of (intent_type, extracted_params, confidence_score)

        Sub-D-2: a ``title_probe`` callback may be passed. When
        provided, rules 2 and 3 consult it to suppress false-positive
        rewrites (real proper nouns, canonical titles). When ``None``,
        rules 2 and 3 run in degraded mode (substitute without
        probing, strip without probing).
        """
        # M10: peel param-leak and politeness suffixes BEFORE the Tier 1
        # rewrites. Rule 4 (_decompose_x_of_y) is the last Tier 1 rule and
        # moves the entity capture mid-string (``population of berlin please``
        # → ``berlin please population``), where the end-anchored strips can no
        # longer remove the junk and the decomposition_hint entity already
        # carries it. Stripping first (both strips are IGNORECASE, so running
        # them on the original-case query is safe) feeds Rule 4 a clean topic.
        #
        # Param-leak strip runs before politeness (post-a23 P1-D3): the
        # politeness regex then sees the clean topic without ``limit=10`` /
        # ``offset=5`` confusing its leading word-boundary anchor.
        #
        # Collapse whitespace runs BEFORE either strip. ``_PARAM_LEAK_RE`` and
        # ``_TRAILING_POLITENESS_RE`` both lead with a repeat whose tail is a
        # failing alternation, which backtracks O(n^2) over a long whitespace
        # run (8 000 trailing spaces measured at 2.4s wall). This sub is linear
        # — no failing tail — and caps every run at one character.
        # ``safe_regex_sub`` cannot bound the cost itself: CPython's ``re``
        # holds the GIL, so the worker-thread timeout in ``run_with_timeout``
        # can't fire until the match completes, making the nominal 1s cap
        # advisory only.
        query = re.sub(r"\s+", " ", query).strip()
        try:
            query = cls._strip_param_leaks(query)
            query = cls._strip_trailing_politeness(query, preserve_topic=True)
        except RegexTimeoutError:
            # Degrade like every other regex site in this function rather than
            # converting a parse into a top-level error envelope: the query is
            # simply left un-stripped and classification continues.
            logger.warning("Regex timeout during query pre-strip; using raw query")
        # Kept for _restore_nonascii_case: both strips above preserve
        # casing, so this is the last form still carrying what the
        # caller typed before Rule 1 lowercases everything.
        pre_rewrite = query

        # Sub-D-2 Tier 1 rewrites. Master kill switch honored inside
        # _apply_tier1_rewrites.
        query, decomposition_hint = cls._apply_tier1_rewrites(
            query,
            title_probe=title_probe,
            enabled=query_rewrite_enabled,
        )
        query_lower = query.lower()

        # Collect all matching patterns
        matches: List[Tuple[str, Dict[str, Any], float, int]] = []

        for pattern, intent, base_confidence, specificity in cls.INTENT_PATTERNS:
            try:
                match = safe_regex_search(pattern, query_lower, re.IGNORECASE)
                if match:
                    params = cls._extract_params(query, intent)
                    # Boost confidence only when params extract AND base is
                    # below 0.8 — the boost is a tie-breaker for ambiguous
                    # low-priority matches, not a way to lift them above
                    # high-priority param-less intents (M17). Cap at 0.85
                    # to keep low-priority + boost strictly below high-base
                    # intents (>= 0.9).
                    confidence = base_confidence
                    if (
                        base_confidence < 0.8
                        and params
                        and any(v for v in params.values() if v)
                    ):
                        confidence = min(base_confidence + 0.05, 0.85)
                    matches.append((intent, params, confidence, specificity))
            except RegexTimeoutError:
                logger.warning(f"Regex timeout for pattern: {pattern[:30]}...")
                continue

        if not matches:
            # Default fallback. A query that didn't match any pattern falls
            # into one of two buckets:
            #
            # * A bare topic name (proper-noun phrase with no verb,
            #   e.g. ``"Martin Luther King Jr."`` or ``"Photosynthesis"``).
            #   The caller almost certainly wants information *about* that
            #   topic — route to ``tell_me_about`` so the handler fetches
            #   the article body when the top hit is a strong title match.
            #
            # * Anything else — keep the legacy bare-search fallback.
            if cls._looks_like_bare_topic(query):
                params = cls._attach_decomposition_hint(
                    {"topic": _normalize_url_topic(query.strip())},
                    decomposition_hint,
                )
                cls._restore_nonascii_case(params, pre_rewrite)
                return "tell_me_about", params, 0.7
            params = cls._attach_decomposition_hint(
                {"query": query}, decomposition_hint
            )
            cls._restore_nonascii_case(params, pre_rewrite)
            return "search", params, 0.5

        # Select best match using weighted scoring
        # Primary: confidence, Secondary: specificity
        best_match = cls._select_best_match(matches)
        intent_type, params, confidence = (
            best_match[0],
            best_match[1],
            best_match[2],
        )
        cls._attach_decomposition_hint(params, decomposition_hint)
        cls._restore_nonascii_case(params, pre_rewrite)
        return intent_type, params, confidence

    # Words that signal an explicit verb-shaped intent. If a query contains
    # one of these (case-insensitive, whole-word), it isn't "bare-topic" — it
    # has structure the intent classifier should have caught, and a
    # bare-topic fallback is inappropriate. Conservative list: only words
    # the intent parser specifically looks for as command verbs /
    # interrogatives, not generic English words like "the" or "of" that
    # appear in titles ("The Lord of the Rings").
    _BARE_TOPIC_VERB_TOKENS = frozenset(
        {
            "what",
            "who",
            "when",
            "where",
            "why",
            "how",
            "which",
            "list",
            "show",
            "get",
            "find",
            "fetch",
            "search",
            "browse",
            "tell",
            "describe",
            "explain",
            "give",
            "info",
            "about",
            "metadata",
            "namespace",
            "namespaces",
            "main",
            "page",
            "structure",
            "outline",
            "links",
            "related",
            "suggestions",
            "autocomplete",
            "walk",
            "all",
        }
    )

    # Common English filler / conversational tokens. A query whose tokens
    # are *only* drawn from this set looks like meta-instruction or
    # conversational filler ("do both", "try again", "ok", "test this")
    # rather than a topic ask, even though none of the tokens are
    # explicit command verbs in ``_BARE_TOPIC_VERB_TOKENS``. Used by
    # ``_looks_like_bare_topic`` to require at least one *content-shaped*
    # token before treating a query as a bare topic — otherwise small
    # LLMs that copy the user's literal message verbatim will trip the
    # bare-topic-fallback into ``tell_me_about``, where the strong-title
    # match path can dump entire article bodies for unrelated common-word
    # collisions (Aaliyah's "Try Again" for the literal user string
    # ``"try again"`` is the canonical motivating example).
    _COMMON_FILLER_TOKENS = frozenset(
        {
            # Affirmation / negation / acknowledgement
            "yes",
            "yeah",
            "yep",
            "no",
            "nope",
            "nah",
            "ok",
            "okay",
            "sure",
            "alright",
            "fine",
            # Greetings / politeness
            "hi",
            "hello",
            "hey",
            "thanks",
            "thank",
            "please",
            # Continuation cues
            "go",
            "continue",
            "next",
            "more",
            "again",
            "also",
            "still",
            "keep",
            "going",
            # D46: the two-word pagination follow-ups small models emit
            # after a paged response (``next page`` / ``more results``).
            # Bare ``next`` / ``more`` were already filler, but the noun
            # half was not, so the all-tokens-filler check failed and the
            # pair ran a stop-word-collision full-text search instead of
            # returning the guidance playbook.
            "page",
            "results",
            # Determiners / particles
            "the",
            "a",
            "an",
            "this",
            "that",
            "these",
            "those",
            "here",
            "there",
            "now",
            # Pronouns
            "i",
            "me",
            "my",
            "mine",
            "you",
            "your",
            "yours",
            "we",
            "us",
            "our",
            "ours",
            "they",
            "them",
            "their",
            "it",
            "its",
            # Coordinators
            "and",
            "or",
            "but",
            "if",
            "then",
            "else",
            # Common prepositions / particles (added for Sub-D-2 Rule 1
            # compatibility: lowercasing removes the capitalization signal
            # so short non-filler tokens now need explicit coverage to
            # prevent e.g. ``"go on"`` from being a bare topic because
            # ``"on"`` is 2 chars and not in the filler set).
            "on",
            "at",
            "in",
            "by",
            "up",
            "to",
            "as",
            "of",
            "so",
            "not",
            "yet",
            "for",
            "nor",
            "per",
            "via",
            # Common short verbs (non-intent)
            "do",
            "does",
            "did",
            "doing",
            "done",
            "try",
            "tries",
            "tried",
            "trying",
            "use",
            "uses",
            "used",
            "using",
            "have",
            "has",
            "had",
            "is",
            "are",
            "was",
            "were",
            "am",
            "be",
            "been",
            "being",
            "can",
            "could",
            "would",
            "should",
            "may",
            "might",
            "must",
            "will",
            "shall",
            # Meta-tool vocabulary (matches the LLM-passthrough patterns
            # observed in the v1.2.0 beta-test transcripts)
            "test",
            "tests",
            "tested",
            "testing",
            "tester",
            "demo",
            "demos",
            "explore",
            "exploring",
            "beta",
            "alpha",
            "regression",
            "stress",
            "smoke",
            "tool",
            "tools",
            # Vague nouns / quantifiers
            "thing",
            "things",
            "stuff",
            "anything",
            "everything",
            "something",
            "nothing",
            "any",
            "each",
            "every",
            "some",
            "none",
            "both",
            # Generic responses
            "right",
            "wrong",
            "true",
            "false",
            # User asked for help on the tool, not for a "Help" article
            "help",
        }
    )

    @classmethod
    def _looks_like_bare_topic(cls, query: str) -> bool:
        """Return True if ``query`` looks like a bare topic name.

        Two layers of evidence:

        1. Negative — the query has no command-verb / interrogative
           tokens from ``_BARE_TOPIC_VERB_TOKENS`` (otherwise it has
           structure the intent classifier should have caught).

        2. Positive — at least one token is *distinctive*: not common
           filler AND either capitalized in the (pre-Rule-1) query
           (proper-noun signal) OR at least 2 characters long
           (content-word signal). The 2-char floor exists because
           Sub-D-2 Rule 1 unconditionally lowercases the query before
           this gate fires, so short acronyms like ``dna`` / ``pi`` /
           ``ai`` lose their capitalization signal and must qualify on
           length alone. Single-char inputs are still excluded.

        The positive layer is what stops conversational fragments like
        ``"do both"`` / ``"try again"`` / ``"test"`` / ``"help"`` from
        qualifying as bare topics under the negative-only rule. Without
        it, the strong-title-match branch in
        ``SimpleToolsHandler._handle_tell_me_about`` could dump full
        article bodies for unrelated common-word matches (the
        ``"try again"`` -> 105k-char Aaliyah article body trap).

        Examples:
          * ``"martin luther king jr."`` qualifies (multiple non-filler
            tokens, all ≥2 chars).
          * ``"biology"`` qualifies (7 chars, not filler).
          * ``"dna"`` qualifies (3 chars, not filler — post-Rule-1).
          * ``"pi"`` qualifies (2 chars, not filler — minimum length).
          * ``"量子力学"`` qualifies (non-Latin script — Chinese, Arabic,
            Russian, etc. — is treated as inherently distinctive since
            those scripts don't have casing or short ASCII filler).
          * ``"do both"`` does NOT (every token is common filler).
          * ``"try again"`` does NOT (every token is common filler).
          * ``"test"`` / ``"help"`` do NOT (single filler token).
          * ``"tell me about MLK"`` does NOT (verb ``tell``).
        """
        if not query or len(query) > 80:
            return False
        # Non-Latin scripts (CJK, Cyrillic, Arabic, Devanagari, Hebrew,
        # …) have no casing and no overlap with the ASCII filler-token
        # set, so any unicode "letter" character is a strong distinctive
        # signal on its own. Without this, the ASCII-only tokenizer below
        # treats ``"量子力学"`` as zero tokens and the gate falsely
        # rejects every non-Latin topic ask. ``str.isalpha()`` returns
        # True for letters in any script.
        if any(c.isalpha() and ord(c) > 127 for c in query):
            verb_match = re.search(r"[A-Za-z]+", query)
            if verb_match:
                ascii_tokens = [t.lower() for t in re.findall(r"[A-Za-z]+", query)]
                if any(t in cls._BARE_TOPIC_VERB_TOKENS for t in ascii_tokens):
                    return False
            return True
        # Tokenize on alphanumerics so punctuation in titles ("Jr.",
        # "U.S.A.") doesn't fragment names.
        raw_tokens = re.findall(r"[A-Za-z0-9]+", query)
        if not raw_tokens:
            return False
        lower_tokens = [t.lower() for t in raw_tokens]
        if any(t in cls._BARE_TOPIC_VERB_TOKENS for t in lower_tokens):
            return False
        # Positive check: any single token that is non-filler AND either
        # capitalized in the original query, content-word-length (≥5), OR
        # at least 2 characters is enough evidence that this is a topic
        # ask. The 2-char floor exists because Sub-D-2 Rule 1 lowercases
        # the query before this check fires, removing the capitalization
        # signal — short acronyms like ``dna`` / ``pi`` / ``ai`` / ``rna``
        # are still valid topics that must not fall through to search.
        # Single-char inputs are excluded (len(t) >= 2) to stop bare
        # single letters from qualifying.
        return any(
            t.lower() not in cls._COMMON_FILLER_TOKENS
            and (t[0].isupper() or len(t) >= 2)
            for t in raw_tokens
        )

    @classmethod
    def _select_best_match(
        cls, matches: List[Tuple[str, Dict[str, Any], float, int]]
    ) -> Tuple[str, Dict[str, Any], float]:
        """Select the best match from multiple matching patterns.

        Uses a weighted scoring algorithm:
        - Primary factor: confidence score (0-1)
        - Secondary factor: specificity weight (normalized to 0-1)
        - Combined score = confidence * 0.7 + (specificity / 10) * 0.3

        Args:
            matches: List of (intent, params, confidence, specificity) tuples

        Returns:
            Best match as (intent, params, confidence) tuple
        """
        if len(matches) == 1:
            intent, params, confidence, _ = matches[0]
            return intent, params, confidence

        # Calculate combined scores
        scored_matches = []
        for intent, params, confidence, specificity in matches:
            # Normalize specificity to 0-1 range (max specificity is 10)
            normalized_specificity = specificity / 10.0
            # Weighted combination: 70% confidence, 30% specificity
            combined_score = (confidence * 0.7) + (normalized_specificity * 0.3)
            scored_matches.append((intent, params, confidence, combined_score))

        # Sort by combined score (descending)
        scored_matches.sort(key=lambda x: x[3], reverse=True)

        # Log multi-match resolution for debugging
        if len(matches) > 1:
            logger.debug(
                f"Multi-match resolution: {len(matches)} patterns matched, "
                f"selected '{scored_matches[0][0]}' "
                f"with score {scored_matches[0][3]:.3f}"
            )

        best = scored_matches[0]
        return best[0], best[1], best[2]

    @classmethod
    def _extract_params(cls, query: str, intent: str) -> Dict[str, Any]:
        """Extract parameters from query based on intent.

        Uses cross-platform timeout protection to prevent ReDoS attacks.

        Args:
            query: Original query string
            intent: Detected intent type

        Returns:
            Dictionary of extracted parameters
        """
        params: Dict[str, Any] = {}
        extractor = _PARAM_EXTRACTORS.get(intent)
        if extractor is None:
            return params

        try:
            extractor(query, params)
        except RegexTimeoutError:
            logger.warning(
                f"Regex timeout during param extraction for intent {intent}: "
                f"{query[:50]}..."
            )
            # Caller handles missing params gracefully.
            return {}

        return params

    # ----- sub-D-2 Tier 1 query rewriting rules -----

    @staticmethod
    def _split_misspelling_affixes(token: str) -> Tuple[str, str, str]:
        """Post-b1 P1-D5 / P1-D6: split ``token`` into
        ``(leading_affix, core, trailing_affix)`` where affix
        characters are non-word (``\\W`` equivalent).

        Linear-time, no regex backtracking — replaces the original
        ``^(\\W*)(.*?)(\\W*)$`` regex that SonarCloud's S5852
        ReDoS detector flagged (lazy ``.*?`` between two greedy
        ``\\W*`` quantifiers tripped the static analyzer despite
        the actual runtime being bounded-linear on token-length
        inputs). Same precedent-rewrite pattern the post-a22 sweep
        applied to the implicit-concat regex in
        ``_chained_intent_guidance``.

        Word chars: ``\\w`` equivalent — alphanumerics +
        underscore. Underscore handled explicitly because
        ``str.isalnum`` excludes it (whereas ``\\w`` includes it).
        Unicode letters / digits flow through unchanged
        (``str.isalnum`` is Unicode-aware), so non-Latin tokens
        like ``München.`` split correctly to ``("", "München",
        ".")`` — matching the original regex semantics.

        Apostrophes are non-word, so leading/trailing single
        quotes get stripped (``'recieve'`` → ``("'", "recieve",
        "'")``) while interior possessive ``'s`` stays attached
        to the core (``photosythesis's`` → ``("", "photosythesis's",
        "")``) — the caller's subsequent possessive-strip step
        peels ``'s`` off and reattaches on map hit.
        """
        n = len(token)
        i = 0
        while i < n and not (token[i].isalnum() or token[i] == "_"):
            i += 1
        j = n
        while j > i and not (token[j - 1].isalnum() or token[j - 1] == "_"):
            j -= 1
        return token[:i], token[i:j], token[j:]

    @classmethod
    def _normalize_topic_case(cls, query: str) -> str:
        """Sub-D-2 rule 1: lowercase the query.

        Replaces scattered `.lower()` calls in the relevance pipeline
        with a named pass. Idempotent. No telemetry — fires on
        essentially every query."""
        return query.lower()

    # Class-level overridable paths (None = use bundled defaults).
    # Tests can monkeypatch these to swap in fixture files;
    # ``SimpleToolsHandler`` binds them from ``QueryRewriteConfig``.
    _misspellings_path: Optional["Path"] = None
    _exclusions_path: Optional["Path"] = None

    @classmethod
    def bind_data_paths(
        cls, misspellings_path: object, exclusions_path: object
    ) -> None:
        """Point rule 2 at operator-supplied data files.

        Rule 2 is a classmethod reading class-level state, so the binding is
        process-wide: a process hosting two configs gets the last one. Both
        paths are always written, ``None`` included, so a caller without
        overrides restores the bundled defaults instead of inheriting the
        previous caller's files. Values that aren't filesystem paths are
        treated as "no override" so a malformed config degrades to the
        bundled data rather than raising inside the loader.
        """
        cls._misspellings_path = cls._as_data_path(misspellings_path)
        cls._exclusions_path = cls._as_data_path(exclusions_path)

    @staticmethod
    def _as_data_path(value: object) -> Optional["Path"]:
        return Path(value) if isinstance(value, (str, Path)) else None

    @classmethod
    def _apply_misspelling_map(  # noqa: C901
        cls,
        query: str,
        *,
        title_probe: Optional[Callable[[str], bool]],
    ) -> str:
        """Sub-D-2 rule 2: substitute known misspellings token-by-token.

        Probe-gated when ``title_probe`` is provided: if the original
        token canonically resolves to a real entity, the substitution
        is suppressed. Degrades to ``substitute-without-probe`` when
        ``title_probe`` is None.

        Idempotent: a corrected word is never itself a key in the map.
        Telemetry (``query_rewrite.misspelling``) is emitted by the
        caller (simple_tools.py wiring) based on the before/after diff.

        The data files come from the class attributes ``SimpleToolsHandler``
        binds from ``QueryRewriteConfig`` — see :meth:`bind_data_paths`."""
        mapping = load_misspellings(cls._misspellings_path)
        exclusions = load_exclusions(cls._exclusions_path)
        if not mapping:
            return query

        # Split on whitespace; preserve runs of whitespace between tokens.
        # re.split with a captured group keeps the separators in the list.
        parts = re.split(r"(\s+)", query)
        out: list[str] = []
        for part in parts:
            if not part or part.isspace():
                out.append(part)
                continue
            lower = part.lower()
            replacement = mapping.get(lower)
            # Post-b1 P1-D5 / P1-D6: when the raw token misses the map,
            # retry with a stripped form. Two real defect classes:
            #   * trailing/leading punctuation (``bilogy.``,
            #     ``"photosythesis"``) — the period/quote attached to
            #     the misspelling defeats the lookup.
            #   * possessive ``'s`` (``photosythesis's reproduction``)
            #     — the suffix changes the lookup key.
            # The retry strips a leading/trailing non-word boundary
            # AND a possessive suffix, reattaching them to the
            # substitution on hit. ``re.match`` always returns a match
            # here (the pattern can match the empty string).
            lookup_core = lower
            prefix_chars = ""
            suffix_chars = ""
            possessive = ""
            if replacement is None:
                prefix_chars, lookup_core, suffix_chars = (
                    cls._split_misspelling_affixes(lower)
                )
                if lookup_core.endswith("'s"):
                    possessive = "'s"
                    lookup_core = lookup_core[:-2]
                if lookup_core and lookup_core != lower:
                    replacement = mapping.get(lookup_core)
                    if replacement is not None:
                        replacement = (
                            prefix_chars + replacement + possessive + suffix_chars
                        )
            if replacement is None:
                out.append(part)
                continue
            # Honor exclusions against the same key that matched (the
            # stripped core when the retry hit, else the original
            # lowercased token).
            exclusion_key = lookup_core if lookup_core != lower else lower
            if exclusion_key in exclusions or lower in exclusions:
                out.append(part)
                continue
            if title_probe is not None and title_probe(part):
                out.append(part)
                continue
            out.append(replacement)
        return "".join(out)

    _LEADING_ARTICLE_RE = re.compile(r"^(the|a|an|of)\s+", re.IGNORECASE)

    # Guard: patterns where a leading article is PART of the command
    # signal, not a standalone article to strip. The primary case is
    # ``the X section of Y`` (``get_section`` intent) where stripping
    # ``the`` leaves ``X section of Y`` which matches the generic
    # ``structure`` pattern instead. Both surface-forms use
    # ``\bsection\b`` but the second (``the X section of Y``) requires
    # ``the`` to be present for the intent regex to fire.
    _RULE3_SECTION_COMMAND_RE = re.compile(
        r"^the\s+\S+(?:\s+\S+){0,8}\s+section\s+(?:of|in|from)\s+\S+",
        re.IGNORECASE,
    )

    @classmethod
    def _detect_stopword_phrase(
        cls,
        query: str,
        *,
        title_probe: Optional[Callable[[str], bool]],
    ) -> str:
        """Sub-D-2 rule 3: strip a leading article unless the full
        query (with article) is a canonical title.

        Probe-gated: the probe is called ONCE per query on the full
        query string. If the probe says yes → keep the article (e.g.
        ``The Beatles``). If no, or if ``title_probe`` is None → strip.

        Idempotent: stripping a leading article doesn't introduce a
        new one.

        Guard: ``the X section of Y`` / ``the X section in Y`` is a
        ``get_section`` command where ``the`` is syntactically load-
        bearing. Stripping it would break the intent regex. Skip the
        strip when the query matches this shape."""
        match = cls._LEADING_ARTICLE_RE.match(query)
        if not match:
            return query
        # Guard: ``the X section of/in/from Y`` is a get_section command.
        if cls._RULE3_SECTION_COMMAND_RE.match(query):
            return query
        if title_probe is not None and title_probe(query):
            # Real canonical title — keep the article.
            return query
        return query[match.end() :]

    # Rule 4 regex shapes. Both require a single-word attribute so we
    # don't mis-decompose multi-word phrases — multi-hop / multi-word
    # attribute decomposition is a deferred sub-D-3 concern.
    _X_OF_Y_RE = re.compile(
        # Entity capture is bounded at 200 chars to eliminate any
        # polynomial-backtracking risk on adversarial inputs.
        # Legitimate entity names fit comfortably; anything longer is
        # not a real query. Single-char-class `.` keeps the analyzer
        # happy about quantifier nesting.
        r"^(?P<attr>\w+)\s+of\s+(?P<entity>.{1,200})$",
        re.IGNORECASE,
    )
    _POSSESSIVE_RE = re.compile(
        r"^(?P<entity>\w+)'s\s+(?P<attr>\w+)$",
        re.IGNORECASE,
    )

    # Rule 4 guard: attribute words that are recognised intent keywords.
    # When the attr group matches one of these, the query is a structured
    # command (e.g. ``structure of Biology``, ``sections of Protein``)
    # rather than a factual decomposition (``population of Berlin``).
    # Decomposing these would rewrite them into bare noun phrases that
    # lose the command signal and misroute to ``search`` / ``tell_me_about``.
    _DECOMPOSE_SKIP_ATTRS: frozenset[str] = frozenset(
        {
            # Structure/TOC intent keywords (INTENT_PATTERNS, specificity 8–10)
            "structure",
            "outline",
            "sections",
            "section",
            "headings",
            "heading",
            "toc",
            "contents",
            # ``table`` as in ``table of contents`` — the multi-word phrase
            # ``table of contents for X`` starts with ``table``, so Rule 4
            # must not consume it before the toc intent regex can see it.
            "table",
            # Metadata intent keywords
            "metadata",
            "info",
            "details",
            "detail",
            # Summary intent keywords
            "summary",
            "overview",
            "brief",
            # Links intent keywords
            "links",
            "link",
            "references",
            "related",
            # Browse intent keywords
            "list",
            "browse",
            # Binary intent keywords
            "binary",
            # Search / find command verbs
            "find",
            "search",
            "get",
        }
    )

    @classmethod
    def _decompose_x_of_y(
        cls,
        query: str,
        *,
        title_probe: Optional[Callable[[str], bool]] = None,
    ) -> tuple[str, Optional[dict[str, str]]]:
        """Sub-D-2 rule 4: decompose `<attr> of <entity>` and
        `<entity>'s <attr>` shapes.

        Returns ``(rewritten_query, hint_or_None)``:
        - ``rewritten_query`` collapses to ``<entity> <attr>`` when
          decomposition matches; otherwise returns input unchanged.
        - ``hint_or_None`` is ``{"entity": ..., "attribute": ...}`` on
          match, else None. The hint rides inside ``params`` in the
          parse_intent return value; ``_handle_tell_me_about`` reads it
          to skip its own extraction.

        Idempotent: a rewritten ``berlin population`` no longer matches
        either regex.

        Guard 1: when the attr word is a recognised intent keyword (e.g.
        ``structure``, ``sections``, ``metadata``), the query is a
        structured command and must NOT be decomposed — decomposing
        would destroy the command signal and misroute the query.

        Guard 2 (post-b1 P1-D3): probe-gated — when ``title_probe`` is
        provided and the FULL query canonically resolves to a real
        article (``lord of the rings``, ``the art of war``, ``history
        of rome``, ``birth of venus``), decomposition is suppressed.
        Without this guard, every ``X of Y`` canonical title was
        torn apart into ``Y X`` and looked up as ``Y``, returning
        wrong articles (``Lord_of_the_Rings`` → ``The_Rings`` Iranian
        horror film; ``The_Art_of_War`` → ``War``; ``History_of_Rome``
        → ``Rome``). Degrades to substitute-without-probe when
        ``title_probe`` is None (legacy behaviour)."""
        m = cls._X_OF_Y_RE.match(query)
        if not m:
            m = cls._POSSESSIVE_RE.match(query)
        if not m:
            return query, None
        entity = m.group("entity").strip()
        attr = m.group("attr").strip()
        # Guard 1: do not decompose known command-keyword attributes.
        if attr.lower() in cls._DECOMPOSE_SKIP_ATTRS:
            return query, None
        # Guard 2 (post-b1 P1-D3): suppress decomposition when the
        # full query is itself a canonical title.
        if title_probe is not None and title_probe(query):
            return query, None
        return f"{entity} {attr}", {"entity": entity, "attribute": attr}
