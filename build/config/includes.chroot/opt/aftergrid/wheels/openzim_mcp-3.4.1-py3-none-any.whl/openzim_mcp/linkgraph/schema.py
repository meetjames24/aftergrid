"""SQLite schema for the inbound link-graph sidecar.

Layout is integer-keyed: ``nodes`` interns each entry path to a small id and
carries the precomputed ``inbound_degree`` used to rank linkers by importance;
``edges`` stores ``(target_id, source_id, anchor_text)`` rows indexed by target
for the inbound lookup (``anchor_text`` is the visible link text of each edge).
``meta`` holds the archive UUID + schema version the reader fingerprints against
(strict staleness check).
"""

from __future__ import annotations

import sqlite3

# Bump on any incompatible layout change; the reader rejects mismatches and
# forces an operator rebuild.
#
# The CONTENTS count as much as the layout. v3: edge targets are now stored in
# the spelling the archive can actually serve — ``A/El_Niño`` rather than the
# raw percent-encoded href ``A/El_Ni%C3%B1o`` the builder used to record. The
# table shapes are unchanged, so a v2 file loads fine and looks healthy, but
# ``query_inbound`` matches ``nodes.path`` as an exact string and every caller
# now supplies the decoded form. A v2 sidecar therefore answers every
# non-ASCII lookup with an empty page (36 inbound links silently becoming zero
# for one article of the shipped test corpus) instead of being reported stale.
SCHEMA_VERSION = 3

_DDL = """
CREATE TABLE meta  (key TEXT PRIMARY KEY, value TEXT) STRICT;
CREATE TABLE nodes (id INTEGER PRIMARY KEY, path TEXT NOT NULL UNIQUE,
                    inbound_degree INTEGER NOT NULL DEFAULT 0) STRICT;
-- No UNIQUE(target_id, source_id): the builder already guarantees each
-- (source, target) pair is unique (it dedups targets within a source and
-- visits each source entry exactly once), so a uniqueness index would only
-- slow the bulk insert without changing the data. inbound_degree is a plain
-- COUNT over these rows, so the by-construction uniqueness keeps it accurate.
CREATE TABLE edges (target_id INTEGER NOT NULL, source_id INTEGER NOT NULL,
                    anchor_text TEXT NOT NULL DEFAULT '') STRICT;
CREATE INDEX edges_by_target ON edges(target_id);
"""


def create_schema(conn: sqlite3.Connection) -> None:
    """Create the tables + index on a fresh connection.

    Call once before opening any transaction: ``executescript`` issues an
    implicit ``COMMIT`` first, and the DDL has no ``IF NOT EXISTS`` so a second
    call on the same connection raises ``sqlite3.OperationalError``.
    """
    conn.executescript(_DDL)


def apply_build_pragmas(conn: sqlite3.Connection) -> None:
    """Speed pragmas for the one-shot build (safe: a crash discards the temp file)."""
    conn.execute("PRAGMA journal_mode=OFF")
    conn.execute("PRAGMA synchronous=OFF")
