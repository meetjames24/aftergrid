"""zim_metadata — archive M-namespace fields + namespace inventory.

Collapses ``get_zim_metadata`` + ``list_namespaces`` (2 → 1; the
legacy ``get_main_page`` moves to ``zim_get(main_page=True)``).
Delegates to the D2 combined wrapper
``AsyncZimOperations.get_archive_metadata_data``.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from ._common import (
    READ_ONLY_ANNOTATIONS,
    blank_archive_path,
    enforce_rate_limit,
    load_description,
    tool_error_response,
)

if TYPE_CHECKING:
    from ..server import OpenZimMcpServer

_DESCRIPTION = load_description("zim_metadata")


def register(server: "OpenZimMcpServer") -> None:
    """Register the `zim_metadata` tool with the MCP server."""
    from ..async_operations import AsyncZimOperations

    ops = AsyncZimOperations(server.zim_operations)

    @server.mcp.tool(description=_DESCRIPTION, annotations=READ_ONLY_ANNOTATIONS)
    async def zim_metadata(zim_file_path: str) -> Any:
        try:
            # Internal operation name, not the wire name — see
            # ``RATE_LIMIT_COSTS`` in ``defaults.py``.
            rl = enforce_rate_limit(server, "get_metadata")
            if rl is not None:
                return rl
            blank = blank_archive_path(zim_file_path)
            if blank is not None:
                return blank
            return await ops.get_archive_metadata_data(zim_file_path)
        except Exception as e:  # noqa: BLE001 — broad catch matches b13 envelope
            return tool_error_response(
                server,
                operation="zim_metadata",
                error=e,
                context=f"Path: {zim_file_path}",
            )
