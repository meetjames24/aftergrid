"""Custom exceptions for OpenZIM MCP server.

Each exception has an error_code for programmatic handling and categorization.
Error codes follow the pattern: OPENZIM_<CATEGORY>_<SPECIFIC>
"""

from typing import Optional


class OpenZimMcpError(Exception):
    """Base exception for all OpenZIM MCP-related errors.

    Attributes:
        error_code: Unique error code for programmatic handling
        message: Human-readable error message
        details: Optional additional details about the error
    """

    error_code: str = "OPENZIM_ERROR"

    def __init__(self, message: str, details: Optional[str] = None):  # noqa: B042
        """Initialize the exception.

        Args:
            message: Human-readable error message
            details: Optional additional details about the error
        """
        self.message = message
        self.details = details
        # Pass only ``message`` to ``Exception.__init__``: ``Exception.args``
        # ends up as ``(message,)`` rather than ``(message, details)``, so
        # ``repr(error)`` no longer leaks operational metadata (rate-limit
        # cost breakdowns, request IDs, etc.) into tracebacks. ``details``
        # remains accessible programmatically via ``self.details``. The B042
        # exception (pickle/copy edge cases) is acceptable here because we
        # do not pickle these errors across process boundaries.
        super().__init__(message)

    def __str__(self) -> str:
        """Return the error message."""
        return self.message


class OpenZimMcpSecurityError(OpenZimMcpError):
    """Raised when security validation fails."""

    error_code: str = "OPENZIM_SECURITY_VIOLATION"


class OpenZimMcpValidationError(OpenZimMcpError):
    """Raised when input validation fails."""

    error_code: str = "OPENZIM_VALIDATION_ERROR"


class OpenZimMcpCursorMismatchError(OpenZimMcpValidationError):
    """A pagination cursor's archive identity does not match the call's archive.

    Subclasses ``OpenZimMcpValidationError`` so existing callers that catch
    the broad class keep working, but is distinct so the tool wrappers can
    render it under the same ``cursor_context_mismatch`` operation code the
    entry/kind cursor guards use — the archive-identity check can only run
    in the data layer (it needs the validated path), and as a plain
    validation error it fell into the wrappers' generic envelope, the one
    cursor failure mode a client's ``cursor_*`` recovery branch missed.
    """


class OpenZimMcpArchivePathError(OpenZimMcpValidationError):
    """Raised when the ZIM archive itself is missing or unusable.

    A subclass of :class:`OpenZimMcpValidationError` so every existing
    ``except OpenZimMcpValidationError`` keeps catching it, while callers that
    render argument-level advice (e.g. "retry with a smaller ``limit``") can
    single this out first: the failure is the archive, not an argument, and
    the recovery is to pick a different archive.
    """

    error_code: str = "OPENZIM_ARCHIVE_PATH_ERROR"


class OpenZimMcpArchiveNameError(OpenZimMcpArchivePathError):
    """Raised when a relative ``zim_file_path`` matches no loaded archive.

    A relative input carries no traversal (``..`` is rejected earlier) and
    no absolute escape, so failing to match is a typo or a stale name, not
    an attack. Keeping it apart from :class:`OpenZimMcpSecurityError` lets
    the error surface say "did not match any loaded archive" instead of
    "blocked for security reasons" — the wording the project already ruled
    a regression for the simple-mode path.
    """

    error_code: str = "OPENZIM_ARCHIVE_NAME_UNRESOLVED"


class OpenZimMcpFileNotFoundError(OpenZimMcpError):
    """Raised when a ZIM file is not found."""

    error_code: str = "OPENZIM_FILE_NOT_FOUND"


class OpenZimMcpArchiveError(OpenZimMcpError):
    """Raised when ZIM archive operations fail."""

    error_code: str = "OPENZIM_ARCHIVE_ERROR"


class OpenZimMcpEntryNotFoundError(OpenZimMcpArchiveError):
    """Raised when the caller names an entry path the archive does not contain.

    A subclass of :class:`OpenZimMcpArchiveError` so every existing
    ``except OpenZimMcpArchiveError`` keeps catching it unchanged; the only
    thing that changes is that callers can now tell "you asked for a page
    that isn't here" apart from "this archive is corrupt". That is the
    difference between a caller mistake and a server fault, and therefore
    between a WARNING and an ERROR — a distinction that must come from the
    exception TYPE, never from string-matching the message.
    ``tools/resource_tools.py`` already draws exactly this line at the
    protocol layer by answering a miss with ``INVALID_PARAMS``.
    """

    error_code: str = "OPENZIM_ENTRY_NOT_FOUND"


class OpenZimMcpConfigurationError(OpenZimMcpError):
    """Raised when configuration is invalid."""

    error_code: str = "OPENZIM_CONFIG_ERROR"


class OpenZimMcpTimeoutError(OpenZimMcpError):
    """Base class for timeout-related errors."""

    error_code: str = "OPENZIM_TIMEOUT"


class ArchiveOpenTimeoutError(OpenZimMcpTimeoutError):
    """Raised when opening a ZIM archive times out."""

    error_code: str = "OPENZIM_ARCHIVE_OPEN_TIMEOUT"


class RegexTimeoutError(OpenZimMcpTimeoutError):
    """Raised when a regex operation times out."""

    error_code: str = "OPENZIM_REGEX_TIMEOUT"


class OpenZimMcpRateLimitError(OpenZimMcpError):
    """Raised when rate limit is exceeded."""

    error_code: str = "OPENZIM_RATE_LIMIT_EXCEEDED"
