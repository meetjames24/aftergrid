"""Content-retrieval methods for ``ZimOperations``.

This mixin holds the entry-content reading surface — single entry, batch
entries, binary entries, summaries, and snippets. Methods run as instance
methods of ``ZimOperations`` via the mixin pattern.

``zim_archive``, ``Searcher``, ``Query`` etc. are accessed through
``openzim_mcp.zim_operations`` so existing test patches against the
shim's symbols continue to work without changes.
"""

import base64
import json
import logging
import re
from pathlib import Path
from typing import (
    TYPE_CHECKING,
    Any,
    Callable,
    Dict,
    List,
    Optional,
    Tuple,
    TypeVar,
    cast,
)
from urllib.parse import unquote

from libzim.reader import Archive  # type: ignore[import-untyped]

import openzim_mcp.zim_operations as _zim_ops_mod
from openzim_mcp.content_processor import paged_slice_length
from openzim_mcp.error_messages import url_shaped_path_hint
from openzim_mcp.exceptions import (
    OpenZimMcpArchiveError,
    OpenZimMcpEntryNotFoundError,
    OpenZimMcpValidationError,
)
from openzim_mcp.meta import attach_meta
from openzim_mcp.recovery_advice import (
    correct_entry_path,
    locate_entry,
    locate_or_explore,
    metadata_keys,
    verify_archive,
)
from openzim_mcp.zim._ops_base import _json
from openzim_mcp.zim.redirects import (
    best_effort_redirect_chain,
    resolve_redirect_chain,
)

if TYPE_CHECKING:
    from openzim_mcp.cache import OpenZimMcpCache
    from openzim_mcp.config import OpenZimMcpConfig
    from openzim_mcp.content_processor import ContentProcessor
    from openzim_mcp.preset_data import ArchivePreset
    from openzim_mcp.security import PathValidator
    from openzim_mcp.tool_schemas import (
        BatchEntryResponse,
        BinaryEntryResponse,
        EntryResponse,
        EntrySummaryResponse,
    )

logger = logging.getLogger(__name__)

# Result type produced by the surface-specific ``build`` callable in
# ``_smart_retrieve_entry`` — ``str`` for the legacy text surface,
# ``Dict[str, Any]`` for the structured surface.
_EntryResultT = TypeVar("_EntryResultT")


def _strip_markdown_links_shared(text: str) -> str:
    """Strip ``[text](href)`` / ``![alt](src)`` markdown link soup.

    Delegates to the tested ``_CompactFormatMixin._strip_markdown_links``
    (idempotent, timeout-bounded). Imported lazily to avoid an import-time
    cycle between the ``zim`` package and ``compact_format``.
    """
    from openzim_mcp.compact_format import _CompactFormatMixin

    return _CompactFormatMixin._strip_markdown_links(text)


# Common MIME-type prefix used to gate text-extraction logic.
_TEXT_MIME_PREFIX = "text/"

# Heading tokens (lowercase substring match) that mark the summary section
# for each non-default summary_style. A style with no token table, or whose
# token never matches, falls back to the first-section slice (never worse
# than baseline).
#
# ``q_and_a`` was validated against the live superuser (sotoki v3.0.2)
# archive during the v2.2.0 reprobe: real Q&A pages carry exactly one
# heading, always "N AnswersN" (sotoki pluralizes even N=1 -> "1 Answers1",
# e.g. "3 Answers3", "5 Answers5"), so this substring selects the answers
# block on every page. The answer-submission form is stripped by sotoki,
# so there is no competing "Your Answer" heading to false-match; zero-answer
# pages have no heading and fall through to the first-section fallback below.
#
# The a2 ``gloss`` (wiktionary) and ``transcript`` (ted) styles are deferred:
# a 2026-06-16 live probe found ted2zim ``ted_mul_all`` pages are heading-less
# multilingual stubs whose transcripts live in text/vtt subtitle files (not
# the HTML body), so a heading-token slice can never match; and no mwoffliner
# wiktionary archive was available to pin a gloss token. Re-add their entries
# here (and to SummaryStyle + data/presets.toml) once a real archive validates
# the selector. See the deferred items in docs/roadmap.md.
_ANSWER_HEADING_TOKENS = ("answer",)

_STYLE_HEADING_TOKENS: Dict[str, Tuple[str, ...]] = {
    "q_and_a": _ANSWER_HEADING_TOKENS,
}


def _render_offset_and_body(payload: Dict[str, Any]) -> Tuple[str, str]:
    """Render the ``Content Offset:`` line and the body for an entry payload.

    Shared by :func:`_render_entry_payload_text` and the ``M/<key>`` metadata
    presenter, which render the same two facts and must render them the same
    way. They were copies once, and the copy silently drifted — the metadata
    side lost the empty-value fallback, so a genuinely empty value printed as a
    bare ``## Content`` heading and nothing else, reading as "this entry has no
    content" rather than "this value is empty". Keeping one builder is what
    makes that class of drift impossible rather than merely fixed.

    Returns ``(offset_line, body)``. ``offset_line`` is ``""`` when no positive
    offset was applied and already carries its trailing newline otherwise, so
    callers concatenate it unconditionally.
    """
    offset_past_end = bool(payload.get("content_offset_past_end"))
    offset_line = ""
    # ``content_offset`` / ``total_chars`` are present exactly when a
    # positive offset was applied by the payload builder.
    if "content_offset" in payload:
        content_offset = payload["content_offset"]
        total_length = payload["total_chars"]
        if offset_past_end:
            offset_line = (
                f"Content Offset: {content_offset} is past the end of the "
                f"{total_length:,}-character body — no content at this offset.\n"
            )
        else:
            offset_line = (
                f"Content Offset: {content_offset} of {total_length:,} characters\n"
            )
    if offset_past_end:
        body = "(No content — offset beyond end of body)"
    else:
        body = payload["content"] or "(No content)"
    return offset_line, body


def _render_entry_payload_text(payload: Dict[str, Any]) -> str:
    """Render a ``_build_entry_payload`` dict as the legacy markdown text.

    The payload builder is the single source of truth for redirect
    resolution, compact link-stripping, and offset/truncation accounting;
    this function only formats — it must not re-derive any content or
    offset state. Shows both requested and actual paths when they differ
    (``requested_path`` is present in the payload exactly in that case).
    """
    result_text = f"# {payload['title']}\n\n"
    requested_path = payload.get("requested_path")
    if requested_path is not None:
        result_text += f"Requested Path: {requested_path}\n"
        result_text += f"Actual Path: {payload['path']}\n"
    else:
        result_text += f"Path: {payload['path']}\n"
    result_text += f"Type: {payload.get('content_type') or 'Unknown'}\n"
    offset_line, body = _render_offset_and_body(payload)
    return f"{result_text}{offset_line}## Content\n\n{body}"


def _alternate_entry_spellings(entry_path: str) -> List[str]:
    """Other spellings of ``entry_path`` worth an exact probe, raw one excluded.

    Mirrors ``zim.structure._resolve_entry_spelling``'s raw-first / decoded-
    fallback order for the entry-fetch ladder: the percent-decoded form is
    offered only when it differs from the input, so paths with a literal
    ``%`` (warc2zim asset names) are never decoded away from a working
    spelling.

    A leading ``/`` is the other common client slip: ZIM paths are never
    rooted, so ``/medlineplus.gov/diabetes.html`` can only mean the
    un-slashed entry. The search fallback cannot recover it — its matcher
    splits the first segment off both sides asymmetrically — and the
    not-found error then ran the path through the filesystem redactor,
    echoing ``...diabetes.html`` back at the caller.
    """
    candidates = [unquote(entry_path)]
    candidates.extend(c.lstrip("/") for c in (entry_path, *candidates))
    spellings: List[str] = []
    for candidate in candidates:
        if candidate and candidate != entry_path and candidate not in spellings:
            spellings.append(candidate)
    return spellings


# The size the illustration is actually fetched at. ``has_illustration()``
# with no argument answers "any size", which is not the same question:
# an archive can hold a 96px illustration and still fail the 48px fetch,
# putting the text and binary surfaces back into disagreement.
_ILLUSTRATION_SIZE = 48


def _has_well_known_illustration(archive: Archive) -> bool:
    """Whether ``get_illustration_item`` can serve the size we fetch."""
    try:
        return bool(archive.has_illustration(_ILLUSTRATION_SIZE))
    except Exception as e:  # pragma: no cover - defensive, libzim-version dependent
        logger.debug(f"has_illustration probe failed: {e}")
        return False


def rewrite_well_known_path(
    archive: Archive, entry_path: str, *, tool_mode: str = "simple"
) -> str:
    """Resolve a synthetic ``W/`` browse path to the entry it stands for.

    ``zim_browse``/``zim_metadata`` publish ``W/mainPage`` on new-scheme
    archives, but it is not a literal entry — it is resolved through
    ``archive.main_entry``. Every surface that resolves an entry path has to
    agree about that, or one tool answers contradictorily an argument apart:
    ``zim_get`` returned the article while ``view=toc``, ``zim_get_section``
    and ``zim_links`` — which run a second, independent ladder — returned
    Resource Not Found for the same path.

    The leading slash is accepted because ``get_zim_entry_data`` does not
    normalize at its boundary the way the binary surface does, so
    ``/W/mainPage`` would otherwise miss a check that sits above the ladder
    whose un-rooting recovery would have caught it.

    Any other path, and any old-scheme archive, is returned unchanged.
    """
    if not entry_path or not getattr(archive, "has_new_namespace_scheme", False):
        return entry_path
    if entry_path.lstrip("/") != "W/mainPage":
        return entry_path
    try:
        entry = best_effort_redirect_chain(archive.main_entry)
        resolved = getattr(entry, "path", None)
    except Exception as e:
        logger.debug(f"W/mainPage resolution failed: {e}")
        resolved = None
    if not resolved:
        raise OpenZimMcpEntryNotFoundError(
            "This archive declares no main page, so 'W/mainPage' cannot be "
            "resolved. " + locate_entry(tool_mode)
        )
    return str(resolved)


def _heading_matches(title: str, tokens: Tuple[str, ...]) -> bool:
    """Return True when a section heading contains any of ``tokens``."""
    t = title.strip().lower()
    return any(tok in t for tok in tokens)


def _strip_leading_score(md: str) -> str:
    """Drop a bare leading vote-score line from a Stack Exchange answer slice.

    sotoki answer bodies open with the answer's vote score on its own line
    (e.g. ``3``), which is noise as the first token of a summary. A leading
    line that is only digits (optionally signed) is removed; any other
    content — including a single line with no trailing newline — is returned
    unchanged so a real one-line answer is never destroyed.

    Validated 2026-06-16 against the live superuser.com_en_all_2026-02
    archive: a real q_and_a summary opens with the bare vote score on its
    own line ("2\\nCheck user A's .ssh/config ..."), so the strip fires on
    real output. The digits-only guard keeps a mis-fire harmless on
    non-score content.
    """
    stripped = md.lstrip("\n")
    head, sep, rest = stripped.partition("\n")
    if sep and head.strip().lstrip("+-").isdigit():
        return rest.lstrip("\n")
    return md


def _select_summary_section_md(
    sections: List[Any],
    rendered_md: str,
    summary_style: Optional[str],
) -> str:
    """Return the markdown slice for the summary, per ``summary_style``.

    A style listed in ``_STYLE_HEADING_TOKENS`` selects the first section
    whose heading matches its token set; ``q_and_a`` additionally strips a
    leading vote-score line. Any other style (including ``None``), or no
    matching heading, returns the first-section slice (the prior behavior),
    which guarantees a never-worse-than-baseline result.
    """
    tokens = _STYLE_HEADING_TOKENS.get(summary_style or "")
    if tokens is not None:
        for s in sections:
            if _heading_matches(str(s.get("title", "")), tokens):
                start = int(s["char_start"])
                end = int(s["char_end"])
                slice_md = rendered_md[start:end]
                if summary_style == "q_and_a":
                    slice_md = _strip_leading_score(slice_md)
                return slice_md
    if sections:
        return rendered_md[: int(sections[0]["char_end"])]
    return rendered_md


# D12 (v2.0.0a9): detect the path-traversal shapes that don't make sense
# for a ZIM entry path. ZIM paths are ``<namespace>/<name>`` (e.g.
# ``C/Berlin``) — they never start with ``/``, contain a ``..`` SEGMENT,
# or use URL-encoded equivalents. Reject these at the API boundary so
# log-based abuse detection has a clean signal and the response carries a
# security-flavoured message instead of the generic "entry not found"
# remediation advice.


def _truncate_markdown_words(text: str, max_words: int) -> str:
    """Cut ``text`` after its ``max_words``-th word, KEEPING its whitespace.

    ``" ".join(text.split()[:max_words])`` counts the same words but flattens
    every newline, and ``view="summary"`` truncates on any article long
    enough to be worth summarising — so the common case shipped one blob with
    ``##``/``###``/``*`` markers stranded mid-line, which no markdown renderer
    can lay out. Slice by character offset instead: the word budget is
    identical, the line structure survives.
    """
    if max_words <= 0:
        return ""
    seen = 0
    for match in re.finditer(r"\S+", text):
        seen += 1
        if seen == max_words:
            return text[: match.end()].rstrip()
    return text.rstrip()


def _looks_like_path_traversal(entry_path: str) -> bool:
    r"""Return True iff ``entry_path`` carries a path-traversal shape.

    Segment-based: only a whole ``..`` path segment (or its URL-encoded
    form, or an absolute-path prefix) triggers. Substring checks like
    ``startswith("..")`` / ``"/.." in path`` rejected real article titles
    beginning with dots — Wikipedia's ``...And Justice for All`` lives at
    ``A/...And_Justice_for_All``, which contains ``/..`` without any
    parent-directory reference.
    """
    if not entry_path:
        return False
    if entry_path.startswith("/") or entry_path.startswith("\\"):
        return True
    if "%2e%2e" in entry_path.lower():
        return True
    # Decode encoded separators so ``..%2Ffoo`` is seen as ``../foo``,
    # then test whole segments across both separator styles.
    decoded = (
        entry_path.replace("%2f", "/")
        .replace("%2F", "/")
        .replace("%5c", "\\")
        .replace("%5C", "\\")
    )
    return any(seg == ".." for seg in decoded.replace("\\", "/").split("/"))


def normalize_entry_path(entry_path: str) -> str:
    """Return ``entry_path`` with a client's leading ``/`` removed.

    ZIM entry paths are never rooted, so a leading slash can only be a client
    slip — D17 taught the entry-fetch ladder to try the un-slashed spelling
    for exactly that reason (``_alternate_entry_spellings``). The ladder sits
    behind ``reject_path_traversal``, though, and every sibling surface calls
    that guard first, so the same tool served ``/medlineplus.gov/diabetes.html``
    for the full body and answered the summary, batch and binary fetches with
    a security-flavoured rejection of a path it had just served.

    Normalizing before the guard fixes the message without loosening it: only
    the leading separator is dropped, never a segment, so ``/../secret`` still
    reaches the guard carrying its ``..``. A path that is nothing but slashes
    is returned unchanged, leaving that decision to the guard.

    Call it at the same boundary as ``reject_path_traversal``; the two belong
    together.
    """
    return entry_path.lstrip("/") or entry_path


def reject_path_traversal(entry_path: str) -> None:
    """Raise OpenZimMcpArchiveError on a path-traversal-shaped ``entry_path``.

    Public (no leading underscore) so every tool method that accepts a
    caller-supplied entry path can call this at its boundary. D12 added
    the guard to ``get_zim_entry``; the sibling tools (``get_section``,
    ``extract_article_links``, ``get_table_of_contents``,
    ``get_article_structure``, ``get_entry_summary``, ``get_binary_entry``,
    ``get_related_articles``, batch ``get_entries``) need the same
    protection so a single injection vector can't slip in via a different
    tool name.
    """
    if _looks_like_path_traversal(entry_path):
        raise OpenZimMcpArchiveError(
            f"Rejected suspicious entry path {entry_path!r}: paths with "
            f"``..`` segments or absolute prefixes are blocked. ZIM "
            f"entry paths are namespace-prefixed (e.g. ``C/Article_Name``)."
        )


# The shortest stored title worth completing from a body heading. "A"
# prefixes almost any sentence, so a one- or two-character title would let
# the page's typography overwrite the archive's naming on a coincidence.
_MIN_COMPLETABLE_TITLE = 3

_LEADING_H1_RE = re.compile(r"^\s*#\s+(.+?)\s*$", re.MULTILINE)


def snippet_render_key(validated_path: Optional[str], entry_path: str) -> Optional[str]:
    """Cache key for one entry's rendered markdown, or ``None``.

    Factored out so the search row can read back the very render its own
    snippet just produced (see ``completed_title``) without re-deriving the
    key — two spellings of one key is how a cache silently stops hitting.
    """
    if not validated_path or not entry_path:
        return None
    try:
        from openzim_mcp.bundle import archive_stat_token

        return (
            f"snippet_render:v1:{validated_path}:"
            f"{archive_stat_token(Path(validated_path))}:"
            f"{entry_path}"
        )
    except Exception:
        return None


def leading_h1(rendered_markdown: str) -> str:
    """The document's opening ``# `` heading, or ``""``.

    Read from the RENDERED markdown, which every search row already
    produces to build its snippet and which is cached per entry — so this
    costs a string scan, not a second body read. The render is
    query-independent (highlighting happens later, per query in
    ``create_snippet``), so the text here carries no emphasis markers.

    Only a heading that OPENS the document counts: a ``##`` further down is
    a section, and a page whose first heading is not an ``h1`` has no title
    heading to offer.
    """
    if not rendered_markdown:
        return ""
    # ``match`` (not ``search``) is what makes this "leading": it anchors at
    # position 0, so a ``# `` further down the document cannot answer, and
    # ``#\s+`` cannot match ``##`` because the second hash is not
    # whitespace. An explicit startswith guard here would be unreachable.
    match = _LEADING_H1_RE.match(rendered_markdown.lstrip())
    return match.group(1).strip() if match else ""


def completed_title(stored_title: str, body_h1: str) -> str:
    """``stored_title``, completed from ``body_h1`` when it was truncated.

    v3.3.1 field report (fid 70). warc2zim cuts a scraped ``<title>`` at a
    curly apostrophe, so MedlinePlus stores "Alzheimer" for a page whose
    own ``<h1>`` reads "Alzheimer's Disease" — and four unrelated pages
    then carry one indistinguishable title in a result list. The same
    truncation scores an exact 1.0 title match, so "Sartre" (really
    "Sartre's Political Philosophy") outranked the real overview article.

    Strictly a PREFIX repair, never a preference. A stored title that
    merely differs from the heading is the archive's own editorial choice,
    and overriding it would replace that choice with the page's
    typography; a stored title LONGER than the heading is already the
    fuller of the two.
    """
    stored = (stored_title or "").strip()
    h1 = (body_h1 or "").strip()
    if len(stored) < _MIN_COMPLETABLE_TITLE or len(h1) <= len(stored):
        return stored_title
    if not h1.lower().startswith(stored.lower()):
        return stored_title
    return h1


class _ContentMixin:
    """Entry-content retrieval methods for ZimOperations.

    Attributes below are provided by the concrete ``ZimOperations`` class
    that mixes this in.
    """

    if TYPE_CHECKING:
        config: "OpenZimMcpConfig"
        path_validator: "PathValidator"
        cache: "OpenZimMcpCache"
        content_processor: "ContentProcessor"

        def _validate_zim_path(self, zim_file_path: str) -> Path:
            """Resolve via ``_ArchiveAccessMixin`` on the concrete coordinator."""

        # Provided by other mixins / coordinator class.
        def _find_entry_by_search(
            self, archive: Archive, entry_path: str
        ) -> Optional[str]:
            """Resolve via ``_SearchMixin`` on the concrete coordinator."""

        def _resolve_entry_with_fallback(
            self, archive: Archive, entry_path: str
        ) -> Tuple[Any, str]:
            """Resolve via ``ZimOperations`` on the concrete coordinator."""

        def _resolve_preset_for_open_archive(
            self, archive: Archive, validated_path: Optional[str] = None
        ) -> "Tuple[Optional[ArchivePreset], Optional[str]]":
            """Resolve via ``ZimOperations`` on the concrete coordinator."""

    def _get_entry_snippet(
        self,
        entry: Any,
        query: Optional[str] = None,
        *,
        snippet_length: Optional[int] = None,
        max_paragraphs: Optional[int] = None,
        validated_path: Optional[str] = None,
    ) -> str:
        """Get content snippet for search result, optionally query-aware.

        Renders the entry's HTML with ``compact=True`` so the resulting
        markdown matches what the EntryBundle stores (the bundle is also
        built with ``compact=True`` in :mod:`openzim_mcp.bundle`).
        Without the same flag on both sides, search snippets carried
        pipe-soup infoboxes and raw tables that the bundle had already
        replaced with placeholders — section attribution in synthesize
        couldn't find those snippets in the bundle markdown, so every
        passage dropped back to entry-level citations.

        ``title=entry.title`` is forwarded to ``create_snippet`` so the
        leading ``# <Title>`` H1 that html2text emits (a verbatim
        duplicate of the entry title already shown in the result row)
        is stripped before snippet selection — Op1.

        M29 update: the original M29 proposed a snippet-only mode that
        skipped structural rewrites for per-result perf. In practice
        the infobox extraction is doing meaningful work for the
        SNIPPET (removing the leading infobox table so the snippet
        starts on the lead paragraph) — skipping it produced
        pipe-soup snippets. Kept compact=True; the M29 hook
        (``process_mime_content(snippet_mode=True)``) remains
        available for callers that want raw rendering.
        """
        try:
            # M31: the compact render below (BeautifulSoup parse + html2text
            # over the whole document) is the dominant CPU cost of a cold
            # search — it runs once per result and, in a synthesize request, the
            # SAME entries are re-rendered by get_or_build_bundle. The render is
            # query-INDEPENDENT (highlighting happens later in create_snippet),
            # so cache the rendered markdown per (path, entry, stat token) when
            # the caller supplies ``validated_path``; create_snippet then runs
            # per-query over the cached text.
            render_cache_key = snippet_render_key(
                validated_path, getattr(entry, "path", "") or ""
            )
            cached_content = (
                # One lookup per search RESULT, so this is the traffic that
                # used to swamp the reported hit rate (fid 127).
                self.cache.get(render_cache_key, ancillary=True)
                if render_cache_key
                else None
            )
            if isinstance(cached_content, str):
                entry_title = getattr(entry, "title", None) or ""
                mp = max_paragraphs if max_paragraphs is not None else 2
                return self.content_processor.create_snippet(
                    cached_content,
                    query=query,
                    title=entry_title,
                    max_paragraphs=mp,
                    snippet_length=snippet_length,
                )

            item = entry.get_item()
            mime = item.mimetype or ""
            if not mime.startswith(_TEXT_MIME_PREFIX):
                return f"(Unsupported content type: {mime})"
            if mime.startswith("text/html"):
                # Scope to the page's main-content landmark so snippets are
                # drawn from the article body, not the ZIMIT/warc2zim site
                # chrome (banner / header nav / footer) wrapping it. With no
                # landmark, select_main_content returns the whole document, so
                # this matches process_mime_content output for chrome-free
                # (e.g. Wikipedia/mwoffliner) pages — no regression there.
                from bs4 import BeautifulSoup

                from openzim_mcp.content_processor import (
                    HTML_PARSER,
                    select_main_content,
                )

                soup = BeautifulSoup(
                    bytes(item.content).decode("utf-8", errors="replace"),
                    HTML_PARSER,
                )
                content = self.content_processor._render_soup_to_text(
                    select_main_content(soup), compact=True
                )
            else:
                content = self.content_processor.process_mime_content(
                    bytes(item.content), mime, compact=True
                )
            if render_cache_key:
                try:
                    # One entry per result: ``ancillary`` keeps a wide search
                    # from charging ~limit slots against the response count
                    # cap and flushing every other warm response (D65).
                    self.cache.set(render_cache_key, content, ancillary=True)
                except Exception as exc:  # pragma: no cover - cache is best-effort
                    logger.debug("snippet render cache set failed: %s", exc)
            entry_title = getattr(entry, "title", None) or ""
            mp = max_paragraphs if max_paragraphs is not None else 2
            return self.content_processor.create_snippet(
                content,
                query=query,
                title=entry_title,
                max_paragraphs=mp,
                snippet_length=snippet_length,
            )
        except Exception as e:
            logger.warning(f"Error getting content snippet: {e}")
            return "(Unable to get content preview)"

    def get_zim_entry(
        self,
        zim_file_path: str,
        entry_path: str,
        max_content_length: Optional[int] = None,
        content_offset: int = 0,
        *,
        compact: bool = False,
    ) -> str:
        """Get detailed content of a ZIM entry with smart retrieval.

        This function implements intelligent entry retrieval that automatically handles
        path encoding inconsistencies common in ZIM files:

        1. **Direct Access**: First attempts to retrieve entry using provided path
        2. **Automatic Fallback**: If direct access fails, searches for the entry
           using various search terms derived from the path
        3. **Path Mapping Cache**: Caches successful path mappings for performance
        4. **Enhanced Error Guidance**: Provides guidance when entries not found

        This eliminates the need for manual search-first methodology and provides
        transparent operation regardless of path encoding differences.

        Args:
            zim_file_path: Path to the ZIM file
            entry_path: Entry path, e.g., 'A/Some_Article'
            max_content_length: Maximum length of content to return
            content_offset: Character offset to start reading from (default 0).
                Combine with max_content_length to page through long articles
                without re-fetching from the beginning.

        Returns:
            Entry content text with metadata including actual path used

        Raises:
            OpenZimMcpFileNotFoundError: If ZIM file not found
            OpenZimMcpArchiveError: If entry retrieval fails or entry cannot
                be found via direct access or search
        """
        if max_content_length is None:
            max_content_length = self.config.content.max_content_length
        if content_offset < 0:
            content_offset = 0

        # D12 (v2.0.0a9): reject path-traversal-shaped entry paths
        # before reaching the archive layer. ``reject_path_traversal``
        # is shared with the sibling tools so a single injection
        # vector can't slip in via a different tool name. The rooted
        # spelling is un-rooted first so this surface agrees with the
        # ladder in ``get_zim_entry_data`` (see ``normalize_entry_path``).
        entry_path = normalize_entry_path(entry_path)
        reject_path_traversal(entry_path)

        # Validate and resolve file path
        validated_path = self._validate_zim_path(zim_file_path)

        # Cheap response cache check: a hit avoids opening the archive
        # entirely, which is the whole point of caching here. The stat token
        # (mtime_ns:size) invalidates the entry when the archive is replaced
        # in place (archive_stat_token contract).
        #
        # ``v3`` because the stat token only covers the ARCHIVE changing, not
        # this server changing what it renders from an unchanged archive.
        # 3.0.0 does exactly that — the empty ``M/<key>`` fallback, the
        # boundary-whitespace fix and ``_meta.more_at_offset`` all alter the
        # cached value — so an operator upgrading with
        # ``persistence_enabled`` would have kept being served the 2.7.0
        # rendering until the TTL expired, with every fix inert on precisely
        # the entries it was written for. Same rule the bundle and
        # browse-namespace prefixes already follow. Both ``entry:`` keys must
        # stay byte-identical; see the sibling in ``_get_zim_entry_from_archive``.
        from openzim_mcp.bundle import archive_stat_token

        cache_key = (
            f"entry:v3:{validated_path}:{archive_stat_token(validated_path)}:"
            f"{entry_path}:{max_content_length}:{content_offset}:compact={compact}"
        )
        cached_result = self.cache.get(cache_key)
        if cached_result is not None:
            logger.debug(f"Returning cached entry: {entry_path}")
            return cached_result  # type: ignore[no-any-return]

        try:
            with _zim_ops_mod.zim_archive(validated_path) as archive:
                return self._get_zim_entry_from_archive(
                    archive,
                    validated_path,
                    entry_path,
                    max_content_length,
                    content_offset,
                    compact=compact,
                )
        except OpenZimMcpArchiveError:
            # Re-raise OpenZimMcpArchiveError with enhanced guidance messages
            raise
        except Exception as e:
            logger.error(f"Entry retrieval failed for {entry_path}: {e}")
            raise OpenZimMcpArchiveError(
                f"Entry retrieval failed for '{entry_path}': {e}. "
                f"This may be due to file access issues or ZIM file corruption. "
                + verify_archive(self.config.tool_mode)
            ) from e

    def _get_zim_entry_from_archive(
        self,
        archive: Archive,
        validated_path: Path,
        entry_path: str,
        max_content_length: int,
        content_offset: int = 0,
        *,
        compact: bool = False,
    ) -> str:
        """Retrieve and format a single entry against an already-open archive.

        Splits the open-archive concern out of ``get_zim_entry`` so batch
        callers (``get_entries``) can reuse one open archive across many
        entries from the same ZIM file.

        Honours the same response cache as ``get_zim_entry``: a cache hit
        returns the formatted text without touching the archive; misses are
        populated on success.
        """
        # Response cache: also checked here so batch callers benefit from
        # already-cached entries without re-rendering. ``get_zim_entry``
        # checks before opening the archive; this check covers the case
        # where the archive is already open (batch call) and a different
        # entry within the same ZIM file was previously cached. Key must
        # match get_zim_entry's exactly (same stat token) so the two checks
        # share one cache entry (archive_stat_token contract).
        from openzim_mcp.bundle import archive_stat_token

        cache_key = (
            f"entry:v3:{validated_path}:{archive_stat_token(validated_path)}:"
            f"{entry_path}:{max_content_length}:{content_offset}:compact={compact}"
        )
        cached_result = self.cache.get(cache_key)
        if cached_result is not None:
            logger.debug(f"Returning cached entry: {entry_path}")
            return cached_result  # type: ignore[no-any-return]

        result, content_ok = self._get_entry_content(
            archive,
            entry_path,
            max_content_length,
            validated_path,
            content_offset,
            compact=compact,
        )

        # Only cache successful content retrieval. If process_mime_content
        # raised and we returned an error sentinel, recompute on the next
        # request rather than locking the failure in for the TTL.
        if content_ok:
            self.cache.set(cache_key, result)
        logger.info(f"Retrieved entry: {entry_path}")
        return result

    def _get_batch_entry_body(
        self,
        archive: Archive,
        validated_path: Path,
        entry_path: str,
        max_content_length: int,
        *,
        compact: bool = False,
    ) -> str:
        """Resolve one batch entry and return its clean body text.

        Batch items used to carry the legacy rendered document (``# title``
        / ``Path:`` / ``Type:`` / ``## Content`` header block) while the
        single-entry branch serves the bare body with path/title as
        separate fields. The item already identifies the entry through
        ``entry_path``, so the batch surface now serves the same body the
        structured payload builder produces — first page, with the
        batch-specific truncation footer.

        Own cache namespace (``entry_batch``) because the body differs from
        both the legacy text (``entry:v3``) and the single-entry dict
        (``entry_data``) renderings of the same entry.
        """
        from openzim_mcp.bundle import archive_stat_token

        cache_key = (
            f"entry_batch:v1:{validated_path}:{archive_stat_token(validated_path)}:"
            f"{entry_path}:{max_content_length}:compact={compact}"
        )
        cached = self.cache.get(cache_key)
        if cached is not None:
            return cast(str, cached)

        payload, content_ok = self._smart_retrieve_entry(
            archive,
            entry_path,
            validated_path,
            build=lambda actual_path: self._build_entry_payload(
                archive,
                actual_path,
                entry_path,
                max_content_length,
                0,
                compact=compact,
                batch_item=True,
            ),
            fetch_metadata=lambda: self._get_metadata_entry_data(
                archive, entry_path, max_content_length, 0
            ),
        )
        body = str(payload.get("content") or "")
        if content_ok:
            self.cache.set(cache_key, body)
        return body

    def get_zim_entry_data(
        self,
        zim_file_path: str,
        entry_path: str,
        max_content_length: Optional[int] = None,
        content_offset: int = 0,
        *,
        compact: bool = False,
    ) -> "EntryResponse":
        """Structured variant of ``get_zim_entry``.

        Returns the entry dict directly (path/title/content/content_type)
        so MCP tools can hand it to the SDK's structured-content path.
        Honours the same smart-retrieval and path-mapping logic as the
        legacy text variant.

        Args:
            zim_file_path: Path to the ZIM file
            entry_path: Entry path, e.g., 'A/Some_Article'
            max_content_length: Maximum length of content to return
            content_offset: Character offset to start reading from (default 0)

        Returns:
            ``EntryResponse``-shaped dict with ``path``, ``title``,
            ``content``, optionally ``content_type``/``requested_path``/
            ``content_offset``/``total_chars``, plus ``_meta``.

        Raises:
            OpenZimMcpFileNotFoundError: If ZIM file not found
            OpenZimMcpArchiveError: If entry retrieval fails
        """
        if max_content_length is None:
            max_content_length = self.config.content.max_content_length
        if content_offset < 0:
            content_offset = 0

        validated_path = self._validate_zim_path(zim_file_path)

        # Cache key distinct from the legacy string cache so old persisted
        # entries (text payloads) don't collide with the new dict shape.
        # The stat token (mtime_ns:size) invalidates the entry when the
        # archive is replaced in place (archive_stat_token contract).
        from openzim_mcp.bundle import archive_stat_token

        cache_key = (
            f"entry_data:{validated_path}:{archive_stat_token(validated_path)}:"
            f"{entry_path}:{max_content_length}:{content_offset}:compact={compact}"
        )
        cached_result = self.cache.get(cache_key)
        if cached_result is not None:
            logger.debug(f"Returning cached entry dict for: {entry_path}")
            return cast("EntryResponse", cached_result)

        try:
            with _zim_ops_mod.zim_archive(validated_path) as archive:
                payload, content_ok = self._get_entry_data_from_archive(
                    archive,
                    entry_path,
                    max_content_length,
                    validated_path,
                    content_offset,
                    compact=compact,
                )
        except OpenZimMcpArchiveError:
            raise
        except Exception as e:
            logger.error(f"Entry retrieval failed for {entry_path}: {e}")
            raise OpenZimMcpArchiveError(
                f"Entry retrieval failed for '{entry_path}': {e}. "
                f"This may be due to file access issues or ZIM file corruption. "
                + verify_archive(self.config.tool_mode)
            ) from e

        # ``_truncated`` / ``_total_chars`` / ``_content_chars`` are internal
        # hints from the payload builder that drive the eventual ``_meta``
        # envelope; stripped before the dict reaches the wire.
        truncated = bool(payload.pop("_truncated", False))
        total_chars = payload.pop("_total_chars", None)
        # ``_content_chars`` is the length of the paginable body SLICE
        # (excluding the appended truncation note). Using it — rather than
        # ``len(payload["content"])``, which includes the note — keeps
        # ``more_at_offset`` aligned with the human-readable
        # ``content_offset=N`` hint in the body. Fallback to the served length
        # for any payload that predates the hint.
        content_chars = payload.pop("_content_chars", None)
        if content_chars is None:
            content_chars = len(payload.get("content", ""))
        with_meta = attach_meta(
            payload,
            truncated=truncated,
            total_chars=total_chars,
            current_offset=content_offset,
            content_chars=content_chars,
        )
        # Attach _meta before caching so cold and warm reads return
        # bit-identical responses (Phase B #12).
        if content_ok:
            self.cache.set(cache_key, with_meta)
        logger.info(f"Retrieved entry data: {entry_path}")
        return cast("EntryResponse", with_meta)

    def _smart_retrieve_entry(
        self,
        archive: Archive,
        entry_path: str,
        validated_path: Path,
        *,
        build: Callable[[str], Tuple[_EntryResultT, bool, str]],
        fetch_metadata: Callable[[], Tuple[_EntryResultT, bool]],
    ) -> Tuple[_EntryResultT, bool]:
        """Shared smart-retrieval ladder for the text and structured surfaces.

        Implements the retrieval control flow exactly once (it used to be
        duplicated between ``_get_entry_content`` and
        ``_get_entry_data_from_archive``, which is how the D7 M/-routing
        fix initially landed on only one surface):

        1. Route ``M/<key>`` paths on new-scheme archives to the metadata
           API via ``fetch_metadata`` (D7).
        2. Try the cached path mapping, dropping it if it went stale.
        3. Try direct entry access, caching the resolved path on success.
        4. Probe the alternate spellings of the raw path (percent-decoded,
           un-rooted) as cheap exact lookups, caching the resolved path.
        5. Fall back to search-based retrieval, caching the resolved path.

        Steps 2, 4 and 5 live in ``_retrieve_via_*`` helpers; the order
        here is the contract (raw spelling before decoded, exact probes
        before search).

        ``build`` constructs the surface-specific result for a candidate
        path and returns ``(result, content_ok, resolved_path)``. Both
        surfaces share the path-mapping cache (it stores the resolved
        actual_path, not the body), so a hit on one surface also speeds
        up the other.

        Returns:
            ``(result, content_ok)`` — ``content_ok`` is False when MIME
            processing raised and the result body holds the
            ``(Error retrieving content: ...)`` sentinel; the caller must
            not cache the response in that case.
        """
        # D7 (beta): the path-traversal-guard error message tells callers
        # to use namespace-prefixed paths like ``M/Title``. But libzim
        # silently strips the ``M/`` prefix and resolves to the C-namespace
        # article with that name — so ``get_zim_entry('M/Title')``
        # against a Wikipedia ZIM returned the 172 KB disambiguation
        # article "Title" instead of the ZIM metadata "Title" entry
        # ("Wikipedia"). The proper API for M entries is
        # ``archive.get_metadata(key)``. Route ``M/<key>`` paths to it
        # explicitly so callers can actually reach ZIM metadata.
        if (
            entry_path
            and entry_path.startswith("M/")
            and getattr(archive, "has_new_namespace_scheme", False)
        ):
            return fetch_metadata()

        # The sibling route for the synthetic ``W/`` rows browse publishes
        # (see ``namespace._materialise_browse_entry``). Neither path is a
        # literal entry on a new-scheme archive, so without this both were
        # advertised by one tool and rejected by another — with the
        # rejection advising "use browsing tools", the tool that had just
        # handed the caller the path.
        entry_path = rewrite_well_known_path(
            archive, entry_path, tool_mode=self.config.tool_mode
        )
        if entry_path == "W/favicon" and getattr(
            archive, "has_new_namespace_scheme", False
        ):
            # Served, but only as bytes: the illustration is an image, so the
            # binary route is the one that can carry it (see
            # ``get_binary_entry_data``). Name that instead of sending the
            # caller back to the browse tool that offered the path — but only
            # when there is something to fetch, or the retry we prescribe
            # fails and the caller spends two round trips learning the first
            # answer was false.
            if _has_well_known_illustration(archive):
                raise OpenZimMcpEntryNotFoundError(
                    "'W/favicon' is the archive illustration, an image. "
                    "Fetch it with binary=True."
                )
            raise OpenZimMcpEntryNotFoundError(
                "This archive carries no illustration, so 'W/favicon' cannot "
                "be fetched."
            )

        cache_key = self._path_mapping_cache_key(validated_path, entry_path)
        cached = self._retrieve_via_cached_mapping(cache_key, entry_path, build)
        if cached is not None:
            return cached

        # Try direct access first
        try:
            logger.debug(f"Attempting direct entry access: {entry_path}")
            result, content_ok, resolved_path = build(entry_path)
            # Cache the *resolved* path so a follow-up request for the same
            # redirect entry skips the redirect chain entirely. Path mapping
            # is valid even if content extraction hit a transient MIME error
            # — the path resolved, only the body raised.
            self.cache.set(cache_key, resolved_path)
            return result, content_ok
        except OpenZimMcpArchiveError:
            # Structural failures we raised ourselves (redirect cycles,
            # depth-limit) are not "entry not found" cases — searching for
            # the same path again would either return the same broken
            # redirect or a misleading match. Propagate unchanged.
            raise
        except Exception as direct_error:
            logger.debug(f"Direct entry access failed for {entry_path}: {direct_error}")
            # Both fallbacks run inside this handler on purpose: anything
            # they raise keeps ``direct_error`` as its implicit context.
            alternate = self._retrieve_via_alternate_spelling(
                cache_key, entry_path, build
            )
            if alternate is not None:
                return alternate
            return self._retrieve_via_search(
                archive, cache_key, entry_path, build, direct_error
            )

    @staticmethod
    def _resolve_well_known_illustration(archive: Archive) -> Any:
        """The illustration Item behind the synthetic ``W/favicon`` row.

        Matches the size ``namespace._materialise_new_scheme_favicon`` probes
        for the browse row, so the two surfaces describe the same asset.
        """
        try:
            item = archive.get_illustration_item(48)
        except Exception as e:
            logger.debug(f"get_illustration_item failed: {e}")
            item = None
        if item is None:
            raise OpenZimMcpEntryNotFoundError(
                "This archive carries no illustration, so 'W/favicon' cannot "
                "be fetched."
            )
        return item

    @staticmethod
    def _path_mapping_cache_key(validated_path: Path, entry_path: str) -> str:
        """Cache key for the requested-path -> resolved-path mapping.

        Includes the archive path + stat token so identical entry names in
        different ZIM files don't collide and an atomic file replacement
        invalidates the resolved-path cache.
        """
        from openzim_mcp.bundle import archive_stat_token

        return (
            f"path_mapping:{validated_path}:"
            f"{archive_stat_token(validated_path)}:{entry_path}"
        )

    def _retrieve_via_cached_mapping(
        self,
        cache_key: str,
        entry_path: str,
        build: Callable[[str], Tuple[_EntryResultT, bool, str]],
    ) -> Optional[Tuple[_EntryResultT, bool]]:
        """Ladder step 2: serve from the cached path mapping if it still holds.

        Returns ``None`` when there is no mapping or it went stale (the
        stale entry is dropped so the caller continues down the ladder).
        """
        cached_actual_path = self.cache.get(cache_key)
        if not cached_actual_path:
            return None
        logger.debug(f"Using cached path mapping: {entry_path} -> {cached_actual_path}")
        try:
            result, content_ok, _resolved = build(cached_actual_path)
            return result, content_ok
        except Exception as e:
            logger.warning(f"Cached path mapping failed: {e}")
            # Clear invalid cache entry and continue with smart retrieval
            self.cache.delete(cache_key)
            return None

    def _retrieve_via_alternate_spelling(
        self,
        cache_key: str,
        entry_path: str,
        build: Callable[[str], Tuple[_EntryResultT, bool, str]],
    ) -> Optional[Tuple[_EntryResultT, bool]]:
        """Ladder step 4: exact probes on the other spellings of ``entry_path``.

        These come BEFORE the search fallback: the archive's own links are
        percent-encoded per RFC 3986 while libzim stores raw UTF-8, so a
        client following a link zim_get itself served
        (``../gau%E1%B8%8Dapad/``) used to dead-end in not-found. The raw
        spelling was already tried by the caller — some archives store a
        literal ``%`` in a path — so decoding is strictly a fallback.

        Returns ``None`` when no alternate spelling resolves. Structural
        ``OpenZimMcpArchiveError``s from ``build`` propagate unchanged.
        """
        for alternate in _alternate_entry_spellings(entry_path):
            try:
                result, content_ok, resolved_path = build(alternate)
            except OpenZimMcpArchiveError:
                raise
            except Exception as alternate_error:
                logger.debug(
                    f"Alternate spelling {alternate!r} failed: {alternate_error}"
                )
                continue
            self.cache.set(cache_key, resolved_path)
            logger.info(f"Resolved {entry_path!r} via alternate spelling {alternate!r}")
            return result, content_ok
        return None

    def _retrieve_via_search(
        self,
        archive: Archive,
        cache_key: str,
        entry_path: str,
        build: Callable[[str], Tuple[_EntryResultT, bool, str]],
        direct_error: Exception,
    ) -> Tuple[_EntryResultT, bool]:
        """Ladder step 5: search-based retrieval, the last resort.

        Raises ``OpenZimMcpArchiveError`` with tool guidance when the
        search finds nothing or fails; ``direct_error`` is quoted in the
        failure message so the caller sees both legs of the ladder.
        """
        try:
            logger.info(f"Falling back to search-based retrieval for: {entry_path}")
            actual_path = self._find_entry_by_search(archive, entry_path)
            if actual_path:
                result, content_ok, resolved_path = build(actual_path)
                # Cache the resolved path (which may differ from
                # ``actual_path`` if the search hit a redirect stub).
                self.cache.set(cache_key, resolved_path)
                logger.info(
                    f"Smart retrieval successful: {entry_path} -> {resolved_path}"
                )
                return result, content_ok
            # No entry found via search
            raise OpenZimMcpEntryNotFoundError(
                f"Entry not found: '{entry_path}'. "
                f"The entry path may not exist in this ZIM file. "
                + locate_or_explore(self.config.tool_mode)
                + url_shaped_path_hint(entry_path)
            )
        except OpenZimMcpArchiveError:
            # Re-raise our custom errors with guidance
            raise
        except Exception as search_error:
            logger.error(
                f"Search-based retrieval failed for {entry_path}: {search_error}"
            )
            # Provide comprehensive error message with guidance
            raise OpenZimMcpArchiveError(
                f"Failed to retrieve entry '{entry_path}'. "
                f"Direct access failed: {direct_error}. "
                f"Search-based fallback failed: {search_error}. "
                f"The entry may not exist or the path format may be incorrect. "
                + correct_entry_path(self.config.tool_mode)
            ) from search_error

    def _get_entry_data_from_archive(
        self,
        archive: Archive,
        entry_path: str,
        max_content_length: int,
        validated_path: Path,
        content_offset: int = 0,
        *,
        compact: bool = False,
    ) -> Tuple[Dict[str, Any], bool]:
        """Resolve an entry against an open archive and build its dict payload.

        Thin structured binding of ``_smart_retrieve_entry`` — the ladder
        (D7 M/-routing, path-mapping cache, direct-access/search fallback)
        lives there, shared with the legacy text surface.

        Returns:
            ``(payload, content_ok)`` — ``content_ok`` is False when MIME
            processing raised and ``payload["content"]`` is the error
            sentinel; the caller must not cache the response in that case.
        """
        return self._smart_retrieve_entry(
            archive,
            entry_path,
            validated_path,
            build=lambda actual_path: self._build_entry_payload(
                archive,
                actual_path,
                entry_path,
                max_content_length,
                content_offset,
                compact=compact,
            ),
            fetch_metadata=lambda: self._get_metadata_entry_data(
                archive,
                entry_path,
                max_content_length,
                content_offset,
            ),
        )

    def _build_entry_payload(  # NOSONAR(python:S3776)
        self,
        archive: Archive,
        actual_path: str,
        requested_path: str,
        max_content_length: int,
        content_offset: int = 0,
        *,
        compact: bool = False,
        batch_item: bool = False,
    ) -> Tuple[Dict[str, Any], bool, str]:
        """Construct the dict payload for a resolved entry.

        Single source of truth for redirect resolution (cycle/depth
        checks), content extraction, compact link-stripping, and
        offset/truncation accounting. The legacy text surface
        (``_get_entry_content_direct``) renders this payload via
        ``_render_entry_payload_text``. ``batch_item`` selects the
        truncation footer batch mode can act on (see
        ``ContentProcessor.truncate_content``).
        """
        entry = archive.get_entry_by_path(actual_path)

        # Resolve redirects to the target entry so the response reflects
        # the resolved page (path, title, content) rather than the redirect
        # stub. The shared resolver detects cycles and runaway chains
        # explicitly — libzim's ``Entry.get_item()`` silently follows the
        # chain and would hang on a cycle.
        entry = resolve_redirect_chain(entry, context=f"starting at {actual_path}")

        # From here on, ``entry`` is the resolved target. Update
        # ``actual_path`` so the response and the path-mapping cache
        # reflect the target — subsequent lookups skip the chain entirely.
        actual_path = entry.path
        title = entry.title or "Untitled"

        content = ""
        content_type = ""
        content_ok = True
        try:
            item = entry.get_item()
            content_type = item.mimetype or ""
            # Process content based on MIME type. ``scope_main_content``
            # strips ZIMIT/warc2zim site chrome from the primary
            # entry-content fetch so get_zim_entry / get_entries match the
            # cleaned bundle tools.
            content = self.content_processor.process_mime_content(
                bytes(item.content),
                content_type,
                compact=compact,
                scope_main_content=True,
            )
        except Exception as e:
            logger.warning(f"Error getting entry content: {e}")
            content = f"(Error retrieving content: {e})"
            content_ok = False

        # Strip markdown link soup IN the content layer when compact, BEFORE
        # measuring/slicing, so ``total_chars`` and ``content_offset`` are
        # computed against the same text the caller receives. Otherwise the
        # body was measured/sliced with link markup (~146k chars) but served
        # link-stripped (~83k) by the downstream compact post-processing, and
        # content_offset addressed positions that didn't exist in the served
        # text. (The downstream strip is now idempotent on this content.)
        if compact:
            content = _strip_markdown_links_shared(content)

        total_length = len(content)
        offset_applied = False
        offset_past_end = False
        if content_offset and content_offset > 0:
            if content_offset >= total_length:
                content = ""
                offset_past_end = True
            else:
                content = content[content_offset:]
            offset_applied = True

        # Truncate post-offset so max_content_length governs the *returned*
        # slice, matching the legacy text path. ``current_offset`` carries
        # the starting offset into the original article so the truncation
        # hint can compute the correct next-page offset (A11 F2/Opp4).
        # ``original_total`` carries the pre-slice length so the footer's
        # "of N" denominator stays correct under pagination (A11 post-a11
        # M4); without it the footer reported the post-slice length and
        # the "total" decreased every time the caller paged forward.
        truncated_content = self.content_processor.truncate_content(
            content,
            max_content_length,
            current_offset=content_offset,
            original_total=total_length,
            batch_item=batch_item,
        )
        # Compare against the cap, NOT the rendered lengths: ``truncate_content``
        # appends a ~150-char truncation note, so ``len(truncated) < len(content)``
        # is False whenever the overflow is smaller than that note — the body
        # visibly said "truncated" while the metadata said otherwise. ``content``
        # is already the post-offset slice handed to ``truncate_content``, so
        # this predicate agrees with it exactly (empty content: 0 > cap is False,
        # matching ``truncate_content``'s short-circuit).
        was_truncated = len(content) > max_content_length
        # The paginable slice length is the pre-note body length —
        # ``truncate_content`` slices ``content[:max_content_length]`` and only
        # then appends the ``... [Content truncated ...] ...`` note. The human
        # hint inside that note points the caller at
        # ``content_offset = current_offset + max_content_length``; capture the
        # same slice length here so ``more_at_offset`` agrees with it instead of
        # overshooting by the note length. When not truncated the whole
        # post-offset body is served, so the slice length is ``len(content)``
        # and no continuation offset is emitted anyway.
        content_chars = paged_slice_length(content, max_content_length, content_offset)
        content = truncated_content

        payload: Dict[str, Any] = {
            "path": actual_path,
            "title": title,
            "content": content,
        }
        if content_type:
            payload["content_type"] = content_type
        if actual_path != requested_path:
            payload["requested_path"] = requested_path
        if offset_applied:
            payload["content_offset"] = content_offset
            payload["total_chars"] = total_length
            if offset_past_end:
                payload["content_offset_past_end"] = True
        # Hints stripped before the dict is returned to the caller; they
        # drive the eventual ``attach_meta`` call.
        if was_truncated or offset_applied:
            payload["_truncated"] = was_truncated
            payload["_total_chars"] = total_length
            payload["_content_chars"] = content_chars
        return payload, content_ok, actual_path

    def get_entries_data(  # NOSONAR(python:S3776)
        self,
        entries: List[Dict[str, str]],
        max_content_length: Optional[int] = None,
        *,
        compact: bool = False,
    ) -> "BatchEntryResponse":
        """Structured variant of ``get_entries``.

        Returns the result dict directly (not a JSON string) so MCP tools
        can hand it straight to the SDK's structured-content path.

        Per-entry partial success: one failure does not abort the batch.
        Each result carries the input ``index`` so callers can correlate
        responses with their original request order.

        v2 Phase B contract: the response carries the canonical pagination
        keys (``results`` / ``next_cursor`` / ``total`` / ``done`` /
        ``page_info``) plus the tool-specific ``succeeded`` / ``failed``
        counters. Batch fetch is non-paginated — every requested entry is
        attempted, so ``next_cursor`` is always ``None`` and ``done`` is
        always ``True``. The contract is applied for uniformity with the
        other list-shaped responses.

        Args:
            entries: list of ``{"zim_file_path", "entry_path"}`` dicts.
            max_content_length: per-entry max content length.

        Returns:
            ``BatchEntryResponse``-shaped dict carrying ``results``,
            ``next_cursor`` (always ``None``), ``total``, ``done`` (always
            ``True``), ``page_info``, ``succeeded``, ``failed``, plus
            ``_meta``.

        Raises:
            OpenZimMcpValidationError: empty list or > MAX_BATCH_SIZE.
        """
        from openzim_mcp.constants import MAX_BATCH_SIZE

        if not entries:
            raise OpenZimMcpValidationError("entries list cannot be empty")
        if len(entries) > MAX_BATCH_SIZE:
            raise OpenZimMcpValidationError(
                f"batch size {len(entries)} exceeds limit {MAX_BATCH_SIZE}; "
                "split into multiple batches"
            )

        # Resolve the per-entry max length once — the same default applies to
        # every entry in the batch, so honour it here rather than re-resolving
        # inside _get_zim_entry_from_archive.
        if max_content_length is None:
            max_content_length = self.config.content.max_content_length

        # Group input entries by zim_file_path so we open each archive once
        # for the whole group. Preserve the original input index on every
        # entry so we can emit results in input order even after grouping.
        groups: Dict[str, List[Tuple[int, str, str]]] = {}
        for index, entry in enumerate(entries):
            zim_file_path = entry.get("zim_file_path", "")
            entry_path = entry.get("entry_path", "")
            groups.setdefault(zim_file_path, []).append(
                (index, zim_file_path, entry_path)
            )

        results: List[Dict[str, Any]] = []
        succeeded = 0
        failed = 0

        for zim_file_path, group in groups.items():
            # Validate the path once per file. If validation itself fails,
            # every entry in this group fails with the same error rather
            # than spending an archive open per entry.
            try:
                validated_path = self._validate_zim_path(zim_file_path)
            except Exception as e:  # noqa: BLE001 - per-group isolation
                for index, zfp, entry_path in group:
                    results.append(
                        {
                            "index": index,
                            "zim_file_path": zfp,
                            "entry_path": entry_path,
                            "success": False,
                            "error": str(e),
                        }
                    )
                    failed += 1
                continue

            # Open the archive once for the whole group via the context
            # manager. If opening fails, mark every entry in this group as
            # failed without trying again — the failure is per-file, not
            # per-entry. Per-entry exceptions are caught inside the inner
            # loop so they stay scoped to the right index.
            try:
                with _zim_ops_mod.zim_archive(validated_path) as archive:
                    for index, zfp, entry_path in group:
                        try:
                            # Per-entry path-traversal guard. Without this
                            # check inside the batch loop, a malicious
                            # entry slips through D12 by hiding inside a
                            # batched request. The normalized spelling is
                            # kept local so the result still echoes the
                            # path the caller sent, for correlation.
                            fetch_path = normalize_entry_path(entry_path)
                            reject_path_traversal(fetch_path)
                            content = self._get_batch_entry_body(
                                archive,
                                validated_path,
                                fetch_path,
                                max_content_length,
                                compact=compact,
                            )
                            results.append(
                                {
                                    "index": index,
                                    "zim_file_path": zfp,
                                    "entry_path": entry_path,
                                    "success": True,
                                    "content": content,
                                }
                            )
                            succeeded += 1
                        except (
                            Exception
                        ) as e:  # noqa: BLE001 - per-entry isolation by design
                            results.append(
                                {
                                    "index": index,
                                    "zim_file_path": zfp,
                                    "entry_path": entry_path,
                                    "success": False,
                                    "error": str(e),
                                }
                            )
                            failed += 1
            except Exception as e:  # noqa: BLE001 - per-group isolation
                for index, zfp, entry_path in group:
                    results.append(
                        {
                            "index": index,
                            "zim_file_path": zfp,
                            "entry_path": entry_path,
                            "success": False,
                            "error": str(e),
                        }
                    )
                    failed += 1
                continue

        # Sort back into input order so callers see results in the order
        # they submitted entries (grouping is a transparent optimisation).
        results.sort(key=lambda r: r["index"])

        payload: Dict[str, Any] = {
            "results": results,
            "next_cursor": None,
            "total": len(results),
            "done": True,
            "page_info": {
                "offset": 0,
                "limit": len(entries),
                "returned_count": len(results),
            },
            "succeeded": succeeded,
            "failed": failed,
        }
        return cast("BatchEntryResponse", attach_meta(payload))

    def get_entries(
        self,
        entries: List[Dict[str, str]],
        max_content_length: Optional[int] = None,
        *,
        compact: bool = False,
    ) -> str:
        """Legacy JSON-string variant of ``get_entries_data``.

        Fetch multiple ZIM entries in one call. Per-entry partial success:
        one failure does not abort the batch. Each result carries the
        input ``index`` so callers can correlate responses with their
        original request order.

        Args:
            entries: list of ``{"zim_file_path", "entry_path"}`` dicts.
            max_content_length: per-entry max content length.
            compact: When True, forward compact rendering to each entry
                (infobox extraction, oversized-table replacement).

        Returns:
            JSON string ``{"results": [...], "succeeded": N, "failed": N}``.

        Raises:
            OpenZimMcpValidationError: empty list or > MAX_BATCH_SIZE.
        """
        return json.dumps(
            self.get_entries_data(entries, max_content_length, compact=compact),
            ensure_ascii=False,
        )

    def _get_entry_content(
        self,
        archive: Archive,
        entry_path: str,
        max_content_length: int,
        validated_path: Path,
        content_offset: int = 0,
        *,
        compact: bool = False,
    ) -> Tuple[str, bool]:
        """Get the actual entry content with smart retrieval.

        Thin text binding of ``_smart_retrieve_entry`` — the ladder (D7
        M/-routing, path-mapping cache, direct-access/search fallback)
        lives there, shared with the structured surface.

        Returns:
            (result_text, content_ok) — ``content_ok`` is False when
            ``process_mime_content`` raised and the result text is the
            ``(Error retrieving content: ...)`` sentinel; the caller must
            not cache the response in that case.
        """
        return self._smart_retrieve_entry(
            archive,
            entry_path,
            validated_path,
            build=lambda actual_path: self._get_entry_content_direct(
                archive,
                actual_path,
                entry_path,
                max_content_length,
                content_offset,
                compact=compact,
            ),
            fetch_metadata=lambda: self._get_metadata_entry(
                archive,
                entry_path,
                max_content_length,
                content_offset,
            ),
        )

    @staticmethod
    def _decode_metadata_content(raw: bytes, mime: str) -> str:
        """Decode a metadata item's bytes payload into a string.

        Text MIME types decode as UTF-8 (replacement on invalid bytes);
        binary types render as a ``(mime content, N bytes)`` marker;
        empty bytes return an empty string.
        """
        if mime.startswith(_TEXT_MIME_PREFIX):
            try:
                return raw.decode("utf-8", errors="replace")
            except Exception:
                return repr(raw)
        if raw:
            return f"({mime or 'binary'} content, {len(raw)} bytes)"
        return ""

    def _get_metadata_entry(
        self,
        archive: Archive,
        entry_path: str,
        max_content_length: int,
        content_offset: int = 0,
    ) -> Tuple[str, bool]:
        """D7 (beta): fetch a ZIM ``M/<key>`` metadata entry.

        New-scheme ZIM archives keep metadata (Title, Description,
        Date, Creator, Source, etc.) on a separate API surface
        (``archive.get_metadata`` / ``get_metadata_item``) — the
        iterable C-namespace entry surface that ``get_entry_by_path``
        uses silently strips the ``M/`` prefix and resolves to a
        same-named article. Callers that ask for ``M/Title`` mean the
        archive metadata, so route the request to the metadata API
        and return whatever text/bytes the ZIM stored.

        Thin text presenter over ``_get_metadata_entry_data`` — the dict
        builder is the single source of truth for key resolution and
        offset/truncation accounting.

        Returns ``(result_text, content_ok)`` matching the contract of
        :meth:`_get_entry_content`. ``content_ok`` is False only when
        the metadata read itself raised (e.g. missing key); a present
        non-text payload is still ``True`` — it's just rendered with
        a ``(bytes content)`` marker.
        """
        payload, content_ok = self._get_metadata_entry_data(
            archive, entry_path, max_content_length, content_offset
        )
        if not content_ok:
            # Error payloads carry the requested path in ``path`` and the
            # diagnostic message in ``content``.
            return f"# {payload['path']}\n\n{payload['content']}", False
        # Offset accounting and the body come from the renderer the regular
        # entry surface uses, not a copy of it: a tail slice must not read as
        # the complete value, a past-end offset must not read as "the value is
        # empty", and an empty value must not read as "no content here".
        offset_line, body = _render_offset_and_body(payload)
        return (
            f"# {payload['title']}\n\nRequested Path: {payload['path']}\n"
            f"Type: {payload.get('content_type') or 'Unknown'}\n"
            f"{offset_line}## Content\n\n{body}"
        ), True

    def _get_metadata_entry_data(
        self,
        archive: Archive,
        entry_path: str,
        max_content_length: int,
        content_offset: int = 0,
    ) -> Tuple[Dict[str, Any], bool]:
        """D7 (beta): dict-shaped ``M/<key>`` metadata fetch.

        Single source of truth for metadata-key resolution and the
        offset/truncation accounting (matching ``_build_entry_payload``'s
        so the ``M/<key>`` route honours the regular entry contract). The
        legacy text surface (``_get_metadata_entry``) renders this
        payload. Returns ``(payload, content_ok)`` matching
        :meth:`_get_entry_data_from_archive`.
        """
        key = entry_path.split("/", 1)[1] if "/" in entry_path else entry_path
        payload: Dict[str, Any] = {
            "path": entry_path,
            "title": key or entry_path,
            "content": "",
        }
        # A miss raises like every other entry miss. Returning the sentence
        # in ``content`` with ``content_ok=False`` only suppressed caching:
        # the tool still answered ``isError=false``, so a client rendering
        # ``content`` displayed "Metadata key … not found" as though it were
        # the entry's text, while the same miss under ``A/`` surfaced the
        # Resource Not Found envelope.
        if not key:
            raise OpenZimMcpEntryNotFoundError(
                "Empty metadata key. Pass a known M/<key> path. "
                + metadata_keys(self.config.tool_mode)
            )
        try:
            item = archive.get_metadata_item(key)
        except Exception as e:
            logger.debug(f"get_metadata_item failed for {key}: {e}")
            raise OpenZimMcpEntryNotFoundError(
                f"Entry not found: '{entry_path}'. "
                f"Metadata key {key!r} does not exist in this archive. "
                + metadata_keys(self.config.tool_mode)
            ) from e
        if item is None:
            # Same contract as the raising branch above: a key that resolves
            # to nothing is a miss, not a body. Real libzim raises rather
            # than returning ``None``, so this is defence for a stubbed or
            # future backend — but it must not be the one path that still
            # answers isError=false with an error sentence as the content.
            raise OpenZimMcpEntryNotFoundError(
                f"Entry not found: '{entry_path}'. "
                f"Metadata key {key!r} resolved to an empty item. "
                + metadata_keys(self.config.tool_mode)
            )
        mime = item.mimetype or ""
        try:
            raw = bytes(item.content)
        except Exception as e:
            logger.warning(f"Metadata content read failed for {key}: {e}")
            payload["content"] = f"(Error retrieving content: {e})"
            return payload, False
        content = self._decode_metadata_content(raw, mime)

        total_length = len(content)
        offset_applied = False
        offset_past_end = False
        if content_offset and content_offset > 0:
            if content_offset >= total_length:
                content = ""
                offset_past_end = True
            else:
                content = content[content_offset:]
            offset_applied = True
        truncated_content = self.content_processor.truncate_content(
            content,
            max_content_length,
            current_offset=content_offset,
            original_total=total_length,
        )
        # See the note at the sibling site above: the appended truncation note
        # makes a length comparison unreliable, so key on the cap instead.
        was_truncated = len(content) > max_content_length
        content_chars = paged_slice_length(content, max_content_length, content_offset)

        payload["content"] = truncated_content
        if mime:
            payload["content_type"] = mime
        if offset_applied:
            payload["content_offset"] = content_offset
            payload["total_chars"] = total_length
            if offset_past_end:
                payload["content_offset_past_end"] = True
        if was_truncated or offset_applied:
            payload["_truncated"] = was_truncated
            payload["_total_chars"] = total_length
            payload["_content_chars"] = content_chars
        return payload, True

    def _get_entry_content_direct(
        self,
        archive: Archive,
        actual_path: str,
        requested_path: str,
        max_content_length: int,
        content_offset: int = 0,
        *,
        compact: bool = False,
    ) -> Tuple[str, bool, str]:
        """Get entry content using the actual path from the ZIM file.

        Thin text presenter over ``_build_entry_payload`` — the payload
        builder is the single source of truth for redirect resolution,
        compact link-stripping, and offset/truncation accounting, so the
        text and structured surfaces cannot drift (the D7 M/-routing bug
        happened exactly because a fix landed in only one copy).

        Args:
            archive: ZIM archive instance
            actual_path: The actual path as it exists in the ZIM file
            requested_path: The originally requested path (for display)
            max_content_length: Maximum content length
            content_offset: Character offset to start reading from

        Returns:
            ``(result_text, content_ok, resolved_path)`` where
            ``content_ok`` is False when MIME processing raised and the
            body holds the ``(Error retrieving content: ...)`` sentinel,
            and ``resolved_path`` is the path of the resolved target after
            following any redirect chain (equal to ``actual_path`` when
            ``actual_path`` itself was not a redirect).
        """
        payload, content_ok, resolved_path = self._build_entry_payload(
            archive,
            actual_path,
            requested_path,
            max_content_length,
            content_offset,
            compact=compact,
        )
        return _render_entry_payload_text(payload), content_ok, resolved_path

    def get_binary_entry_data(  # NOSONAR(python:S3776)
        self,
        zim_file_path: str,
        entry_path: str,
        max_size_bytes: Optional[int] = None,
        include_data: bool = True,
    ) -> "BinaryEntryResponse":
        """Structured variant of ``get_binary_entry``.

        Returns the result dict directly (not a JSON string) so MCP tools
        can hand it straight to the SDK's structured-content path. The
        ``data`` field, when populated, remains a base64-encoded string.

        Args:
            zim_file_path: Path to the ZIM file
            entry_path: Entry path, e.g., 'I/image.png' or 'C/document.pdf'
            max_size_bytes: Maximum size of content to return (default: 10MB)
            include_data: If True, include base64-encoded data; if False, metadata only

        Returns:
            Dict containing binary content metadata and optionally the data

        Raises:
            OpenZimMcpFileNotFoundError: If ZIM file not found
            OpenZimMcpArchiveError: If entry retrieval fails
        """
        from openzim_mcp.constants import DEFAULT_MAX_BINARY_SIZE

        if max_size_bytes is None:
            max_size_bytes = DEFAULT_MAX_BINARY_SIZE

        entry_path = normalize_entry_path(entry_path)
        reject_path_traversal(entry_path)

        # Validate and resolve file path
        validated_path = self._validate_zim_path(zim_file_path)

        # Cache key for invariant metadata (size, mime_type, etc.) — not data,
        # since data is potentially large and varies with max_size_bytes.
        # The stat token guarantees that an atomic ZIM replacement
        # invalidates stale metadata (e.g. a thumbnail entry whose
        # mimetype/size changed between archive revisions).
        from openzim_mcp.bundle import archive_stat_token

        cache_key = (
            f"binary_meta:{validated_path}:"
            f"{archive_stat_token(validated_path)}:{entry_path}"
        )

        # If we already know the entry's metadata, we can short-circuit calls
        # that don't need bytes (include_data=False) or that would be rejected
        # for being over the size limit. include_data=True under the limit still
        # requires opening the archive to read the bytes.
        cached_meta = self.cache.get(cache_key)
        if cached_meta and (not include_data or cached_meta["size"] > max_size_bytes):
            logger.debug(f"Returning cached binary metadata for: {entry_path}")
            payload = self._format_binary_response(
                cached_meta, include_data, max_size_bytes, data=None
            )
            return cast(
                "BinaryEntryResponse",
                attach_meta(payload, truncated=payload.get("truncated", False)),
            )

        try:
            with _zim_ops_mod.zim_archive(validated_path) as archive:
                # The synthetic ``W/favicon`` row browse publishes. The
                # illustration is an Item reached through
                # ``get_illustration_item``, not an Entry with a path, so the
                # ordinary lookup below can never find it — which is why the
                # path browse advertises used to 404. It carries the same
                # size/mimetype/content surface an Item from ``get_item()``
                # does, so everything downstream serves it unchanged.
                if entry_path == "W/favicon" and getattr(
                    archive, "has_new_namespace_scheme", False
                ):
                    item = self._resolve_well_known_illustration(archive)
                    entry_title = "favicon"
                    content_size = item.size
                    meta = {
                        "path": entry_path,
                        "title": entry_title,
                        "mime_type": item.mimetype or "image/png",
                        "size": content_size,
                        "size_human": self._format_size(content_size),
                    }
                    illustration_data: Optional[str] = None
                    if include_data and content_size <= max_size_bytes:
                        illustration_data = base64.b64encode(
                            bytes(item.content)
                        ).decode("ascii")
                    self.cache.set(cache_key, meta)
                    payload = self._format_binary_response(
                        meta, include_data, max_size_bytes, data=illustration_data
                    )
                    return cast(
                        "BinaryEntryResponse",
                        attach_meta(payload, truncated=payload.get("truncated", False)),
                    )

                # Try direct access first
                try:
                    entry = archive.get_entry_by_path(entry_path)
                except Exception:
                    # Fall back to search-based retrieval
                    actual_path = self._find_entry_by_search(archive, entry_path)
                    if actual_path:
                        entry = archive.get_entry_by_path(actual_path)
                        entry_path = actual_path
                    else:
                        raise OpenZimMcpEntryNotFoundError(
                            f"Entry not found: '{entry_path}'. "
                            + locate_or_explore(self.config.tool_mode)
                        )

                # Resolve the redirect chain — libzim raises RuntimeError on
                # get_item() of a redirect entry. Reflect the resolved path
                # back into entry_path so the response identifies the entry
                # actually served, matching _get_entry_content_direct. Only
                # rewrite entry_path when a redirect was actually followed
                # (the resolver returns the same object on a direct hit), so
                # a non-redirect lookup keeps the caller's original path.
                resolved = resolve_redirect_chain(entry, context=f"for: '{entry_path}'")
                if resolved is not entry:
                    entry = resolved
                    entry_path = entry.path

                item = entry.get_item()
                entry_title = entry.title or "Untitled"

                content_size = item.size
                meta = {
                    "path": entry_path,
                    "title": entry_title,
                    "mime_type": item.mimetype or "application/octet-stream",
                    "size": content_size,
                    "size_human": self._format_size(content_size),
                }

                # Read bytes only when we'll actually serve them — item.content
                # decompresses the entire entry into memory.
                encoded_data: Optional[str] = None
                if include_data and content_size <= max_size_bytes:
                    raw_content = bytes(item.content)
                    encoded_data = base64.b64encode(raw_content).decode("ascii")

                # Cache invariant metadata for future calls.
                self.cache.set(cache_key, meta)

                payload = self._format_binary_response(
                    meta, include_data, max_size_bytes, data=encoded_data
                )
                result = cast(
                    "BinaryEntryResponse",
                    attach_meta(payload, truncated=payload.get("truncated", False)),
                )
                logger.info(
                    f"Retrieved binary entry: {entry_path} "
                    f"({meta['mime_type']}, {self._format_size(content_size)})"
                )
                return result

        except OpenZimMcpArchiveError:
            raise
        except Exception as e:
            logger.error(f"Binary entry retrieval failed for {entry_path}: {e}")
            raise OpenZimMcpArchiveError(f"Failed to retrieve binary entry: {e}") from e

    def get_binary_entry(
        self,
        zim_file_path: str,
        entry_path: str,
        max_size_bytes: Optional[int] = None,
        include_data: bool = True,
    ) -> str:
        """Legacy JSON-string variant of ``get_binary_entry_data``.

        Retrieve binary content from a ZIM entry.

        This method returns raw binary content encoded in base64, enabling
        integration with external tools for processing embedded media like
        PDFs, videos, and images.

        Args:
            zim_file_path: Path to the ZIM file
            entry_path: Entry path, e.g., 'I/image.png' or 'C/document.pdf'
            max_size_bytes: Maximum size of content to return (default: 10MB)
            include_data: If True, include base64-encoded data; if False, metadata only

        Returns:
            JSON string containing binary content metadata and optionally the data

        Raises:
            OpenZimMcpFileNotFoundError: If ZIM file not found
            OpenZimMcpArchiveError: If entry retrieval fails
        """
        return _json(
            self.get_binary_entry_data(
                zim_file_path, entry_path, max_size_bytes, include_data
            )
        )

    def _format_binary_response(
        self,
        meta: Dict[str, Any],
        include_data: bool,
        max_size_bytes: int,
        data: Optional[str],
    ) -> Dict[str, Any]:
        """Build the response dict for get_binary_entry from cached/fresh metadata."""
        result: Dict[str, Any] = dict(meta)
        size = meta["size"]
        if include_data:
            if size <= max_size_bytes and data is not None:
                result["encoding"] = "base64"
                result["data"] = data
                result["truncated"] = False
            else:
                result["encoding"] = None
                result["data"] = None
                result["truncated"] = True
                # Name the knob the caller can actually turn: zim_get maps
                # ``max_content_length`` onto this byte cap and never exposes
                # ``include_data`` / ``max_size_bytes``, so the old hint sent
                # callers to parameters the tool silently ignores.
                #
                # ...but only when turning it would work. ``zim_get`` refuses
                # a ``max_content_length`` above
                # ``CONTENT.MAX_BINARY_CONTENT_LENGTH``, so for a bigger entry
                # this used to name a number the very next call rejects, whose
                # rejection sends the caller back to a cap that produces this
                # message again — a closed loop of the server's own advice.
                # Past the ceiling there is no in-protocol fetch to advertise,
                # so say that instead of inventing one.
                from ..defaults import CONTENT as _CONTENT

                head = (
                    f"Content size ({self._format_size(size)}) exceeds the "
                    f"{self._format_size(max_size_bytes)} byte cap. The metadata "
                    f"above is complete; "
                )
                if size > _CONTENT.MAX_BINARY_CONTENT_LENGTH:
                    result["message"] = head + (
                        "this entry is past the "
                        f"{_CONTENT.MAX_BINARY_CONTENT_LENGTH:,}-byte ceiling on "
                        "a binary fetch, which ships as one base64 line with no "
                        "continuation, so no `max_content_length` will return "
                        "it — read the file outside the MCP surface."
                    )
                else:
                    result["message"] = head + (
                        f"raise max_content_length to at least {size} to fetch "
                        "the bytes."
                    )
        else:
            result["encoding"] = None
            result["data"] = None
            result["truncated"] = False
            result["message"] = "Data not included (include_data=False)"
        return result

    def _format_size(self, size_bytes: int) -> str:
        """Format size in bytes to human-readable string."""
        if size_bytes < 1024:
            return f"{size_bytes} B"
        elif size_bytes < 1024 * 1024:
            return f"{size_bytes / 1024:.2f} KB"
        elif size_bytes < 1024 * 1024 * 1024:
            return f"{size_bytes / (1024 * 1024):.2f} MB"
        else:
            return f"{size_bytes / (1024 * 1024 * 1024):.2f} GB"

    def get_entry_summary_data(
        self,
        zim_file_path: str,
        entry_path: str,
        max_words: int = 200,
        *,
        compact: bool = False,
    ) -> "EntrySummaryResponse":
        """Structured variant of ``get_entry_summary``.

        Returns the result dict directly (not a JSON string) so MCP tools
        can hand it straight to the SDK's structured-content path.

        Raises:
            OpenZimMcpFileNotFoundError: If ZIM file not found
            OpenZimMcpArchiveError: If summary extraction fails
        """
        # Clamp to a sane upper bound; the tool layer enforces the
        # documented [1, 1000] range, so we don't impose a silent floor
        # here (callers asking for max_words=1 should get one word, not
        # ten).
        if max_words < 1:
            max_words = 1
        elif max_words > 1000:
            max_words = 1000

        entry_path = normalize_entry_path(entry_path)
        reject_path_traversal(entry_path)

        # Validate and resolve file path
        validated_path = self._validate_zim_path(zim_file_path)

        try:
            with _zim_ops_mod.zim_archive(validated_path) as archive:
                preset, applied_type = self._resolve_preset_for_open_archive(
                    archive, str(validated_path)
                )
                summary_style = preset.summary_style if preset is not None else None
                result = self._extract_entry_summary_data(
                    archive,
                    entry_path,
                    max_words,
                    compact=compact,
                    validated_path=validated_path,
                    summary_style=summary_style,
                )

            logger.info(f"Extracted summary for: {entry_path}")
            return cast(
                "EntrySummaryResponse",
                attach_meta(
                    result,
                    truncated=bool(result.get("is_truncated")),
                    preset_applied=applied_type,
                ),
            )

        except Exception as e:
            logger.error(f"Summary extraction failed for {entry_path}: {e}")
            raise OpenZimMcpArchiveError(f"Summary extraction failed: {e}") from e

    def get_entry_summary(
        self,
        zim_file_path: str,
        entry_path: str,
        max_words: int = 200,
        *,
        compact: bool = False,
    ) -> str:
        """Legacy JSON-string variant of ``get_entry_summary_data``.

        Get a concise summary of an article without returning the full content.

        This method extracts the opening paragraph(s) or introduction section,
        providing a quick overview of the article content. Useful for getting
        context without loading full articles.

        Args:
            zim_file_path: Path to the ZIM file
            entry_path: Entry path, e.g., 'C/Some_Article'
            max_words: Maximum number of words in the summary (default: 200)

        Returns:
            JSON string containing the article summary

        Raises:
            OpenZimMcpFileNotFoundError: If ZIM file not found
            OpenZimMcpArchiveError: If summary extraction fails
        """
        return _json(
            self.get_entry_summary_data(
                zim_file_path, entry_path, max_words, compact=compact
            )
        )

    def _extract_entry_summary_data(
        self,
        archive: Archive,
        entry_path: str,
        max_words: int,
        *,
        compact: bool = False,
        validated_path: Optional[Path] = None,
        summary_style: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Extract summary from article content as a dict.

        For HTML entries the bundle is used so that parsing is shared with
        the other Phase C tools.  Non-HTML entries fall back to direct
        content reading (the bundle stores empty rendered_markdown for them).
        """
        from openzim_mcp.bundle import get_or_build_bundle

        try:
            # Peek at the MIME type first to decide the path.
            entry, entry_path = self._resolve_entry_with_fallback(archive, entry_path)
            item = entry.get_item()
            mime_type = item.mimetype or ""

            if mime_type.startswith("text/html"):
                # HTML path — build (or reuse) the bundle and slice it.
                # H13: the bundle is rendered with ``compact=True`` semantics
                # (see openzim_mcp/bundle.py:_render_soup_to_text call),
                # so it's safe to serve compact-mode callers from it. The
                # prior code bypassed the bundle for ``compact=True`` based
                # on a stale assumption that bundle markdown was verbose;
                # the bypass forced an extra HTML parse and a different
                # rendering path, producing different markdown for the same
                # article when fetched via ``get_entry_summary`` vs
                # ``get_section``. Keep the ``validated_path is None``
                # fallback for tests that monkeypatch the path validator.
                if validated_path is None:
                    raw_content = bytes(item.content).decode("utf-8", errors="replace")
                    html_result = self._extract_html_summary(
                        raw_content, max_words, compact=compact
                    )
                    return {
                        "title": entry.title or "Untitled",
                        "path": entry_path,
                        "content_type": mime_type,
                        **html_result,
                    }

                bundle = get_or_build_bundle(
                    archive,
                    entry_path,
                    cache=self.cache,
                    validated_path=validated_path,
                    content_processor=self.content_processor,
                )
                md = bundle["rendered_markdown"]
                summary_md = _select_summary_section_md(
                    bundle["sections"], md, summary_style
                )

                words = summary_md.split()
                is_truncated = len(words) > max_words
                if is_truncated:
                    summary_md = _truncate_markdown_words(summary_md, max_words)

                return {
                    "path": bundle["entry_path"],
                    "title": bundle["title"],
                    "summary": summary_md,
                    "word_count": min(len(words), max_words),
                    "content_type": bundle["content_type"],
                    "is_truncated": is_truncated,
                }

            elif mime_type.startswith(_TEXT_MIME_PREFIX):
                # For plain text, take first N words
                title = entry.title or "Untitled"
                raw_content = bytes(item.content).decode("utf-8", errors="replace")
                plain_text = raw_content.strip()
                words = plain_text.split()
                summary: str
                is_trunc: bool
                if len(words) > max_words:
                    summary = " ".join(words[:max_words]) + "..."
                    is_trunc = True
                else:
                    summary = plain_text
                    is_trunc = False
                return {
                    "title": title,
                    "path": entry_path,
                    "content_type": mime_type,
                    "summary": summary,
                    "word_count": min(len(words), max_words),
                    "is_truncated": is_trunc,
                }
            else:
                title = entry.title or "Untitled"
                return {
                    "title": title,
                    "path": entry_path,
                    "content_type": mime_type,
                    "summary": f"(Non-text content: {mime_type})",
                    "word_count": 0,
                    "is_truncated": False,
                }

        except OpenZimMcpArchiveError:
            raise
        except Exception as e:
            logger.error(f"Error extracting summary for {entry_path}: {e}")
            raise OpenZimMcpArchiveError(
                f"Failed to extract article summary: {e}"
            ) from e

    def _extract_html_summary(  # NOSONAR(python:S3776)
        self, html_content: str, max_words: int, *, compact: bool = False
    ) -> Dict[str, Any]:
        """Extract summary from HTML content.

        Prioritizes:
        1. Paragraphs AFTER the first H1 (skips skip-nav and site banners
           that always sit above the title).
        2. Content of any <p> tags as fallback (with chrome stripped).
        3. Any text content as final fallback.

        Errors propagate to the caller so a transient parse failure is not
        cached as a permanent ``"(Error extracting summary)"`` sentinel for
        the full TTL. ``get_entry_summary`` translates the exception into a
        user-facing ``Summary extraction failed`` error response.
        """
        from bs4 import BeautifulSoup, Tag

        result: Dict[str, Any] = {
            "summary": "",
            "word_count": 0,
            "is_truncated": False,
        }

        soup = BeautifulSoup(html_content, "html.parser")

        # Remove navigation, sidebars, infoboxes, banners, etc.
        unwanted_selectors = [
            "nav",
            "header",
            "footer",
            "aside",
            "script",
            "style",
            "noscript",
            "form",
            # Wikipedia / MediaWiki chrome
            ".infobox",
            ".navbox",
            ".sidebar",
            ".toc",
            ".mw-editsection",
            ".reference",
            ".reflist",
            "#coordinates",
            ".hatnote",
            ".mbox",
            ".ambox",
            ".metadata",
            # USWDS / federal-site banners (MedlinePlus, NIH, NIST...)
            ".usa-banner",
            ".usa-overlay",
            ".usa-skipnav",
            "#skipnav",
            "#skipNav",
            "[role='banner']",
            "[role='navigation']",
        ]
        for selector in unwanted_selectors:
            for element in soup.select(selector):
                element.decompose()

        # Prefer paragraphs that come AFTER the first H1 — site banners,
        # cookie notices, and "skip to content" blocks always sit above
        # the document title and pollute summaries when collected naively.
        first_h1 = soup.find("h1")
        paragraph_iter: List[Tag] = []
        if isinstance(first_h1, Tag):
            paragraph_iter = [
                p for p in first_h1.find_all_next("p") if isinstance(p, Tag)
            ]
        if not paragraph_iter:
            paragraph_iter = [p for p in soup.find_all("p") if isinstance(p, Tag)]

        paragraphs = []
        for p in paragraph_iter:
            text = p.get_text().strip()
            # Skip very short paragraphs (likely captions or labels)
            if len(text) > 50:
                paragraphs.append(text)
                total_words = sum(len(para.split()) for para in paragraphs)
                if total_words >= max_words:
                    break

        if paragraphs:
            # Combine paragraphs and truncate to max_words
            combined = " ".join(paragraphs)
            words = combined.split()

            if len(words) > max_words:
                result["summary"] = " ".join(words[:max_words]) + "..."
                result["is_truncated"] = True
                result["word_count"] = max_words
            else:
                result["summary"] = combined
                result["word_count"] = len(words)
        else:
            # Fallback: use html2text to get any text
            plain_text = self.content_processor.html_to_plain_text(
                html_content, compact=compact
            )
            words = plain_text.split()

            if len(words) > max_words:
                result["summary"] = " ".join(words[:max_words]) + "..."
                result["is_truncated"] = True
                result["word_count"] = max_words
            else:
                result["summary"] = plain_text
                result["word_count"] = len(words)

        return result
