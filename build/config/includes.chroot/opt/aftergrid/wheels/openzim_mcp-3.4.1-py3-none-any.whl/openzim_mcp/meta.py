"""Response metadata helpers — `_meta` envelope, footer, token estimation.

Phase A item #5 (token & char metadata). The `_meta` envelope ships on
every dict-returning tool; the footer renders a one-line markdown
summary on prose-returning tools in compact mode. Token estimates use
tiktoken's cl100k_base encoding as a model-agnostic budget signal —
not exact for any specific model, but close enough for context
budgeting across Anthropic, OpenAI, and Llama tokenizers.
"""

from __future__ import annotations

import functools
import json as _json
import logging
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


@functools.lru_cache(maxsize=1)
def _get_encoder() -> Any:
    """Lazy tokenizer accessor.

    H21: ``lru_cache(maxsize=1)`` replaces the previous ``_EncoderCache``
    class with its unguarded check-then-set on shared mutable state.
    ``lru_cache`` is implemented in C, holds its own lock around cache
    population, and returns the same instance on every call — so two
    concurrent ``asyncio.to_thread`` workers calling this on first-use
    no longer race to write the encoder.

    Returns the tiktoken encoder, or ``None`` if init failed (sandboxed
    envs without a writable BPE cache). Callers that need to distinguish
    "tokenizer unavailable" from "zero tokens" inspect the return value
    directly via ``_raw_tokens_est``.
    """
    try:
        import tiktoken

        return tiktoken.get_encoding("cl100k_base")
    except Exception as e:  # pragma: no cover — defensive; sandboxed envs
        logger.warning(
            "tiktoken init failed; tokens_est will be omitted from _meta "
            "envelopes for this session: %s",
            e,
        )
        return None


# Above this many characters, ``tokens_est`` is extrapolated from bounded
# samples instead of encoding the whole string.
#
# v3.3.1 field report (fid 124): ``attach_meta`` json.dumps's the whole
# payload and hands it to tiktoken unconditionally, base64 ``data`` field
# included. On the DEFAULT binary path (a 9.9 MB entry, no unusual arguments)
# that is 1.4 s and +240 MB of RSS; raise ``max_content_length`` and it
# becomes 7.5 s and +1.25 GB, producing a 51-million-element token list — to
# compute an advisory number that gates nothing and whose only content is
# "this response is unusable". cl100k costs roughly 0.1 s and ~20x the
# string's size in peak RSS per megabyte, so 200 KB is ~20 ms and is where
# exactness stops being worth paying for.
_EXACT_TOKENISE_LIMIT = 200_000
# Three windows (head / middle / tail) rather than one prefix, so a payload
# that mixes prose and a base64 blob is not estimated entirely from whichever
# of the two happens to start it.
_TOKENISE_SAMPLE_WINDOW = 32_000


def _sampled_tokens_est(encoder: Any, rendered: str) -> int:
    """Extrapolate a token count from bounded samples of ``rendered``.

    Sampling rather than a flat chars/N divisor because the divisor is not
    a constant across content types: cl100k averages ~4 chars per token on
    English prose but ~1.4 on base64, so a chars/4 estimate under-reports a
    media payload by ~3x — in the direction that causes context overflow.
    Encoding a sample measures the ratio for the content actually present at
    a cost that does not grow with the payload.
    """
    total = len(rendered)
    window = _TOKENISE_SAMPLE_WINDOW
    middle = (total - window) // 2
    samples = [
        rendered[:window],
        rendered[middle : middle + window],
        rendered[-window:],
    ]
    sampled_chars = sum(len(s) for s in samples)
    sampled_tokens = sum(len(encoder.encode(s, disallowed_special=())) for s in samples)
    if sampled_chars == 0:  # pragma: no cover — total > limit implies chars
        return 0
    return int(sampled_tokens * (total / sampled_chars))


def _raw_tokens_est(rendered: str) -> Optional[int]:
    """Tokenize ``rendered``. Returns ``None`` when the tokenizer is
    unavailable or the encode fails, so callers can distinguish
    "couldn't estimate" from "zero tokens" — spec §5 requires omitting
    ``tokens_est`` on tiktoken init failure rather than emitting a
    misleading 0.

    Payloads above :data:`_EXACT_TOKENISE_LIMIT` are estimated from bounded
    samples; see the constant.
    """
    if not rendered:
        return 0
    encoder = _get_encoder()
    if encoder is None:
        return None
    try:
        # ``disallowed_special=()`` treats cl100k_base's special-token
        # literals (``<|endoftext|>`` and friends) as ordinary text.
        # tiktoken's default would raise on them, and they occur naturally
        # in article bodies and user queries about tokenizers — a
        # best-effort budget estimate must never fail the tool call.
        if len(rendered) > _EXACT_TOKENISE_LIMIT:
            return _sampled_tokens_est(encoder, rendered)
        return len(encoder.encode(rendered, disallowed_special=()))
    except Exception as e:
        logger.warning("token estimation failed; omitting tokens_est: %s", e)
        return None


def tokens_est(rendered: str) -> int:
    """Estimate the token count of a rendered string using cl100k_base.

    Returns 0 on empty input and 0 when the tokenizer is unavailable —
    the public helper preserves the legacy int return; envelope builders
    that need the "unavailable" signal call :func:`_raw_tokens_est`.
    """
    raw = _raw_tokens_est(rendered)
    return raw if raw is not None else 0


def build_meta(
    *,
    rendered: str,
    total_chars: Optional[int] = None,
    current_offset: int = 0,
    content_chars: Optional[int] = None,
    truncated: bool = False,
    suggestions: Optional[List[Dict[str, str]]] = None,
    reason: Optional[str] = None,
    detected_type: Optional[str] = None,
    detection_confidence: Optional[str] = None,
    preset_applied: Optional[str] = None,
) -> Dict[str, Any]:
    """Construct a `_meta` envelope for a tool response.

    Always emits `tokens_est` (with a 5% pad to cover envelope cost),
    `chars`, `truncated`. Conditionally emits `more_at_offset`,
    `total_chars`, `suggestions`, `reason`,
    `detected_type`, `detection_confidence`, `preset_applied`.

    ``content_chars`` is the byte length of the *paginable content slice*
    in the response (e.g. ``len(payload["content"])`` for get_zim_entry).
    When set together with ``truncated``, drives ``more_at_offset =
    current_offset + content_chars`` — i.e. the offset a caller would
    use to fetch the next page. When omitted, ``more_at_offset`` is not
    emitted: tools whose ``truncated`` means "value omitted, no
    continuation" (binary cap, section-content cap, summary word cap)
    must leave it ``None``.
    """
    chars = len(rendered)
    raw_tokens = _raw_tokens_est(rendered)

    meta: Dict[str, Any] = {
        "chars": chars,
        "truncated": truncated,
    }
    # Spec §5: omit ``tokens_est`` when the tokenizer is unavailable so
    # models can distinguish "zero-token response" from "tokenizer
    # unavailable". A non-None raw count (including 0 for empty input)
    # populates the field; ``None`` skips it. The previous version's
    # ``... if raw_tokens else 0`` collapsed the rare "non-empty payload
    # that BPE tokenizes to 0 tokens" case into a misleading ``0`` — drop
    # that special-case so the +5% pad + minimum 1 applies uniformly.
    if raw_tokens is not None:
        if raw_tokens == 0 and not rendered:
            meta["tokens_est"] = 0
        else:
            meta["tokens_est"] = int(raw_tokens * 1.05) + 1
    if truncated:
        if content_chars is not None:
            meta["more_at_offset"] = current_offset + content_chars
        if total_chars is not None:
            meta["total_chars"] = total_chars
    if suggestions:
        meta["suggestions"] = suggestions
    if reason is not None:
        meta["reason"] = reason
    if detected_type is not None:
        meta["detected_type"] = detected_type
    if detection_confidence is not None:
        meta["detection_confidence"] = detection_confidence
    if preset_applied is not None:
        meta["preset_applied"] = preset_applied
    return meta


def _humanize_count(n: int) -> str:
    """Format an integer as ~XK with one decimal for K-scale, integer otherwise."""
    if n < 1000:
        return str(n)
    k = n / 1000
    if k < 10:
        return f"{k:.1f}K"
    return f"{int(k)}K"


def format_footer(
    meta: Dict[str, Any], *, footer_enabled: bool, tool_mode: str = "simple"
) -> str:
    """Render a one-line markdown blockquote footer from a `_meta` envelope.

    ``tool_mode`` selects which recovery advice the footer may give, on the
    same principle :func:`openzim_mcp.instructions.instructions_for` applies
    to the server instructions: naming a tool the client cannot see is worse
    than naming none. The only caller is the ``zim_query`` response path
    (``simple_tools.py``), and ``zim_query`` is registered in BOTH modes —
    so an advice string written for the advanced tool set reaches simple-mode
    clients, where ``zim_query`` is the only registered tool, unchanged.

    Advanced-mode advice therefore names the v2 tool. Simple-mode advice is
    phrased as a query ``intent_parser.IntentParser`` actually recognises
    (``find article titled X``, ``list namespaces``, ``walk namespace X``) —
    a plain-English paraphrase is worse than useless, because it parses as a
    literal search for its own text.

    The default is the fail-safe mode: a caller that forgets to thread
    ``tool_mode`` degrades to a zim_query-shaped instruction rather than to
    an uncallable tool name.
    """
    if not footer_enabled or not meta:
        return ""

    reason = meta.get("reason")
    # Any structured reason on an empty/low-confidence response shapes the
    # footer as a recovery hint instead of the token-budget summary.
    # Without this, archives lacking a full-text index (``no_xapian_index``)
    # or invalid-namespace responses (``bad_namespace``) fall through to a
    # "~0 tokens" line that gives small models no actionable signal.
    #
    # Op4: expanded reason taxonomy.
    # - ``low_relevance`` (H9): Xapian found hits but none token-match the
    #   query — same recovery prose as 0_hits.
    # - ``sample_only`` (C2): the page came from a sampled discovery and
    #   more entries remain even though ``done=True``. Tells the model
    #   to pivot to walk-mode browsing for exhaustive iteration.
    # - ``archive_unavailable`` (H10): every per-file archive failed in a
    #   fan-out (search_all) — the issue is infrastructural, not the query.
    # - ``search_all_budget_exceeded`` (H22): the aggregate timeout fired
    #   before all archives were searched; partial results returned.
    if reason in {
        "0_hits",
        "low_relevance",
        "bad_query",
        "no_xapian_index",
        "bad_namespace",
        "no_content_type_match",
        "sample_only",
        "archive_unavailable",
        "search_all_budget_exceeded",
        "namespace_not_iterable",
    }:
        suggestions = meta.get("suggestions") or []
        visible = suggestions[:3]
        if not visible:
            advanced = tool_mode == "advanced"
            if reason == "no_xapian_index":
                return "> No full-text index on this archive. " + (
                    "Try `zim_search(mode='title')` or `zim_browse`."
                    if advanced
                    else "Ask for `find article titled <title>` or "
                    "`browse namespace C` — neither needs the index."
                )
            if reason == "bad_namespace":
                return "> Unknown namespace. " + (
                    "Try `zim_metadata` to see valid options."
                    if advanced
                    else "Ask for `list namespaces` to see valid options."
                )
            if reason == "no_content_type_match":
                return (
                    "> No full-text-indexed entries match that content type. "
                    "Binary assets (images, media) aren't in the search index — "
                    + (
                        "use `zim_browse` (include_assets=True) to discover "
                        "them, or drop the `content_type` filter."
                        if advanced
                        else "ask again without the `content_type` filter. "
                        "This tool cannot discover assets, but `get binary "
                        "content of <path>` fetches one you can already name."
                    )
                )
            if reason == "namespace_not_iterable":
                # v3.3.1 field report (fid 80 audit residue). The data layer
                # separates "this namespace holds nothing" from "this
                # namespace is real but not on this archive's iterable
                # surface" — and then this footer, gating on a closed set
                # this code was never added to, rendered both as the same
                # token-budget line. A verdict nothing renders is a verdict
                # nobody acts on. Distinct prose from ``bad_namespace``: the
                # namespace is not the caller's mistake here.
                return (
                    "> That namespace exists but this archive does not "
                    "enumerate it. "
                    + (
                        "Try `zim_browse(mode='walk')`, which scans entry ids "
                        "directly."
                        if advanced
                        else "Ask for `walk namespace <namespace>`, which "
                        "scans entry ids directly."
                    )
                )
            if reason == "sample_only":
                return "> Sampled view only — more entries remain. " + (
                    "Use `zim_browse(mode='walk')` for exhaustive iteration."
                    if advanced
                    else "Ask for `walk namespace <namespace>` for exhaustive "
                    "iteration."
                )
            if reason == "archive_unavailable":
                return "> All archives failed to respond. " + (
                    "Check `zim_health` and server logs."
                    if advanced
                    else "That is a server-side failure, not the query — "
                    "retry shortly, or ask an operator to check the logs."
                )
            if reason == "search_all_budget_exceeded":
                return (
                    "> Search-all aggregate timeout fired before every archive "
                    "was probed. Narrow the query or raise "
                    "`OPENZIM_MCP_SEARCH__SEARCH_ALL_TOTAL_TIMEOUT_SECONDS`."
                )
            if reason == "low_relevance":
                # v3.3.1 field report: this branch used to fall through to the
                # ``0_hits`` prose below, so a response that DID return hits
                # was footed with "No results." — false in the other
                # direction. ``low_relevance`` means Xapian matched something
                # but no hit token-matches the query, so the rows above are
                # real and probably not what was asked for.
                return "> These matches look weak — no result matches your " + (
                    "search terms directly. Try `zim_search(mode='title')` "
                    "for an exact-title lookup, or rephrase."
                    if advanced
                    else "search terms directly. Ask for `find article titled "
                    "<title>` for an exact-title lookup, or rephrase."
                )
            return "> No results. Try a shorter or differently-spelled query."
        bits: List[str] = []
        for item in visible:
            t = item.get("type")
            v = item.get("value", "")
            if t == "alt_spelling":
                bits.append(f"`suggestions for {v}`")
            elif t == "alt_archive":
                bits.append(f"or try ZIM `{v}`")
            elif t == "broader":
                bits.append(f"`search {v}` (broader)")
            elif t == "narrower":
                bits.append(f"`search {v}` (narrower)")
            elif t == "cross_intent_tell_me_about":
                # Post-v2.0.5 D-L: structured-topic-lookup escape
                # hatch injected by the simple-mode search handler
                # so compact-mode callers see the same
                # ``tell me about X`` cross-intent nudge that the
                # non-compact ``_format_search_text`` body emits
                # (``zim/search.py:779``). Distinct type so the
                # handler can append it without colliding with
                # backend-derived suggestion types.
                bits.append(f"`tell me about {v}`")
            else:
                bits.append(f"`{v}`")
        return "> No results. Try: " + " · ".join(bits)

    # ``tokens_est`` may be absent when the tokenizer is unavailable (spec
    # §5); fall back to char-count so the footer still gives the model a
    # budget signal instead of crashing on KeyError.
    parts: List[str] = []
    if "tokens_est" in meta:
        parts.append(f"~{_humanize_count(meta['tokens_est'])} tokens")
    else:
        parts.append(f"~{_humanize_count(meta.get('chars', 0))} chars")
    if meta.get("truncated"):
        chars_label = _humanize_count(meta["chars"])
        total_label = _humanize_count(meta.get("total_chars", meta["chars"]))
        parts.append(f"{chars_label} of {total_label} chars")
        # Op5 (v2.0.0a9): make the byte-offset semantics explicit.
        # ``more_at_offset`` is the byte offset to feed back as
        # ``content_offset`` on tools that paginate article bodies
        # (today: ``get_zim_entry``). Label it ``content_offset`` so
        # callers don't confuse it with the result-set ``offset`` used
        # by search/browse/walk.
        if "more_at_offset" in meta:
            parts.append(f"pass `content_offset={meta['more_at_offset']}` for more")
    return "> " + " · ".join(parts)


def remeasure(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Recompute an existing ``_meta``'s size fields after a late edit.

    ``chars`` and ``tokens_est`` are the only entries ``build_meta`` derives
    from the payload; everything else there is a verdict the caller supplied.
    So a tool that adds a field to a payload the data layer already measured
    can restate the size without having to reconstruct — and risk dropping —
    ``reason``, ``suggestions``, ``detected_type`` and the rest.

    This repo has fixed the stale-envelope bug twice by hand already
    (``_refresh_promotion_meta`` on the title path, ``_restamp_spliced_meta``
    on the splice path), each rebuilding the whole envelope from a
    hand-copied list of carried keys. A third open-coded copy is how one of
    those lists goes stale.

    A payload with no ``_meta`` is left alone: absence means the tool never
    published a size, not that it published a wrong one.
    """
    meta = payload.get("_meta")
    if not isinstance(meta, dict):
        return payload
    rendered = _json.dumps(
        {k: v for k, v in payload.items() if k != "_meta"},
        ensure_ascii=False,
    )
    meta["chars"] = len(rendered)
    raw_tokens = _raw_tokens_est(rendered)
    if raw_tokens is None:
        meta.pop("tokens_est", None)
    elif raw_tokens == 0 and not rendered:
        meta["tokens_est"] = 0
    else:
        meta["tokens_est"] = int(raw_tokens * 1.05) + 1
    return payload


def attach_meta(
    payload: Dict[str, Any],
    *,
    truncated: bool = False,
    total_chars: Optional[int] = None,
    current_offset: int = 0,
    content_chars: Optional[int] = None,
    suggestions: Optional[List[Dict[str, str]]] = None,
    reason: Optional[str] = None,
    rendered: Optional[str] = None,
    detected_type: Optional[str] = None,
    detection_confidence: Optional[str] = None,
    preset_applied: Optional[str] = None,
) -> Dict[str, Any]:
    """Attach a `_meta` envelope built from the JSON-rendered payload (sans _meta).

    Mutates and returns `payload`. Forwards build_meta kwargs.

    H23: ``rendered`` is an optional caller-supplied serialization of the
    payload. When omitted, we serialize via ``json.dumps`` here. Callers
    that already have a rendered form (e.g. a prose body about to ship as
    TextContent) can pass it through to avoid an extra full-payload JSON
    serialization on the hot path. For a typical Wikipedia search
    response (~50 KB payload, top-of-funnel) this was the single largest
    hot-path allocation outside libzim itself.

    Note: ``_meta.chars`` reflects the size of ``rendered`` (caller-supplied
    or default JSON-of-payload). Pagination is driven by ``content_chars``
    — pass the length of the paginable field (e.g. ``len(payload["content"])``)
    so ``more_at_offset`` is computed from content bytes, not envelope bytes.
    """
    if rendered is None:
        rendered = _json.dumps(
            {k: v for k, v in payload.items() if k != "_meta"},
            ensure_ascii=False,
        )
    payload["_meta"] = build_meta(
        rendered=rendered,
        truncated=truncated,
        total_chars=total_chars,
        current_offset=current_offset,
        content_chars=content_chars,
        suggestions=suggestions,
        reason=reason,
        detected_type=detected_type,
        detection_confidence=detection_confidence,
        preset_applied=preset_applied,
    )
    return payload
