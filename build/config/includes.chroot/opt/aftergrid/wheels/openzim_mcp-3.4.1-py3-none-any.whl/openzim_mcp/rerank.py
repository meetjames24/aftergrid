"""Cross-encoder reranking for :class:`SimpleToolsHandler`.

Extracted from ``simple_tools.py`` (post-v2.0.5 review sweep) as a mixin,
following the ``zim`` package's split of ``ZimOperations`` across
``_ContentMixin`` / ``_SearchMixin`` / etc.

Holds the Phase D sub-D-1 reranker telemetry event names and the methods
that drive the optional FastEmbed cross-encoder rerank (engaged only when
the ``[reranker]`` extra is installed). The event-name constants live here
rather than in ``simple_tools`` because both the rerank methods AND the core
``_track`` / ``handle_zim_query`` snapshot logic reference them — keeping
them next to the reranker logic and importing back avoids the circular
import that the reverse direction would create.
"""

import contextvars
from typing import TYPE_CHECKING, Any, Dict, List, Optional

from .constants import CANONICAL_TITLE_MATCH_SNIPPET
from .zim.search import demote_crawl_artefacts

# Names this module deliberately exports to ``simple_tools`` (the reranker
# telemetry contract + the mixin). Declaring it documents the cross-module
# export the docstring describes and tells static analysis these module-level
# constants are intentionally consumed elsewhere — notably
# ``_INFO_LEVEL_TELEMETRY_EVENTS``, whose only reader is ``simple_tools``.
__all__ = [
    "_INFO_LEVEL_TELEMETRY_EVENTS",
    "_RERANK_STATE_VAR",
    "_RERANKER_ENGAGED",
    "_RERANKER_SKIPPED_NO_RESULTS",
    "_RERANKER_SKIPPED_NOT_INSTALLED",
    "_RERANKER_SKIPPED_PASSTHROUGH",
    "_RerankMixin",
]

# Phase D sub-D-1 reranker telemetry events.
_RERANKER_ENGAGED = "reranker_engaged"
_RERANKER_SKIPPED_NOT_INSTALLED = "reranker_skipped.not_installed"
_RERANKER_SKIPPED_NO_RESULTS = "reranker_skipped.no_results"
_RERANKER_SKIPPED_PASSTHROUGH = "reranker_skipped.passthrough"

# Per-request reranker engagement state, recorded as the rerank actually
# runs. The in-band ``<!-- reranker=<state> -->`` marker reads this instead
# of diffing the process-wide telemetry Counter — the diff was racy (a
# concurrent request's event leaked into the delta) and mis-attributed
# (priority order surfaced an internal sub-search's ``no_results`` over the
# main search's real ``engaged``/``passthrough`` outcome), so the marker
# flapped for identical inputs. A ``ContextVar`` is isolated per request /
# async-context and records the LAST rerank outcome, which is the main
# search's. ``None`` means no rerank attempt (non-search intent).
_RERANK_STATE_VAR: "contextvars.ContextVar[Optional[str]]" = contextvars.ContextVar(
    "openzim_rerank_state", default=None
)

_RERANK_EVENT_LABELS = {
    _RERANKER_ENGAGED: "engaged",
    _RERANKER_SKIPPED_NOT_INSTALLED: "skipped:not_installed",
    _RERANKER_SKIPPED_NO_RESULTS: "skipped:no_results",
    _RERANKER_SKIPPED_PASSTHROUGH: "skipped:passthrough",
}

# Telemetry events that also emit an INFO log on every increment. The
# in-memory counter is only visible via ``get_server_health`` (advanced
# tool mode); operators running in simple mode have no other way to see
# reranker engagement. Keep this set small — every entry is a per-query
# INFO line.
_INFO_LEVEL_TELEMETRY_EVENTS: "frozenset[str]" = frozenset(
    {
        _RERANKER_ENGAGED,
        _RERANKER_SKIPPED_NOT_INSTALLED,
        _RERANKER_SKIPPED_NO_RESULTS,
        _RERANKER_SKIPPED_PASSTHROUGH,
    }
)


class _RerankMixin:
    """Cross-encoder rerank methods for ``SimpleToolsHandler``.

    The telemetry counter, ``_track`` and ``zim_operations`` are supplied
    by the concrete ``SimpleToolsHandler`` that mixes this in.
    """

    if TYPE_CHECKING:
        from collections import Counter

        from .zim_operations import ZimOperations

        zim_operations: "ZimOperations"
        _telemetry: "Counter[str]"

        def _track(self, event: str) -> None: ...

    def _record_rerank_event(self, event: str) -> None:
        """Record a reranker outcome: bump the process-wide telemetry
        Counter (for ``get_server_health``) AND stamp the per-request
        ``_RERANK_STATE_VAR`` (for the in-band marker)."""
        self._track(event)
        _RERANK_STATE_VAR.set(_RERANK_EVENT_LABELS.get(event))

    def _compute_rerank_state(
        self, before: Optional[Dict[str, int]] = None
    ) -> Optional[str]:
        """Return the per-request reranker engagement state for the
        ``<!-- reranker=<state> -->`` marker.

        Reads the per-request ``_RERANK_STATE_VAR`` (set by
        ``_record_rerank_event`` as the rerank runs) and consumes it so it
        can't leak into the next request. Returns one of ``engaged`` /
        ``skipped:not_installed`` / ``skipped:no_results`` /
        ``skipped:passthrough``, or ``None`` when no rerank was attempted
        (non-search intent).

        This replaces the previous process-wide telemetry-Counter diff,
        which made the marker non-deterministic for identical inputs: a
        concurrent request's increment leaked into the delta, and the
        priority order surfaced an internal sub-search's ``no_results`` over
        the main search's real outcome. ``before`` is accepted (and ignored)
        for backward compatibility with the old call signature.
        """
        state = _RERANK_STATE_VAR.get()
        _RERANK_STATE_VAR.set(None)
        return state

    def _maybe_rerank_compact(
        self,
        *,
        payload: Dict[str, Any],
        query: str,
        limit: Optional[int],
        results_key: str = "results",
    ) -> Dict[str, Any]:
        """Apply cross-encoder rerank to a compact-mode search payload.

        Reads ``payload[results_key]`` as the candidate list, reranks via
        ``BGEReranker.get()``, emits telemetry, and returns the payload with
        the reranked results. No-op when the [reranker] extra is absent
        or the result list is empty.

        Returns the payload (possibly the same dict, with results swapped).
        """
        from openzim_mcp.ml.reranker import BGEReranker

        reranker_cfg = self.zim_operations.config.ml.reranker
        reranker = BGEReranker.get(reranker_cfg)
        candidates = payload.get(results_key, [])

        if reranker is None:
            self._record_rerank_event(_RERANKER_SKIPPED_NOT_INSTALLED)
            return payload
        if not candidates:
            self._record_rerank_event(_RERANKER_SKIPPED_NO_RESULTS)
            return payload

        # Hold the canonical-splice row out of the comparison entirely.
        #
        # It does not come from the ranked stream — the title index put it
        # there — and it carries no snippet, only the sentinel placeholder.
        # ``BGEReranker.rerank`` scores ``snippet or path`` as the passage, so
        # leaving it in hands the cross-encoder that placeholder as if it were
        # article text. Against any real query it loses to every genuine hit
        # (measured -5.5 vs +4.6 on the shipped corpus), so the row the splice
        # exists to surface FIRST was sorted last and then cut off the page.
        # Pinning keeps it where the splice deliberately placed it.
        pinned = [
            c for c in candidates if c.get("snippet") == CANONICAL_TITLE_MATCH_SNIPPET
        ]
        rerankable = [
            c for c in candidates if c.get("snippet") != CANONICAL_TITLE_MATCH_SNIPPET
        ]
        if not rerankable:
            self._record_rerank_event(_RERANKER_SKIPPED_NO_RESULTS)
            return payload

        # Rerank REORDERS the page; it is never a second cap. Sizing the cut
        # from ``limit`` was safe only while ``len(candidates) == limit``. Since
        # the canonical splice stopped trimming, a spliced page ships
        # ``limit + 1`` rows, so a ``limit``-sized cut deleted one — restoring,
        # one statement after the splice, the very unreachable-row defect that
        # change removed (``page_info``/``next_cursor`` still describe the full
        # page, so the rendered footer advances past the cut row). Size the cut
        # from the list actually handed to us instead; ``limit`` is already
        # honoured by whoever built the page.
        effective_top_k = len(rerankable)

        reranked = reranker.rerank(
            query=query,
            candidates=rerankable,
            top_k=effective_top_k,
        )
        # BGEReranker.rerank's skip paths (the short-query gate and the
        # inference-failure passthrough) return ``candidates[:top_k]``
        # with NO ``rerank_score``. Swapping that truncated slice in would
        # silently drop every hit past top_k while page_info/next_cursor
        # still describe the full page, making those hits unreachable.
        # Only swap when reranking actually happened (mirrors the H9
        # guard in ``_maybe_rerank_search_all``).
        if not (reranked and "rerank_score" in reranked[0]):
            self._record_rerank_event(_RERANKER_SKIPPED_PASSTHROUGH)
            return payload
        # v3.3.1 field report (fid 71): a cross-encoder scores the snippet it
        # is handed, and a translation hub's "Hepatitis B - Multiple Languages"
        # is as on-topic as snippets get. The page arrived with artefacts
        # sunk; sorting on ``rerank_score`` alone would put them back on top.
        # ``query`` is the search string the page was fetched and cached
        # under, so a hub it asks for stays where the rerank put it.
        payload = {
            **payload,
            results_key: demote_crawl_artefacts([*pinned, *reranked], query=query),
        }
        self._record_rerank_event(_RERANKER_ENGAGED)
        return payload

    @staticmethod
    def _flatten_archive_hits(
        per_file: List[Dict[str, Any]],
    ) -> List[Dict[str, Any]]:
        """Flatten per-archive hits into a single tagged list for global rerank."""
        tagged: List[Dict[str, Any]] = []
        for entry_idx, entry in enumerate(per_file):
            if entry.get("error") or not isinstance(entry.get("result"), dict):
                continue
            for hit in entry["result"].get("results") or []:
                tagged.append({**hit, "_rerank_src_idx": entry_idx})
        return tagged

    @staticmethod
    def _redistribute_reranked_hits(
        per_file: List[Dict[str, Any]],
        reranked_tagged: List[Dict[str, Any]],
        *,
        query: str,
    ) -> None:
        """Group reranked tagged hits back into per-archive buckets in place.

        Strips the ``_rerank_src_idx`` tag and updates each entry's ``results``
        + ``has_hits`` fields. Mutates ``per_file``. ``query`` is the string
        every archive's page was searched and cached under."""
        grouped: Dict[int, List[Dict[str, Any]]] = {}
        for hit in reranked_tagged:
            src_idx = hit.get("_rerank_src_idx", -1)
            clean = {k: v for k, v in hit.items() if k != "_rerank_src_idx"}
            grouped.setdefault(src_idx, []).append(clean)
        for entry_idx, entry in enumerate(per_file):
            if entry.get("error") or not isinstance(entry.get("result"), dict):
                continue
            # Fid 71, per archive: each bucket renders as its own list, and
            # the global rerank sorted it on ``rerank_score`` alone.
            new_hits = demote_crawl_artefacts(grouped.get(entry_idx, []), query=query)
            entry["result"] = {**entry["result"], "results": new_hits}
            entry["has_hits"] = bool(new_hits)

    def _maybe_rerank_search_all(
        self,
        *,
        per_file: List[Dict[str, Any]],
        query: str,
    ) -> List[Dict[str, Any]]:
        """Cross-archive rerank for _handle_search_all.

        Flattens hits from all non-error archives into a single candidate list
        (tagged with ``_rerank_src_idx`` to track origin), reranks globally,
        then redistributes back to per-archive buckets in the reranked order.

        Mutates ``per_file`` entries in place and returns the list.
        No-op when the [reranker] extra is absent or there are no candidates.
        """
        from openzim_mcp.ml.reranker import BGEReranker

        reranker_cfg = self.zim_operations.config.ml.reranker
        reranker = BGEReranker.get(reranker_cfg)
        tagged_hits = self._flatten_archive_hits(per_file)

        if reranker is None:
            self._record_rerank_event(_RERANKER_SKIPPED_NOT_INSTALLED)
            return per_file
        if not tagged_hits:
            self._record_rerank_event(_RERANKER_SKIPPED_NO_RESULTS)
            return per_file

        reranked_tagged = reranker.rerank(
            query=query,
            candidates=tagged_hits,
            top_k=reranker_cfg.final_top_k,
        )
        # H9: BGEReranker.rerank's skip paths (the short-query gate that fires
        # for any query under min_query_tokens words — i.e. most real queries —
        # and the inference-failure passthrough) return ``candidates[:top_k]``
        # in ARCHIVE order with NO ``rerank_score``. Redistributing that
        # truncated, un-reranked slice silently zeroes out the third-and-later
        # archives (results=[], has_hits=False) and reorders by archive index —
        # telling the user those archives had no hits when Xapian found some.
        # Only redistribute when reranking actually happened (mirrors the
        # synthesize passthrough guard); otherwise return per_file untouched.
        scored = bool(reranked_tagged and "rerank_score" in reranked_tagged[0])
        if not scored:
            self._record_rerank_event(_RERANKER_SKIPPED_PASSTHROUGH)
            return per_file
        self._redistribute_reranked_hits(per_file, reranked_tagged, query=query)
        self._record_rerank_event(_RERANKER_ENGAGED)
        return per_file
