"""Shared helpers for the thin Phase F tool wrappers."""

from __future__ import annotations

import pathlib
from typing import TYPE_CHECKING, Any, Dict, Optional, Tuple

from mcp.types import ToolAnnotations

from ..constants import MAX_SEARCH_RESULT_LIMIT
from ..exceptions import (
    OpenZimMcpEntryNotFoundError,
    OpenZimMcpFileNotFoundError,
    OpenZimMcpRateLimitError,
    OpenZimMcpSecurityError,
    OpenZimMcpValidationError,
)
from ..responses import ToolErrorPayload, tool_error
from ..security import sanitize_context_for_error, sanitize_for_log

if TYPE_CHECKING:
    from ..server import OpenZimMcpServer

_DESCRIPTIONS_DIR = pathlib.Path(__file__).parent

# Every tool on this surface reads a local archive and writes nothing, and
# none of them reaches the network. Both facts are free signal for a client
# deciding whether a call needs human approval (``readOnlyHint``) or whether
# its result can be cached and replayed (``openWorldHint``) — the v3.3.1
# field report found the whole 8-tool surface publishing neither.
#
# ``openWorldHint`` is the one that has to be stated rather than left out:
# the MCP spec defaults it to *true*, so silence advertises the opposite of
# what an offline-first server does. ``destructiveHint`` and
# ``idempotentHint`` are deliberately absent — the spec defines both as
# meaningful only when ``readOnlyHint`` is false, so here they would be two
# more fields per tool that a correct client must ignore, charged against a
# schema budget with a hard cap. Pinned by
# ``tests/test_fr_tool_annotations.py``.
READ_ONLY_ANNOTATIONS = ToolAnnotations(read_only_hint=True, open_world_hint=False)

# A caller mistake is not a server fault. Every family here means "the request
# was wrong and the same request will always be wrong": the process is healthy
# and there is no operator action to take. Logging them at ERROR — which this
# seam did for the whole 8-tool surface — trains an operator to ignore ERROR,
# which is how a real archive corruption gets missed. Security denials stay at
# WARNING rather than INFO so they remain visible for intrusion triage at the
# shipped default LOG_LEVEL. Split on the exception TYPE, never by
# string-matching the message.
#
# ``OpenZimMcpValidationError`` covers its subclasses (cursor mismatch,
# archive-path, archive-name); ``OpenZimMcpEntryNotFoundError`` is the reason
# that type exists. Everything absent from this tuple keeps ERROR: a bare
# ``OpenZimMcpArchiveError`` (corrupt archive, decode failure), the timeout
# family, configuration errors, and any raw ``Exception`` (a bug).
_CALLER_FAULT = (
    OpenZimMcpValidationError,
    OpenZimMcpSecurityError,
    OpenZimMcpFileNotFoundError,
    OpenZimMcpRateLimitError,
    OpenZimMcpEntryNotFoundError,
)


def load_description(name: str) -> str:
    """Read the ``<name>_description.md`` markdown next to the tool modules.

    Centralizes the ``(_DIR / "...md").read_text(encoding="utf-8")`` line
    each wrapper repeated.
    """
    return (_DESCRIPTIONS_DIR / f"{name}_description.md").read_text(encoding="utf-8")


def tool_error_response(
    server: "OpenZimMcpServer",
    *,
    operation: str,
    error: Exception,
    context: Optional[str] = None,
) -> ToolErrorPayload:
    """Log + build the standard structured error envelope for a broad ``except``.

    The log is emitted under ``openzim_mcp.tools.<operation>`` so each tool's
    records keep the same logger name they had when every wrapper logged via
    its own module-level ``getLogger(__name__)`` (operation is the module
    basename, e.g. ``zim_links`` → ``...tools.zim_links``).

    L6: returns a ``ToolErrorPayload`` (``{error: True, operation, message}``)
    rather than a bare markdown string, so a data-layer failure shares the SAME
    envelope shape as the parameter/combination errors the wrappers already
    return via ``tool_error``. ``responses.py`` and the tool descriptions
    promise "every tool emits a recognisable envelope on failure"; before this
    a client branching on ``error: true`` silently missed broad-except
    failures. The enhanced markdown is preserved in the ``message`` field.
    """
    import logging

    # Control characters in the exception text (a ``zim_file_path`` with an
    # embedded LF is echoed verbatim by the validator) would otherwise forge
    # extra physical lines in the log (R2-3), and its LENGTH is caller-chosen
    # too — a 1 MB ``entry_path`` wrote a 1 MB record while the client-facing
    # envelope was already bounded. ``sanitize_for_log`` applies both, under
    # the same cap the envelope uses. Paths are deliberately NOT redacted
    # here: the operator-facing log needs the real one.
    level = logging.WARNING if isinstance(error, _CALLER_FAULT) else logging.ERROR
    logging.getLogger(f"openzim_mcp.tools.{operation}").log(
        level, "Error in %s: %s", operation, sanitize_for_log(str(error))
    )
    enhanced = server._create_enhanced_error_message(
        operation=operation, error=error, context=context or ""
    )
    # Redact absolute paths from the standalone ``context`` field too, so the
    # envelope's ``message`` and ``context`` are consistently sanitized — the
    # ``message`` is already redacted via ``_create_enhanced_error_message``;
    # without this the raw path (e.g. ``Path: /home/.../foo.zim``) leaked here.
    # Null-safe: keep ``None`` as-is so ``tool_error`` still omits the field.
    safe_context = sanitize_context_for_error(context) if context is not None else None
    return tool_error(operation=operation, message=enhanced, context=safe_context)


def _clamp_cost_to_capacity(
    server: "OpenZimMcpServer", operation: str, cost: int
) -> int:
    """Clamp a variable ``cost`` to the smallest relevant bucket capacity.

    ``TokenBucket.acquire`` denies unconditionally when ``cost`` exceeds the
    bucket's capacity — no amount of waiting refills past ``burst_size``. A
    batch cost derived from caller input (``len(entry_paths)``, up to
    ``MAX_BATCH_SIZE`` = 50) therefore exceeds the default ``burst_size`` of
    20 and would make a documented, supported batch size permanently
    impossible rather than merely expensive. Clamping keeps the batch
    "drains the bucket" instead of "can never succeed".
    """
    try:
        limiter_config = server.rate_limiter.config
        capacity = int(limiter_config.burst_size)
        op_config = limiter_config.per_operation_limits.get(operation)
        if op_config is not None:
            capacity = min(capacity, int(op_config.burst_size))
    except Exception:  # pragma: no cover - defensive (mocked limiters in tests)
        return cost
    if capacity <= 0:
        return cost
    return max(1, min(cost, capacity))


def enforce_rate_limit(
    server: "OpenZimMcpServer",
    operation: str,
    *,
    cost: Optional[int] = None,
) -> Optional[ToolErrorPayload]:
    """Apply the configured rate limit for ``operation`` to the current client.

    Returns ``None`` when the call is allowed, or a structured
    ``ToolErrorPayload`` the wrapper should return directly when the limit is
    exceeded. Buckets are keyed on ``(client_id, operation)``; the client id is
    read from ``request_context`` (set per-request by the HTTP auth middleware),
    so concurrent HTTP callers are isolated while stdio shares the ``"default"``
    bucket. A no-op when ``rate_limit.enabled`` is False.

    ``operation`` must be an INTERNAL operation name (``search``,
    ``get_binary_entry``, ...), not the wire-level v2 tool name. The v2 tools
    are multiplexers, so each wrapper resolves the name for the branch it is
    about to dispatch: passing ``"zim_get"`` matched nothing in
    ``RATE_LIMIT_COSTS`` and silently priced every call at the ``default``
    cost of 1, and made every documented ``per_operation_limits`` override
    inert because the bucket was keyed on a name no operator writes.

    ``cost`` overrides the table lookup for calls whose weight is not fixed —
    a batch ``zim_get(entry_paths=[...])`` debits one token per requested
    entry rather than one for the whole batch.

    This is the enforcement seam the limiter was missing — it was constructed in
    ``OpenZimMcpServer.__init__`` but never called, so configured
    ``OPENZIM_MCP_RATE_LIMIT__*`` limits were silently inert.
    """
    from ..exceptions import OpenZimMcpRateLimitError

    if cost is not None:
        cost = _clamp_cost_to_capacity(server, operation, cost)
    try:
        server.rate_limiter.check_rate_limit(operation=operation, cost=cost)
    except OpenZimMcpRateLimitError as exc:
        return tool_error(
            operation="rate_limited",
            message=str(exc),
            context=str(getattr(exc, "details", "") or "") or None,
        )
    return None


def decode_cursor_state(
    cursor: Optional[str], *, expected_tool: str
) -> Tuple[Optional[Dict[str, Any]], Optional[ToolErrorPayload]]:
    """Decode an advanced-tool pagination cursor into its state dict.

    Returns ``(state, None)`` on success — ``state`` is the cursor's decoded
    ``s`` payload, or ``None`` when ``cursor`` is empty/absent (a fresh,
    unpaginated call). Returns ``(None, error)`` when the cursor is malformed,
    carries an unsupported version, was issued by a different tool, or carries
    no usable resume offset. Callers project the returned state into their
    data-layer call: ``s['o']`` is the resume offset (browse page / links),
    ``s['scan_at']`` the walk resume id, and ``s['ai']`` the archive identity
    to verify against.
    """
    if cursor is None or not str(cursor).strip():
        return None, None
    from ..pagination import Cursor, CursorMismatchError

    try:
        payload = Cursor.decode(str(cursor).strip(), expected_tool=expected_tool)
    except CursorMismatchError as exc:
        return None, tool_error(
            operation="cursor_mismatch",
            message=(
                f"{exc}. Drop the `cursor` and call again with an explicit "
                "`offset` (or no pagination arg)."
            ),
            context=f"expected_tool={expected_tool}",
        )
    except ValueError as exc:
        return None, tool_error(
            operation="cursor_decode",
            message=(
                "The `cursor` value could not be decoded. Drop the `cursor` "
                "and call again with an explicit `offset` (or no pagination "
                "arg)."
            ),
            context=str(exc),
        )
    state = dict(payload["s"])
    # ``Cursor.decode`` validates the envelope but not the contents of ``s``,
    # and every consumer coerces a missing offset to 0 — so a rebuilt or
    # field-dropped cursor was served as a fresh page 1 while the caller
    # believed it had advanced. Reject it the way ``cursor_decode`` does for
    # simple mode. Walk cursors name the position ``scan_at``.
    offset = state.get("o", state.get("scan_at"))
    if not isinstance(offset, int) or isinstance(offset, bool) or offset < 0:
        return None, tool_error(
            operation="cursor_decode",
            message=(
                "The `cursor` payload's `s.o` (offset) is missing or invalid. "
                "Drop the `cursor` and call again with an explicit `offset` "
                "(or no pagination arg)."
            ),
            context=f"expected_tool={expected_tool}",
        )
    return state, None


def limit_out_of_range(
    limit: Optional[int], *, maximum: int, qualifier: str = ""
) -> Optional[ToolErrorPayload]:
    """The ``invalid_limit`` envelope, or ``None`` when ``limit`` is legal.

    v3.3.1 field report (fid 105). Every tool on this surface bounds its
    ``limit``, but only some of them said so in a shape a client can branch
    on: ``zim_search`` / ``zim_get`` emitted ``{"operation":
    "invalid_limit", "message": "`limit` must not exceed 50 …"}`` while
    ``zim_browse`` and ``zim_links`` let the range check happen one layer
    down, in the data layer, where it raises the generic validation type and
    reaches the caller as a 635-character markdown troubleshooting blob with
    the actual cap under "Technical Details".

    The data-layer checks stay: they are the ones that make the bound true
    for every caller of ``browse_namespace_data`` and friends, tool wrapper
    or not. This one runs first so the *tool* answers in the tool surface's
    vocabulary, which is the same division of labour ``zim_search`` already
    uses. ``qualifier`` names the mode or direction whose cap is being
    quoted, because both tools carry more than one.
    """
    if limit is None:
        return None
    if 1 <= limit <= maximum:
        return None
    scope = f" for {qualifier}" if qualifier else ""
    return tool_error(
        operation="invalid_limit",
        message=(
            f"`limit` must be between 1 and {maximum}{scope} " f"(provided: {limit})."
        ),
    )


def blank_archive_path(zim_file_path: Optional[str]) -> Optional[ToolErrorPayload]:
    """The ``invalid_argument`` envelope for an archive path that is blank.

    v3.3.1 field report (fid 32). An empty string satisfies the ``str``
    annotation, so pydantic passes it through and it fails several layers
    down in ``PathValidator.validate_path``, which does not know which
    parameter it was handed: "Path must be a non-empty string". The wrapper
    then labels that envelope with the argument it *does* know —
    ``Context: Path: iep.utm.edu/stoicism/`` — so the only concrete string
    in the whole rejection, printed twice, is the argument that was correct.

    Omitting the same argument produces ``invalid_argument`` with
    ``invalid_arguments: ["zim_file_path"]``, from the envelope layer's
    pydantic mapping. Both are "you did not give me an archive", so both
    answer the same way. Whitespace counts as blank: it reaches the identical
    raise one layer down.
    """
    if zim_file_path is None or zim_file_path.strip():
        return None
    return tool_error(
        operation="invalid_argument",
        message=(
            "`zim_file_path` must be a non-empty archive path. Use "
            "`zim_health()` and pass a `loaded_archives[].path` value verbatim."
        ),
        extras={"invalid_arguments": ["zim_file_path"]},
    )


def effective_limit(
    limit: Optional[int], state: Optional[Dict[str, Any]], default: int
) -> int:
    """Resolve the page size for a call that may be resuming from a cursor.

    An explicit ``limit`` always wins, so a caller can deliberately change
    page size mid-run. Otherwise the size the cursor was issued under
    (``s['l']``) is honoured: an opaque-cursor client replaying ``next_cursor``
    without repeating ``limit`` would otherwise silently revert to the
    wrapper's default, turning a deliberate two-row page into a hundred-row
    one. Anything other than a positive int in ``s['l']`` — a hand-built
    cursor can carry anything — falls back to ``default``, and so does
    anything larger than the largest page the server will ever mint. The
    per-tool cap is only checked against an *explicit* limit, so without an
    upper bound here a request carrying nothing but a forged cursor could name
    any page size it liked.
    """
    if limit is not None:
        return limit
    if state is not None:
        cursor_limit = state.get("l")
        if (
            isinstance(cursor_limit, int)
            and not isinstance(cursor_limit, bool)
            and 1 <= cursor_limit <= MAX_SEARCH_RESULT_LIMIT
        ):
            return cursor_limit
    return default


def cursor_context_mismatch(
    state: Dict[str, Any], *, field: str, expected: str, label: str
) -> Optional[ToolErrorPayload]:
    """Reject a cursor whose ``field`` names a context this call doesn't target.

    Guards ``ns`` / ``ep``: a replayed cursor must not silently apply one
    resume position to the wrong namespace or article. Returns ``None`` when
    the cursor omits the field or it matches the call.
    """
    value = state.get(field)
    if isinstance(value, str) and value and value != expected:
        return tool_error(
            operation="cursor_context_mismatch",
            message=(
                f"Cursor was issued for {label} {value!r}; this call targets "
                f"{expected!r}. Drop the `cursor` and start over for the new "
                f"{label}."
            ),
            context=f"{field}={value!r}",
        )
    return None
